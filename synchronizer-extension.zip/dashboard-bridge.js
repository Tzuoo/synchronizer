function isSynchronizerOrigin(origin) {
  if (origin === 'https://tzuoo.github.io') return true;
  try {
    const url = new URL(origin);
    return url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname);
  } catch {
    return false;
  }
}

window.addEventListener('message', async (event) => {
  if (event.source !== window || !isSynchronizerOrigin(event.origin)) return;
  const request = event.data;
  if (request?.source !== 'synchronizer-dashboard' || typeof request.requestId !== 'string') return;
  const allowed = request.type === 'GET_FULL_CAR_REPORTS' || request.type === 'GET_QUOTE_REPORTS' || request.type === 'PLAN_FULL_CAR' || request.type === 'FULL_CAR_ADD_SEQUENCE'
    || (request.type === 'FULL_CAR_COMMAND' && ['FULL_CAR_PREFLIGHT', 'FULL_CAR_ADD_CART'].includes(request.command));
  if (!allowed) return;
  try {
    const response = await chrome.runtime.sendMessage(request.type === 'GET_FULL_CAR_REPORTS' || request.type === 'GET_QUOTE_REPORTS'
      ? { type: request.type }
      : request.type === 'PLAN_FULL_CAR' ? { type: request.type, game: request.game, playType: request.playType, orders: request.orders }
      : request.type === 'FULL_CAR_ADD_SEQUENCE' ? { type: request.type, targets: request.targets }
      : { type: request.type, command: request.command, targets: request.targets });
    window.postMessage({ source: 'synchronizer-extension', requestId: request.requestId, response }, event.origin);
  } catch (error) {
    window.postMessage({ source: 'synchronizer-extension', requestId: request.requestId,
      response: { ok: false, error: String(error?.message || error) } }, event.origin);
  }
});
