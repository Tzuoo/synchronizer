window.addEventListener(
  "message",
  (event) => {
    if (
      event.source !== window ||
      event.data?.type !==
        "SYNC_DETAIL_RESPONSE"
    ) {
      return;
    }

    const supportedRoots = [
      "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
      "188hot.net", "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"
    ];
    if (!supportedRoots.includes(rootDomain(location.hostname))) return;

    try {
      const data =
        event.data;

      const url =
        new URL(
          data.url,
          location.href
        );

      if (
        url.origin !==
        location.origin
      ) {
        return;
      }

      document.documentElement.dataset.syncDetailResponse =
        `${data.method || "GET"} ${url.pathname}${url.search}`.slice(0, 500);
      safeMessage({
        type:
          "LEARN_DETAIL_REQUEST",
        request: {
          host:
            location.hostname,
          root:
            rootDomain(location.hostname),
          path:
            url.pathname + url.search,
          url:
            url.href,
          method:
            data.method === "POST"
              ? "POST"
              : "GET",
          body:
            data.body || "",
          contentType:
            data.contentType || "",
          headers:
            data.headers || {}
        }
      });

      const bets =
        scrapeDetailResponse(
          data.response || ""
        );

      document.documentElement.dataset.syncDetailCount = String(bets.length);

      const detailRoot = rootDomain(location.hostname);
      if (["vs968.net", "kd998.net"].includes(detailRoot)) {
        safeMessage({ type: "SITE_DIAGNOSTIC", state: {
          responseAt: new Date().toISOString(),
          responseOk: true,
          parsedCount: bets.length,
          pollState: bets.length ? "已解析下注明細" : "收到回應但解析為 0 筆"
        } });
      }

      safeMessage({
        type:
          "POLL_STATUS",
        state: {
          ok: true,
          count:
            bets.length
        }
      });

      if (bets.length) {
        safeMessage({
          type:
            "SYNC_BETS",
          bets
        });
      }
    } catch {
      safeMessage({ type: 'SITE_DIAGNOSTIC', state: { event: { stage: 'parse', code: 'PARSE_FAILED' } } });
    }
  }
);

// page-hook 比 content.js 更早在 document_start 執行。若網站在內容腳本
// 註冊前就回傳一次明細，要求它重送同一份已取得的回應；不會額外發出
// 網站請求，也不改動使用者目前頁面。
window.postMessage({ type: "SYNC_REQUEST_LAST_DETAIL" }, "*");

function preserveWebsiteOrder(bets) {
  const totals =
    new Map();

  const seen =
    new Map();

  bets.forEach(
    (bet) =>
      totals.set(
        bet.placedAt,
        (
          totals.get(
            bet.placedAt
          ) || 0
        ) + 1
      )
  );

  return bets.map(
    (bet) => {
      if (
        (
          totals.get(
            bet.placedAt
          ) || 0
        ) < 2
      ) {
        return bet;
      }

      const position =
        seen.get(
          bet.placedAt
        ) || 0;

      seen.set(
        bet.placedAt,
        position + 1
      );

      const milliseconds =
        String(
          Math.max(
            0,
            999 - position
          )
        ).padStart(
          3,
          "0"
        );

      const placedAt =
        String(
          bet.placedAt
        ).replace(
          /(?:\.\d{1,3})?([+-]\d\d:\d\d|Z)$/,
          `.${milliseconds}$1`
        );

      return {
        ...bet,
        placedAt
      };
    }
  );
}

function sendBets(bets) {
  if (!bets.length) {
    return;
  }

  const actualAccount = reportActualAccount();
  bets = preserveWebsiteOrder(
    bets.map((bet) => actualAccount ? { ...bet, account: actualAccount } : bet)
  );

  safeMessage({
    type:
      "SYNC_BETS",
    bets
  });
}

async function sync() {
  const domain =
    rootDomain(
      location.hostname
    );

  const bets =
    domain === "kd998.net"
      ? scrapeKdOrders()
      : ["amc283.com", "pee688.com"].includes(domain)
      ? scrapeAmcOrders()
      : ["umh693.com", "and539.com"].includes(domain)
      ? scrapeUmhOrders()
      : [
          "188hot.net",
          "bnd139.com",
          "hyp98.com"
        ].includes(domain)
      ? scrape188Orders()
      : scrape();

  sendBets(
    bets
  );
}

setInterval(
  sync,
  2000
);

sync();

setInterval(reportActualAccount, 5000);
reportActualAccount();

let learnedPollBusy =
  false;

const kdCarUnits = {};
chrome.storage.local.get(["kdCarUnits"], ({ kdCarUnits: saved = {} }) => Object.assign(kdCarUnits, saved));

// 操作中的前景頁以網站本身的回應為主；同步器只被動擷取，不另外
// 重播明細或重載隱藏框架。使用者停下操作或切走分頁後再補讀即可。
const FOREGROUND_OPERATION_GRACE_MS = 30_000;
let lastForegroundOperationAt = Date.now();
for (const eventName of ["pointerdown", "keydown", "input", "touchstart"]) {
  document.addEventListener(eventName, () => { lastForegroundOperationAt = Date.now(); }, { passive: true });
}
function shouldDeferBackgroundWork() {
  return document.visibilityState === "visible" &&
    Date.now() - lastForegroundOperationAt < FOREGROUND_OPERATION_GRACE_MS;
}

async function pollLearnedDetail() {
  const supportedRoots = [
    "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
    "188hot.net", "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"
  ];
  const root = rootDomain(location.hostname);
  const directA06Roots = ["hyp98.com", "cj3688.com", "188hot.net", "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"];
  // 風雲的最外層只是網路郵局 frameset；真正登入、持有下注狀態並
  // 呼叫 cmd=516 明細 API 的是 /new_web/ 子框架。背景重播必須在該
  // 子框架執行，否則伺服器會把請求視為未登入。其他網站維持頂層執行。
  const isSharedGatewayWorkFrame =
    ["vs968.net", "kd998.net"].includes(root) && location.pathname.includes("/new_web/");
  const isAllowedPollFrame =
    ["vs968.net", "kd998.net"].includes(root) ? isSharedGatewayWorkFrame && !isInsideSyncDetailFrame() : window.top === window;
  if (
    learnedPollBusy ||
    shouldDeferBackgroundWork() ||
    !supportedRoots.includes(root) ||
    !isAllowedPollFrame ||
    directA06Roots.includes(root)
  ) return;

  learnedPollBusy = true;
  try {
    const { learnedDetailRequests = {} } = await chrome.storage.local.get(["learnedDetailRequests"]);
    const saved = learnedDetailRequests[root];
    if (!saved) {
      document.documentElement.dataset.syncPollState = "no-saved-request";
      safeMessage({ type: "SITE_DIAGNOSTIC", state: {
        frameOk: true,
        framePath: location.pathname,
        requestReady: false,
        pollState: "等待開啟一次網站下注明細"
      } });
      return;
    }

    // Same main-domain subdomains can share the learned endpoint path,
    // while the request is sent from the current origin with its own login cookies.
    const request = { ...saved };
    if (request.path) request.url = location.origin + request.path;

    window.postMessage({ type: "SYNC_SET_DETAIL_REQUEST", request }, "*");
    window.postMessage({ type: "SYNC_POLL_DETAIL" }, "*");
    document.documentElement.dataset.syncPollState =
      `sent ${request.method || "GET"} ${request.path || request.url || ""}`.slice(0, 500);
    safeMessage({ type: "SITE_DIAGNOSTIC", state: {
      frameOk: true,
      framePath: location.pathname,
      requestReady: true,
      pollAt: new Date().toISOString(),
      pollState: "已送出背景讀取"
    } });
  } catch (error) {
    safeMessage({ type: "POLL_STATUS", state: { ok: false, error: String(error) } });
    safeMessage({ type: 'SITE_DIAGNOSTIC', state: { event: { stage: 'read', code: 'READ_FAILED' } } });
  } finally {
    learnedPollBusy = false;
  }
}

// 一分鐘一次足以補回前景頁沒有直接攔到的資料，也避免與下單請求競爭。
setInterval(pollLearnedDetail, 60000);
pollLearnedDetail();

function pollSharedLedgerBackground() {
  const root = rootDomain(location.hostname);
  if (shouldDeferBackgroundWork() || !["vs968.net", "kd998.net"].includes(root) || !location.pathname.includes("/new_web/")) return;
  window.postMessage({ type: "SYNC_POLL_SHARED_LEDGER" }, "*");
}

setInterval(pollSharedLedgerBackground, 60000);
setTimeout(pollSharedLedgerBackground, 1500);

function heartbeat() {
  safeMessage({
    type:
      "SYNC_HEARTBEAT"
  });
}

setInterval(
  heartbeat,
  10000
);

heartbeat();

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "SYNC_BACKGROUND_TICK") return;
  heartbeat();
  pollLearnedDetail();
  pollSharedLedgerBackground();
  syncLedgerDom();
  const root = rootDomain(location.hostname);
  if (["vs968.net", "kd998.net"].includes(root) && location.pathname.includes("/new_web/")) {
    safeMessage({ type: "SITE_DIAGNOSTIC", state: {
      frameOk: true,
      framePath: location.pathname,
      wakeAt: new Date().toISOString()
    } });
  }
});
