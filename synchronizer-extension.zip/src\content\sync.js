function withCurrentWinningAmounts(bets) {
  const amounts=new Map();
  for(const table of document.querySelectorAll('table')) {
    const rows=Array.from(table.rows || []), header=rows.find(row=>Array.from(row.cells).some(cell=>cell.textContent.trim()==='中獎'));
    if(!header)continue;
    let index=0;
    for(const cell of header.cells) {
      if(cell.textContent.trim()==='中獎')break;
      index+=cell.colSpan||1;
    }
    const item=rows.map(row=>row.cells[0]?.textContent.trim()).find(value=>/^\d+$/.test(value||''));
    const date=String(table.innerText||'').replace(/\s+/g,' ').match(/\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/)?.[0];
    if(!item||!date)continue;
    const summary=rows.find(row=>/單項金額總計/.test(row.textContent));if(!summary)continue;
    // A06's item/play cells span the master, details and summary rows.
    // cellIndex/colSpan alone is two columns short at the summary (the rebate).
    let spans=[], winning=null, valid=true;
    for(const row of rows) {
      let column=0;
      const next=spans.map(value=>Math.max(0,value-1));
      for(const cell of row.cells) {
        while(spans[column]>0)column++;
        const width=cell.colSpan||1,height=cell.rowSpan??1;
        if(!Number.isSafeInteger(width)||width<1||!Number.isSafeInteger(height)||height<1){valid=false;break;}
        const end=column+width;
        for(let col=column;col<end;col++) {
          if(spans[col]>0)valid=false;
          next[col]=height-1;
        }
        if(row===summary&&column===index&&end===index+1){const text=cell.textContent.trim().replace(/,/g,'');if(/^\d+(?:\.\d+)?$/.test(text))winning=Number(text);}
        column=end;
      }
      spans=next;
      if(!valid||row===summary)break;
    }
    if(!valid||winning==null)continue;
    const key=`${item}|${date}`,previous=amounts.get(key);
    amounts.set(key,previous===undefined?winning:null); // Ambiguous source tables are not guessed.
  }
  return bets.map(bet=>{
    const key=`${bet.itemNumber}|${String(bet.sourcePlacedAt||bet.placedAt||'').replace('T',' ').slice(0,19)}`;
    const result=amounts.get(key);
    return result==null?bet:{...bet,result,status:result>0&&!/刪|撤|取消/.test(bet.status||'')?'已中獎':bet.status};
  });
}
function sendCurrentBets(bets, proof, family) {
  if (!proof || proof.complete !== true || proof.scope !== 'all' || !Number.isSafeInteger(proof.total) || proof.total < 0 ||
      !Number.isFinite(Date.parse(proof.capturedAt)) || !Array.isArray(bets) ||
      bets.some(bet=>['partial','unknown'].includes(bet.parseStatus))) return false;
  if (family === 'a06') {
    if (!Array.isArray(proof.items) || proof.items.length !== proof.total) return false;
    const expected = new Set(proof.items.map(item=>`${item.game}|${item.item}`));
    const found = new Set(bets.map(bet=>`${String(bet.event||'').split(/\s*\/\s*/)[0]}|${bet.itemNumber}`));
    if (expected.size !== proof.total || expected.size !== found.size || [...expected].some(key=>!found.has(key))) return false;
  } else {
    if (!Array.isArray(proof.ids) || proof.ids.length !== proof.total) return false;
    const found = new Set(bets.map(bet=>String(bet.id).split('|')[2]));
    if (found.size !== proof.total || proof.ids.some(id=>!found.has(id))) return false;
  }
  const account = proof.account || reportActualAccount();
  const legacyBets = bets;
  if(proof.account)safeMessage({type:'REGISTER_ACTUAL_ACCOUNT',account});
  if(family==='a06')bets=withCurrentWinningAmounts(bets);
  // Gateway is authoritative for membership; current DOM remains a display representation.
  // The dashboard's existing one-to-one matcher decides whether those representations match.
  const representations=family==='gateway'&&bets.length
    ? (rootDomain(location.hostname)==='kd998.net'?scrapeKdOrders():scrape()) : [];
  Promise.resolve(safeMessage({ type:'SYNC_CURRENT_BETS', account, capturedAt:proof.capturedAt,
    bets:preserveWebsiteOrder(bets.map(bet=>account?{...bet,account}:bet)),
    representations:preserveWebsiteOrder(representations.map(bet=>account?{...bet,account}:bet)) })).then(result=>{
      if (!result || result.unsupported) sendBets(legacyBets);
    });
  return true;
}
function withCurrentAmcPackages(bets, proof) {
  if (!Array.isArray(proof?.items)) return bets;
  const result=[...bets];
  for(const item of proof.items) {
    const expanded=currentAmcPackages.get(item.id);
    if(!expanded || String(expanded.itemNumber)!==item.item ||
       String(expanded.sourcePlacedAt||expanded.placedAt).replace('T',' ').slice(0,19)!==item.placedAt ||
       String(expanded.event||'').split(/\s*\/\s*/)[0]!==item.game ||
       proof.items.filter(other=>other.item===item.item&&other.game===item.game).length!==1)continue;
    const matches=result.filter(bet=>String(bet.itemNumber)===item.item&&String(bet.event||'').split(/\s*\/\s*/)[0]===item.game);
    if(matches.length>1)continue;
    if(matches.length)result[result.indexOf(matches[0])]=expanded;
    else result.push(expanded); // A collapsed package has no text-parser placeholder.
  }
  const position=bet=>proof.items.findIndex(item=>item.item===String(bet.itemNumber)&&item.game===String(bet.event||'').split(/\s*\/\s*/)[0]);
  return result.sort((a,b)=>position(a)-position(b));
}
window.addEventListener('message', event=>{
  if (event.source!==window || event.data?.type!=='SYNC_CURRENT_A06' || !isInsideSyncDetailFrame()) return;
  const root=rootDomain(location.hostname);
  const bets=['amc283.com','pee688.com'].includes(root)?withCurrentAmcPackages(scrapeAmcOrders(),event.data.proof):['umh693.com','and539.com'].includes(root)?scrapeUmhOrders():scrape188Orders();
  if (!sendCurrentBets(bets,event.data.proof,'a06')) safeMessage({type:'SITE_DIAGNOSTIC',state:{event:{stage:'parse',code:'PARSE_FAILED'}}});
});
window.addEventListener(
  "message",
  (event) => {
    if (
      event.source !== window ||
      event.data?.type !==
        "SYNC_DETAIL_RESPONSE"
    ) {
      return;
    }

    const supportedRoots = [
      "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
      "188hot.net", "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"
    ];
    if (!supportedRoots.includes(rootDomain(location.hostname))) return;

    try {
      const data =
        event.data;

      const url =
        new URL(
          data.url,
          location.href
        );

      if (
        url.origin !==
        location.origin
      ) {
        return;
      }

      document.documentElement.dataset.syncDetailResponse =
        `${data.method || "GET"} ${url.pathname}${url.search}`.slice(0, 500);
      safeMessage({
        type:
          "LEARN_DETAIL_REQUEST",
        request: {
          host:
            location.hostname,
          root:
            rootDomain(location.hostname),
          path:
            url.pathname + url.search,
          url:
            url.href,
          method:
            data.method === "POST"
              ? "POST"
              : "GET",
          body:
            data.body || "",
          contentType:
            data.contentType || "",
          headers:
            data.headers || {}
        }
      });

      const bets =
        scrapeDetailResponse(
          data.response || "", data.gatewayGames
        );
      if (data.currentProof && sendCurrentBets(bets, data.currentProof, 'gateway')) return;
      if (data.currentProof) safeMessage({type:'SITE_DIAGNOSTIC',state:{event:{stage:'parse',code:'PARSE_FAILED'}}});

      document.documentElement.dataset.syncDetailCount = String(bets.length);

      const detailRoot = rootDomain(location.hostname);
      if (["vs968.net", "kd998.net"].includes(detailRoot)) {
        safeMessage({ type: "SITE_DIAGNOSTIC", state: {
          responseAt: new Date().toISOString(),
          responseOk: true,
          parsedCount: bets.length,
          pollState: bets.length ? "已解析下注明細" : "收到回應但解析為 0 筆"
        } });
      }

      safeMessage({
        type:
          "POLL_STATUS",
        state: {
          ok: true,
          count:
            bets.length
        }
      });

      if (bets.length) {
        safeMessage({
          type:
            "SYNC_BETS",
          bets
        });
      }
    } catch {
      safeMessage({ type: 'SITE_DIAGNOSTIC', state: { event: { stage: 'parse', code: 'PARSE_FAILED' } } });
    }
  }
);

// page-hook 比 content.js 更早在 document_start 執行。若網站在內容腳本
// 註冊前就回傳一次明細，要求它重送同一份已取得的回應；不會額外發出
// 網站請求，也不改動使用者目前頁面。
window.postMessage({ type: "SYNC_REQUEST_LAST_DETAIL" }, "*");

function preserveWebsiteOrder(bets) {
  const totals =
    new Map();

  const seen =
    new Map();

  bets.forEach(
    (bet) =>
      totals.set(
        bet.placedAt,
        (
          totals.get(
            bet.placedAt
          ) || 0
        ) + 1
      )
  );

  return bets.map(
    (bet) => {
      const sourcePlacedAt =
        String(
          bet.sourcePlacedAt ||
          bet.placedAt
        );

      if (
        (
          totals.get(
            bet.placedAt
          ) || 0
        ) < 2
      ) {
        return {
          ...bet,
          sourcePlacedAt
        };
      }

      const position =
        seen.get(
          bet.placedAt
        ) || 0;

      seen.set(
        bet.placedAt,
        position + 1
      );

      const milliseconds =
        String(
          Math.max(
            0,
            999 - position
          )
        ).padStart(
          3,
          "0"
        );

      const placedAt =
        String(
          bet.placedAt
        ).replace(
          /(?:\.\d{1,3})?([+-]\d\d:\d\d|Z)$/,
          `.${milliseconds}$1`
        );

      return {
        ...bet,
        sourcePlacedAt,
        placedAt
      };
    }
  );
}

function sendBets(bets) {
  if (!bets.length) {
    return;
  }

  const actualAccount = reportActualAccount();
  bets = preserveWebsiteOrder(
    bets.map((bet) => actualAccount ? { ...bet, account: actualAccount } : bet)
  );

  safeMessage({
    type:
      "SYNC_BETS",
    bets
  });
}

async function sync() {
  const domain =
    rootDomain(
      location.hostname
    );

  const bets =
    domain === "kd998.net"
      ? scrapeKdOrders()
      : ["amc283.com", "pee688.com"].includes(domain)
      ? scrapeAmcOrders()
      : ["umh693.com", "and539.com"].includes(domain)
      ? scrapeUmhOrders()
      : [
          "188hot.net",
          "bnd139.com",
          "hyp98.com"
        ].includes(domain)
      ? scrape188Orders()
      : scrape();

  sendBets(
    bets
  );
}

setInterval(
  sync,
  2000
);

sync();

setInterval(reportActualAccount, 5000);
reportActualAccount();

let learnedPollBusy =
  false;

const kdCarUnits = {};
chrome.storage.local.get(["kdCarUnits"], ({ kdCarUnits: saved = {} }) => Object.assign(kdCarUnits, saved));

// 操作中的前景頁以網站本身的回應為主；同步器只被動擷取，不另外
// 重播明細或重載隱藏框架。使用者停下操作或切走分頁後再補讀即可。
const FOREGROUND_OPERATION_GRACE_MS = 30_000;
let lastForegroundOperationAt = Date.now();
for (const eventName of ["pointerdown", "keydown", "input", "touchstart"]) {
  document.addEventListener(eventName, () => { lastForegroundOperationAt = Date.now(); }, { passive: true });
}
function shouldDeferBackgroundWork() {
  return document.visibilityState === "visible" &&
    Date.now() - lastForegroundOperationAt < FOREGROUND_OPERATION_GRACE_MS;
}

async function pollLearnedDetail() {
  const supportedRoots = [
    "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
    "188hot.net", "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"
  ];
  const root = rootDomain(location.hostname);
  const directA06Roots = ["hyp98.com", "cj3688.com", "188hot.net", "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"];
  // 風雲的最外層只是網路郵局 frameset；真正登入、持有下注狀態並
  // 呼叫 cmd=516 明細 API 的是 /new_web/ 子框架。背景重播必須在該
  // 子框架執行，否則伺服器會把請求視為未登入。其他網站維持頂層執行。
  const isSharedGatewayWorkFrame =
    ["vs968.net", "kd998.net"].includes(root) && location.pathname.includes("/new_web/");
  const isAllowedPollFrame =
    ["vs968.net", "kd998.net"].includes(root) ? isSharedGatewayWorkFrame && !isInsideSyncDetailFrame() : window.top === window;
  if (
    learnedPollBusy ||
    shouldDeferBackgroundWork() ||
    !supportedRoots.includes(root) ||
    !isAllowedPollFrame ||
    directA06Roots.includes(root)
  ) return;

  learnedPollBusy = true;
  try {
    const { learnedDetailRequests = {} } = await chrome.storage.local.get(["learnedDetailRequests"]);
    const saved = learnedDetailRequests[root];
    if (!saved) {
      document.documentElement.dataset.syncPollState = "no-saved-request";
      safeMessage({ type: "SITE_DIAGNOSTIC", state: {
        frameOk: true,
        framePath: location.pathname,
        requestReady: false,
        pollState: "等待開啟一次網站下注明細"
      } });
      return;
    }

    // Same main-domain subdomains can share the learned endpoint path,
    // while the request is sent from the current origin with its own login cookies.
    const request = { ...saved };
    if (request.path) request.url = location.origin + request.path;

    window.postMessage({ type: "SYNC_SET_DETAIL_REQUEST", request }, "*");
    window.postMessage({ type: "SYNC_POLL_DETAIL" }, "*");
    document.documentElement.dataset.syncPollState =
      `sent ${request.method || "GET"} ${request.path || request.url || ""}`.slice(0, 500);
    safeMessage({ type: "SITE_DIAGNOSTIC", state: {
      frameOk: true,
      framePath: location.pathname,
      requestReady: true,
      pollAt: new Date().toISOString(),
      pollState: "已送出背景讀取"
    } });
  } catch (error) {
    safeMessage({ type: "POLL_STATUS", state: { ok: false, error: String(error) } });
    safeMessage({ type: 'SITE_DIAGNOSTIC', state: { event: { stage: 'read', code: 'READ_FAILED' } } });
  } finally {
    learnedPollBusy = false;
  }
}

// 一分鐘一次足以補回前景頁沒有直接攔到的資料，也避免與下單請求競爭。
setInterval(pollLearnedDetail, 60000);
pollLearnedDetail();

function pollSharedLedgerBackground() {
  const root = rootDomain(location.hostname);
  if (shouldDeferBackgroundWork() || !["vs968.net", "kd998.net"].includes(root) || !location.pathname.includes("/new_web/")) return;
  window.postMessage({ type: "SYNC_POLL_SHARED_LEDGER" }, "*");
}

setInterval(pollSharedLedgerBackground, 60000);
setTimeout(pollSharedLedgerBackground, 1500);

function heartbeat() {
  safeMessage({
    type:
      "SYNC_HEARTBEAT"
  });
}

setInterval(
  heartbeat,
  10000
);

heartbeat();

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "SYNC_BACKGROUND_TICK") return;
  heartbeat();
  pollLearnedDetail();
  pollSharedLedgerBackground();
  syncLedgerDom();
  const root = rootDomain(location.hostname);
  if (["vs968.net", "kd998.net"].includes(root) && location.pathname.includes("/new_web/")) {
    safeMessage({ type: "SITE_DIAGNOSTIC", state: {
      frameOk: true,
      framePath: location.pathname,
      wakeAt: new Date().toISOString()
    } });
  }
});
