// Only these non-sensitive codes may leave this browser. Never send raw errors or URLs.
const SyncDiagnostics = (() => {
  const stages = ['frame', 'read', 'parse', 'upload', 'ledger', 'ledgerUpload', 'heartbeat'];
  const codes = ['OK', 'EMPTY', 'WAIT_REQUEST', 'WAIT_FRAME', 'READ_FAILED', 'PARSE_FAILED', 'UPLOAD_FAILED', 'LEDGER_FAILED', 'HTTP_401', 'HTTP_403', 'HTTP_429', 'HTTP_5XX'];
  function errorCode(error, fallback) {
    const value = String(error || '');
    const status = value.match(/HTTP\s+(401|403|429|5\d\d)\b/);
    return status ? (status[1][0] === '5' ? 'HTTP_5XX' : `HTTP_${status[1]}`) : fallback;
  }
  function record(previous = {}, event, at) {
    if (!stages.includes(event.stage) || !codes.includes(event.code)) return previous;
    const status = event.code === 'OK' ? 'ok' : event.code === 'EMPTY' || event.code.startsWith('WAIT_') ? 'waiting' : 'error';
    const next = { status, code: event.code, eventAt: at, count: Number.isInteger(event.count) ? Math.max(0, Math.min(event.count, 1000000)) : null,
      lastErrorCode: previous.lastErrorCode || null, lastErrorAt: previous.lastErrorAt || null, recoveredAt: previous.recoveredAt || null };
    if (status === 'error') { next.lastErrorCode = event.code; next.lastErrorAt = at; next.recoveredAt = null; }
    else if (status === 'ok' && next.lastErrorAt && !next.recoveredAt) next.recoveredAt = at;
    return next;
  }
  function rows(states = {}) {
    return Object.entries(states).flatMap(([site, state]) => stages.filter(stage => state.stages?.[stage]).map(stage => ({ site, stage, ...state.stages[stage] })));
  }
  return { record, rows, errorCode };
})();
