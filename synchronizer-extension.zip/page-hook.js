(() => {
  let lastRequest = null;
  let sharedLedgerBusy = false;
  let packageBusy = false;
  let packageNextRead = 0;
  // Local structural diagnostics only: never include orders, IDs or session URLs.
  const packageDiagnostic = (stage, extra = {}) => {
    try {
      const key = window.frameElement?.name === 'sync-detail-frame' ? 'syncPackageBackground' : 'syncPackageVisible';
      const value = JSON.stringify({ stage, ...extra, at: Date.now() });
      document.documentElement.dataset[key] = value;
      window.top.document.documentElement.dataset[key] = value;
    } catch { /* Cross-origin parents must not prevent reading. */ }
  };

  // A06_0's WinNO uses the master ID (not the older ContentID API).
  // Read via the site's own Ajax manager/formatter without opening a dialog.
  const pollAmcPackages = async () => {
    if (packageBusy || Date.now() < packageNextRead || !/(^|\.)pee688\.com$/.test(location.hostname) ||
        !/\/Front\/A\/A06$/.test(location.pathname)) return;
    if (!window.ko?.contextFor || !window.$AjaxManage?.AddAjax || !window.XI?.WinNOData?.GetOrderData) {
      packageDiagnostic('dependencies', { ko: !!window.ko?.contextFor, ajax: !!window.$AjaxManage?.AddAjax, formatter: !!window.XI?.WinNOData?.GetOrderData });
      return;
    }
    packageBusy = true;
    let attempted = false;
    const clean = html => {
      const node = document.createElement('div');
      node.innerHTML = String(html || '').replace(/<br\s*\/?\s*>/gi, '\n');
      return node.textContent.replace(/\u00a0/g, ' ').trim();
    };
    const query = params => new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Package timeout')), 10000);
      window.$AjaxManage.AddAjax('/FrontA060/OrderContentQuery', {
        params, success: data => { clearTimeout(timer); resolve(data); },
        error: () => { clearTimeout(timer); reject(new Error('Package query failed')); }
      });
    });
    try {
      const seen = new Set();
      const candidates = document.querySelectorAll('td[data-bind*="Mo.OnSeeDetails"]');
      packageDiagnostic('candidates', { count: candidates.length });
      for (const cell of candidates) {
        const context = window.ko.contextFor(cell);
        const master = context?.$parent;
        const detail = context?.$data;
        if (!master?.ID || !/套餐/.test(String(master.ItemName || '')) ||
            detail?.OrderData !== '' || !Array.isArray(master.Detail) || master.Detail.length !== 1 ||
            seen.has(String(master.ID))) continue;
        seen.add(String(master.ID));
        attempted = true;
        packageDiagnostic('query');
        const table = cell.closest('table');
        if (!table) continue;
        const snapshot = table.innerText;
        const date = snapshot.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/)?.[0];
        const rows = [];
        let expected = null;
        for (let page = 1; page <= 100; page++) {
          document.documentElement.dataset.syncPackageReadingAt = String(Date.now());
          const result = await query({ ID: master.ID, PageID: page, PageSize: 15, IsShowWin: false });
          packageDiagnostic('response', { rows: Array.isArray(result?.OrderList) ? result.OrderList.length : null, totalType: typeof result?.TotalCnt, total: Number.isFinite(Number(result?.TotalCnt)) ? Number(result.TotalCnt) : null });
          if (!Array.isArray(result?.OrderList) || !Number.isInteger(result.TotalCnt) || result.TotalCnt < 1) throw new Error('Incomplete package');
          if (expected !== null && expected !== result.TotalCnt) throw new Error('Package changed');
          expected = result.TotalCnt;
          rows.push(...result.OrderList);
          if (rows.length >= expected) break;
          if (!result.OrderList.length) throw new Error('Missing package page');
        }
        if (rows.length !== expected || !cell.isConnected || table.innerText !== snapshot || !date) {
          packageDiagnostic('snapshot-rejected', { complete: rows.length === expected, connected: !!cell.isConnected, unchanged: table.innerText === snapshot, date: !!date });
          continue;
        }
        const parts = rows.map(row => ({
          name: clean(row.GroupName) + (row.ItemName ? ' ' + clean(row.ItemName) : ''),
          selection: clean(window.XI.WinNOData.GetOrderData(null, master.ItemID, row.GroupID, row.OrderData, master.GameID)),
          amount: Number(row.TotBet)
        }));
        if (parts.some(p => !p.selection || !Number.isFinite(p.amount)) ||
            parts.reduce((sum, p) => sum + p.amount, 0) !== Number(detail.TotBet)) {
          packageDiagnostic('parts-rejected', { selections: parts.every(p => !!p.selection), amounts: parts.every(p => Number.isFinite(p.amount)), sumMatches: parts.reduce((sum, p) => sum + p.amount, 0) === Number(detail.TotBet) });
          continue;
        }
        packageDiagnostic('posted');
        window.postMessage({ type: 'SYNC_AMC_PACKAGE', package: {
          id: String(master.ID), itemNumber: String(master.RowID), date,
          playType: clean(master.GroupName) + ' ' + clean(master.ItemName),
          gameText: document.body.innerText.split(snapshot)[0],
          unitAmount: Number(detail.Bet), combinationCount: Number(detail.TotCnt),
          betAmount: Number(detail.TotBet), deleted: Boolean(master.IsDelete), parts
        } }, '*');
      }
    } catch {
      // Preserve the last structural stage so a rejected response remains inspectable.
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code: 'READ_FAILED' } }, '*');
    } finally {
      packageBusy = false;
      packageNextRead = attempted ? Date.now() + 15000 : 0;
      delete document.documentElement.dataset.syncPackageReadingAt;
    }
  };
  if (/(^|\.)pee688\.com$/.test(location.hostname) && /\/Front\/A\/A06$/.test(location.pathname)) {
    packageDiagnostic('loaded');
    // Probe readiness before the background document's 10-second reload.
    // Successful attempts still have a 15-second cooldown; in-flight work is exclusive.
    setInterval(pollAmcPackages, 1000);
  }

  const findVueStore = () => {
    for (const element of document.querySelectorAll("*")) {
      let vm = element.__vue__;
      for (let depth = 0; vm && depth < 12; depth += 1, vm = vm.$parent) {
        if (vm.$store) return vm.$store;
      }
    }
    return null;
  };

  const windQuoteContext = (store) => {
    const seq = store?.getters?.seq || {};
    const pageText = String(document.body?.innerText || '').replace(/\u00a0/g, ' ');
    const storedGame = String(seq.name || '').trim();
    const visibleGame = pageText.match(/(?:^|\n)\s*(539|加州彩)\s*[|｜]\s*(?:全車|台號)(?:\s|$)/m)?.[1] || '';
    const game = ['539', '加州彩'].includes(storedGame) ? storedGame : visibleGame;
    const storedPhase = String(seq.seq || '').trim();
    const visiblePhase = pageText.match(/\b([A-Z]\d{5,}\s*-\s*\d+)\b/)?.[1] || '';
    return { game, phase: (storedPhase || visiblePhase).replace(/\s+/g, '') };
  };

  const windQuoteRefreshAt = new Map();
  const windQuoteRefreshBusy = new Set();
  const refreshWindCasinoQuotes = (store, casino, currentCasino) => {
    if (!Number.isFinite(casino) || casino === currentCasino || windQuoteRefreshBusy.has(casino) ||
        Date.now() - (windQuoteRefreshAt.get(casino) || 0) < 10000) return;
    windQuoteRefreshBusy.add(casino);
    windQuoteRefreshAt.set(casino, Date.now());
    Promise.all([
      Promise.resolve(store.dispatch('Game.c425.update', casino)),
      Promise.resolve(store.dispatch('Game.c423.update', casino)),
      Promise.resolve(store.dispatch('Game.bet.group.async', casino))
    ]).catch(() => {}).finally(() => windQuoteRefreshBusy.delete(casino));
  };

  const publishWindQuotes = () => {
    const quoteHost = location.hostname.toLowerCase();
    if (!/(^|\.)(?:vs968|kd998)\.net$/.test(quoteHost) || !String(location.pathname || '').includes('/new_web/')) return;
    const store = findVueStore();
    if (!store) {
      document.documentElement.dataset.syncQuoteState = 'waiting-store';
      return;
    }
    const currentContext = windQuoteContext(store);
    const currentCasino = Number(store?.getters?.casino ?? store?.state?.Game?.casino);
    const seqs = Array.isArray(store?.getters?.seqs) ? store.getters.seqs : [];
    const cachedContexts = seqs
      .map((seq) => {
        const sourceName = String(seq?.name || '').trim();
        const game = sourceName.includes('539') ? '539' : /加州|California/i.test(sourceName) ? '加州彩' : '';
        return { seq, game };
      })
      .filter((item) => item.game)
      .map((seq) => ({
        casino: Number(seq.seq.casino), game: seq.game,
        phase: String(seq.seq.seq || store?.state?.Game?.betGroups?.[Number(seq.seq.casino)]?.label || '')
          .replace(/\s+/g, '')
      }));
    if (['539', '加州彩'].includes(currentContext.game)) {
      const cached = cachedContexts.find((item) => item.casino === currentCasino);
      if (cached) cached.phase = currentContext.phase || cached.phase;
      else cachedContexts.push({ casino: currentCasino, ...currentContext });
    }
    cachedContexts.forEach((item) => refreshWindCasinoQuotes(store, item.casino, currentCasino));
    document.documentElement.dataset.syncQuoteCatalog = JSON.stringify(cachedContexts.map((item) => ({
      game: item.game, casino: item.casino, phase: item.phase,
      full: store?.state?.Play01?.numbers?.[item.casino]?.length || 0,
      taihao: store?.state?.Play04?.numbers?.[item.casino]?.length || 0
    })));
    const contexts = cachedContexts.filter((item) => item.game);
    if (!contexts.length) {
      document.documentElement.dataset.syncQuoteState = 'waiting-game';
      return;
    }
    const posted = [];
    contexts.forEach(({ casino, game, phase }) => {
      const root = quoteHost.endsWith('.kd998.net') || quoteHost === 'kd998.net' ? 'kd998.net' : 'vs968.net';
      const common = { root, siteName: root === 'kd998.net' ? '喜' : '風雲', game, phase };
      const fullCarRows = casino === currentCasino && Array.isArray(store.getters.Play01Numbers)
        ? store.getters.Play01Numbers : store?.state?.Play01?.numbers?.[casino] || [];
      const fullCarQuotes = {}, fullCarDisabled = {};
      fullCarRows.forEach((row) => {
        const number = String(row?.label ?? row?.key ?? '').padStart(2, '0');
        const price = Number(row?.capital);
        if (/^(0[1-9]|[12]\d|3\d)$/.test(number) && Number.isFinite(price)) {
          fullCarQuotes[number] = price;
          fullCarDisabled[number] = Boolean(row.disabled);
        }
      });
      if (Object.keys(fullCarQuotes).length === 39) {
        window.postMessage({ type: 'SYNC_QUOTE_REPORT', report: {
          ...common, playType: '全車', unitType: 'cars', quotes: fullCarQuotes,
          disabled: fullCarDisabled, capturedAt: new Date().toISOString()
        } }, '*');
      }
      const taihaoRows = casino === currentCasino && Array.isArray(store.getters.Play04Numbers)
        ? store.getters.Play04Numbers : store?.state?.Play04?.numbers?.[casino] || [];
      const taihaoQuotes = {}, taihaoDisabled = {};
      taihaoRows.forEach((row) => {
        const number = String(row?.label ?? row?.key ?? '').padStart(2, '0');
        const price = Number(row?.capital);
        if (/^\d{2}$/.test(number) && Number.isFinite(price)) {
          taihaoQuotes[number] = price;
          taihaoDisabled[number] = Boolean(row.disabled);
        }
      });
      if (Object.keys(taihaoQuotes).length === 100) {
        window.postMessage({ type: 'SYNC_QUOTE_REPORT', report: {
          ...common, playType: '台號', unitType: 'amount', quotes: taihaoQuotes,
          disabled: taihaoDisabled, capturedAt: new Date().toISOString()
        } }, '*');
      }
      posted.push(`${game}-${Object.keys(fullCarQuotes).length}-${Object.keys(taihaoQuotes).length}`);
    });
    document.documentElement.dataset.syncQuoteState = `posted-${posted.join('_')}`;
  };

  const findWindBetComponent = (store, playType) => {
    const expected = playType === '台號' ? store?.getters?.Play04Numbers : store?.getters?.Play01Numbers;
    for (const element of document.querySelectorAll('*')) {
      let vm = element.__vue__;
      for (let depth = 0; vm && depth < 8; depth += 1, vm = vm.$parent) {
        if (vm.$refs?.info?.addBet && vm.numbers === expected) return vm;
      }
    }
    return null;
  };

  const ensureWindBetComponent = async (store, game, playType) => {
    if (windQuoteContext(store).game !== game) {
      const gameLink = [...document.querySelectorAll('a')].find((element) =>
        String(element.textContent || '').trim() === game);
      if (!gameLink) return null;
      gameLink.click();
      const gameDeadline = Date.now() + 3500;
      while (Date.now() < gameDeadline && windQuoteContext(store).game !== game) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      if (windQuoteContext(store).game !== game) return null;
    }
    let component = findWindBetComponent(store, playType);
    if (component) return component;
    // The quote data lives in Vuex, but the site's addBet component only exists
    // for the visible play page. Switch through the site's own navigation link.
    const link = [...document.querySelectorAll('a')].find((element) =>
      String(element.textContent || '').trim() === playType);
    if (!link) return null;
    link.click();
    const deadline = Date.now() + 3500;
    while (Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 100));
      const context = windQuoteContext(store);
      if (context.game === game) {
        component = findWindBetComponent(store, playType);
        if (component) return component;
      }
    }
    return null;
  };

  if (typeof window.addEventListener === 'function') window.addEventListener('message', (event) => {
    const request = event.data;
    if (event.source !== window || request?.type !== 'SYNC_WIND_CART_COMMAND' || typeof request.requestId !== 'string') return;
    const reply = (response) => window.postMessage({ type: 'SYNC_WIND_CART_RESULT', requestId: request.requestId, response }, '*');
    (async () => {
      const store = findVueStore();
      if (!store) throw new Error('風雲網站尚未就緒');
      const requestedGame = String(request.game || '');
      const playType = String(request.playType || '');
      if (!['539', '加州彩'].includes(requestedGame) || !['全車', '台號'].includes(playType)) throw new Error('遊戲或玩法無效');
      const component = await ensureWindBetComponent(store, requestedGame, playType);
      if (!component || windQuoteContext(store).game !== requestedGame) throw new Error(`風雲無法自動切換到「${requestedGame} ${playType}」頁，請重試`);
      const rows = playType === '台號' ? store.getters.Play04Numbers : store.getters.Play01Numbers;
      if (!Array.isArray(rows) || !['全車', '台號'].includes(playType)) throw new Error('目前玩法資料尚未就緒');
      const orders = Array.isArray(request.orders) ? request.orders : [];
      for (const order of orders) {
        const key = Number(order.number);
        const row = rows.find((item) => Number(item?.key) === key || Number(item?.label) === key);
        if (!row || row.disabled || Number(row.capital) !== Number(order.price)) throw new Error(`${order.number} 本金已變更或目前停押`);
        if (!(Number(order.value) > 0)) throw new Error(`${order.number} 輸入數量無效`);
      }
      if (request.command === 'PREFLIGHT') return reply({ ok: true });
      if (request.command !== 'ADD_CART') throw new Error('不支援的暫存命令');
      const carUnit = Number(store.getters.Play01CarUnit) || 1;
      for (const order of orders) {
        const key = Number(order.number);
        const row = rows.find((item) => Number(item?.key) === key || Number(item?.label) === key);
        component.$refs.info.addBet({ casino: row.casino, play: row.play, key: row.key, label: row.label,
          amount: playType === '全車' ? Math.round(Number(order.value) * carUnit) : Number(order.value) });
      }
      reply({ ok: true, count: orders.length });
    })().catch((error) => {
      reply({ ok: false, error: String(error?.message || error) });
    });
  });
  if (/(^|\.)(?:vs968|kd998)\.net$/.test(location.hostname.toLowerCase()) && String(location.pathname || '').includes('/new_web/')) {
    setTimeout(publishWindQuotes, 500);
    setInterval(publishWindQuotes, 2000);
  }

  const pollSharedLedger = async () => {
    const host = location.hostname.toLowerCase();
    if (sharedLedgerBusy || !(/(^|\.)vs968\.net$|(^|\.)kd998\.net$/.test(host))) return;
    const store = findVueStore();
    if (!store?.dispatch) {
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: 'WAIT_FRAME' } }, '*');
      return;
    }
    sharedLedgerBusy = true;
    try {
      await store.dispatch("Ledger.c520");
      const ledgerState = store.state?.Ledger || Object.values(store.state || {}).find(
        (state) => Array.isArray(state?.seqs) && state.seqs.some((seq) => "casinoLabel" in (seq || {}))
      );
      const seqs = Array.isArray(ledgerState?.seqs) ? ledgerState.seqs : [];
      for (const seq of seqs) await store.dispatch("Ledger.c533", seq.id);
      const rows = seqs.flatMap((seq) => (seq.playItems || []).map((play, sourceOrder) => ({
        gameName: String(seq.casinoLabel || "").trim(),
        phaseName: String(seq.seq || "").trim(),
        playType: String(play.label || "").trim(),
        totalAmount: Number(play.amount),
        winningAmount: Number(play.win),
        sourceOrder
      }))).filter((row) => row.gameName && row.phaseName && row.playType &&
        Number.isFinite(row.totalAmount) && Number.isFinite(row.winningAmount));
      window.postMessage({ type: "SYNC_SHARED_LEDGER_ROWS", rows }, "*");
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: rows.length ? 'OK' : 'EMPTY', count: rows.length } }, '*');
    } catch (error) {
      document.documentElement.dataset.syncLedgerError = String(error).slice(0, 300);
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: 'LEDGER_FAILED' } }, '*');
    } finally {
      sharedLedgerBusy = false;
    }
  };
  const publish = (url, method, body, contentType, response, headers = {}) => {
    if (typeof response !== "string") return;

    // 98／16／28／海勝的當日總帳使用 A07 Query JSON。28 的 API
    // 少一層 /Front/，兩種路徑都只交給總帳資料流。
    // 是不同資料流，直接交給內容腳本保存快照，不可被明細學習／重播覆蓋。
    try {
      const resolved = new URL(String(url || ""), location.href);
      if (/(?:\/api\/Front\/A07|\/api\/FrontA07)\/Query$/i.test(resolved.pathname)) {
        window.postMessage({
          type: "SYNC_LEDGER_RESPONSE",
          url: resolved.href,
          method: String(method || "GET").toUpperCase(),
          response: response.slice(0, 500000)
        }, "*");
        return;
      }
    } catch {}

    const responseLooksLikeDetail =
      response.includes("分組序號報表") ||
      response.includes("下注明細");

    // vs968 detail-list requests are the SuperGateway endpoint with the
    // list parameters observed on the bet-detail page. Do not learn/replay
    // the many other SuperGateway cmd requests (odds/status/config traffic).
    let sharedDetailGateway = false;
    try {
      const host = location.hostname.toLowerCase();
      const resolved = new URL(String(url || ""), location.href);
      sharedDetailGateway =
        (host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net")) &&
        /\/SuperGateway\.php$/i.test(resolved.pathname) &&
        resolved.searchParams.has("game_id") &&
        resolved.searchParams.has("group_id") &&
        (resolved.searchParams.get("sort") || "").toLowerCase() === "time-desc";
    } catch {}

    const usesSharedGateway = (() => {
      const host = location.hostname.toLowerCase();
      return host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net");
    })();

    // On vs968, ONLY the confirmed bet-detail list request may be learned/replayed.
    // This prevents cmd=20..., cmd=51..., odds/status/config traffic from being polled.
    if (usesSharedGateway) {
      // 風雲不同盤別可能把篩選參數放在 POST body，而不是網址列。
      // 只要是已確認的 gateway，或回應本身明確包含下注明細，就允許學習。
      if (!sharedDetailGateway && !responseLooksLikeDetail) return;
    } else if (!responseLooksLikeDetail) {
      return;
    }

    lastRequest = { url, method, body: typeof body === "string" ? body : "", contentType: contentType || "", headers };
    window.postMessage({ type: "SYNC_DETAIL_RESPONSE", url, method, body: typeof body === "string" ? body : "", contentType: contentType || "", headers, response: response.slice(0, 500000) }, "*");
  };
  const nativeFetch = window.fetch;
  window.fetch = async function(input, init = {}) {
    const response = await nativeFetch.apply(this, arguments);
    try {
      const headers = Object.fromEntries(new Headers(init.headers || {}).entries());
      const contentType = headers["content-type"] || "";
      publish(typeof input === "string" ? input : input.url, (init.method || "GET").toUpperCase(), init.body || "", contentType, await response.clone().text(), headers);
    } catch {}
    return response;
  };
  const open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send, setHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function(method, url) { this.__sync = { method: String(method || "GET").toUpperCase(), url: String(url), body: "", contentType: "", headers: {} }; return open.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) { if (this.__sync) { this.__sync.headers[String(name).toLowerCase()] = String(value); if (String(name).toLowerCase() === "content-type") this.__sync.contentType = String(value); } return setHeader.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(body) {
    if (this.__sync) this.__sync.body = typeof body === "string" ? body : "";
    this.addEventListener("load", () => { try { const r = this.__sync || {}; publish(r.url, r.method, r.body, r.contentType, this.responseText || "", r.headers || {}); } catch {} }, { once: true });
    return send.apply(this, arguments);
  };
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.data?.type === "SYNC_POLL_SHARED_LEDGER") {
      await pollSharedLedger();
      return;
    }
    if (event.data?.type === "SYNC_SET_DETAIL_REQUEST") lastRequest = event.data.request || lastRequest;
    if (event.data?.type !== "SYNC_POLL_DETAIL" || !lastRequest) return;
    try {
      const init = { method: lastRequest.method || "GET", credentials: "include", headers: lastRequest.headers || (lastRequest.contentType ? { "content-type": lastRequest.contentType } : {}) };
      if (init.method === "POST") init.body = lastRequest.body || "";
      let pollUrl = lastRequest.url;
      try {
        const u = new URL(pollUrl, location.href);
        if ((location.hostname === "vs968.net" || location.hostname.endsWith(".vs968.net")) && u.searchParams.has("_")) {
          u.searchParams.set("_", String(Date.now()));
          pollUrl = u.href;
        }
      } catch {}
      const response = await nativeFetch(pollUrl, init);
      if (!response.ok) {
        const code = [401, 403, 429].includes(response.status) ? `HTTP_${response.status}` : response.status >= 500 ? 'HTTP_5XX' : 'READ_FAILED';
        window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code } }, '*');
        return;
      }
      publish(pollUrl, init.method, lastRequest.body || "", lastRequest.contentType || "", await response.text(), lastRequest.headers || {});
    } catch {
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code: 'READ_FAILED' } }, '*');
    }
  });
})();
