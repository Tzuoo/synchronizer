(() => {
  let lastRequest = null;
  let sharedLedgerBusy = false;
  let packageBusy = false;
  let packageNextRead = 0;
  // Local structural diagnostics only: never include orders, IDs or session URLs.
  const packageDiagnostic = (stage, extra = {}) => {
    try {
      const key = window.frameElement?.name === 'sync-detail-frame' ? 'syncPackageBackground' : 'syncPackageVisible';
      const value = JSON.stringify({ stage, ...extra, at: Date.now() });
      document.documentElement.dataset[key] = value;
      window.top.document.documentElement.dataset[key] = value;
    } catch { /* Cross-origin parents must not prevent reading. */ }
  };

  // A06_0's WinNO uses the master ID (not the older ContentID API).
  // Read via the site's own Ajax manager/formatter without opening a dialog.
  const pollAmcPackages = async () => {
    if (packageBusy || Date.now() < packageNextRead || !/(^|\.)pee688\.com$/.test(location.hostname) ||
        !/\/Front\/A\/A06$/.test(location.pathname)) return;
    if (!window.ko?.contextFor || !window.$AjaxManage?.AddAjax || !window.XI?.WinNOData?.GetOrderData) {
      packageDiagnostic('dependencies', { ko: !!window.ko?.contextFor, ajax: !!window.$AjaxManage?.AddAjax, formatter: !!window.XI?.WinNOData?.GetOrderData });
      return;
    }
    packageBusy = true;
    let attempted = false;
    const clean = html => {
      const node = document.createElement('div');
      node.innerHTML = String(html || '').replace(/<br\s*\/?\s*>/gi, '\n');
      return node.textContent.replace(/\u00a0/g, ' ').trim();
    };
    const query = params => new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Package timeout')), 10000);
      window.$AjaxManage.AddAjax('/FrontA060/OrderContentQuery', {
        params, success: data => { clearTimeout(timer); resolve(data); },
        error: () => { clearTimeout(timer); reject(new Error('Package query failed')); }
      });
    });
    try {
      const seen = new Set();
      const candidates = document.querySelectorAll('td[data-bind*="Mo.OnSeeDetails"]');
      packageDiagnostic('candidates', { count: candidates.length });
      for (const cell of candidates) {
        const context = window.ko.contextFor(cell);
        const master = context?.$parent;
        const detail = context?.$data;
        if (!master?.ID || !/套餐/.test(String(master.ItemName || '')) ||
            detail?.OrderData !== '' || !Array.isArray(master.Detail) || master.Detail.length !== 1 ||
            seen.has(String(master.ID))) continue;
        seen.add(String(master.ID));
        attempted = true;
        packageDiagnostic('query');
        const table = cell.closest('table');
        if (!table) continue;
        const snapshot = table.innerText;
        const date = snapshot.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/)?.[0];
        const rows = [];
        let expected = null;
        for (let page = 1; page <= 100; page++) {
          document.documentElement.dataset.syncPackageReadingAt = String(Date.now());
          const result = await query({ ID: master.ID, PageID: page, PageSize: 15, IsShowWin: false });
          packageDiagnostic('response', { rows: Array.isArray(result?.OrderList) ? result.OrderList.length : null, totalType: typeof result?.TotalCnt, total: Number.isFinite(Number(result?.TotalCnt)) ? Number(result.TotalCnt) : null });
          if (!Array.isArray(result?.OrderList) || !Number.isInteger(result.TotalCnt) || result.TotalCnt < 1) throw new Error('Incomplete package');
          if (expected !== null && expected !== result.TotalCnt) throw new Error('Package changed');
          expected = result.TotalCnt;
          rows.push(...result.OrderList);
          if (rows.length >= expected) break;
          if (!result.OrderList.length) throw new Error('Missing package page');
        }
        if (rows.length !== expected || !cell.isConnected || table.innerText !== snapshot || !date) {
          packageDiagnostic('snapshot-rejected', { complete: rows.length === expected, connected: !!cell.isConnected, unchanged: table.innerText === snapshot, date: !!date });
          continue;
        }
        const parts = rows.map(row => ({
          name: clean(row.GroupName) + (row.ItemName ? ' ' + clean(row.ItemName) : ''),
          selection: clean(window.XI.WinNOData.GetOrderData(null, master.ItemID, row.GroupID, row.OrderData, master.GameID)),
          amount: Number(row.TotBet)
        }));
        if (parts.some(p => !p.selection || !Number.isFinite(p.amount)) ||
            parts.reduce((sum, p) => sum + p.amount, 0) !== Number(detail.TotBet)) {
          packageDiagnostic('parts-rejected', { selections: parts.every(p => !!p.selection), amounts: parts.every(p => Number.isFinite(p.amount)), sumMatches: parts.reduce((sum, p) => sum + p.amount, 0) === Number(detail.TotBet) });
          continue;
        }
        packageDiagnostic('posted');
        window.postMessage({ type: 'SYNC_AMC_PACKAGE', package: {
          id: String(master.ID), itemNumber: String(master.RowID), date,
          playType: clean(master.GroupName) + ' ' + clean(master.ItemName),
          gameText: document.body.innerText.split(snapshot)[0],
          unitAmount: Number(detail.Bet), combinationCount: Number(detail.TotCnt),
          betAmount: Number(detail.TotBet), deleted: Boolean(master.IsDelete), parts
        } }, '*');
      }
    } catch {
      // Preserve the last structural stage so a rejected response remains inspectable.
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code: 'READ_FAILED' } }, '*');
    } finally {
      packageBusy = false;
      packageNextRead = attempted ? Date.now() + 15000 : 0;
      delete document.documentElement.dataset.syncPackageReadingAt;
    }
  };
  if (/(^|\.)pee688\.com$/.test(location.hostname) && /\/Front\/A\/A06$/.test(location.pathname)) {
    packageDiagnostic('loaded');
    // Probe readiness before the background document's 10-second reload.
    // Successful attempts still have a 15-second cooldown; in-flight work is exclusive.
    setInterval(pollAmcPackages, 1000);
  }

  const findVueStore = () => {
    for (const element of document.querySelectorAll("*")) {
      let vm = element.__vue__;
      for (let depth = 0; vm && depth < 12; depth += 1, vm = vm.$parent) {
        if (vm.$store) return vm.$store;
      }
    }
    return null;
  };

  const publishWindQuotes = () => {
    if (!/(^|\.)vs968\.net$/.test(location.hostname.toLowerCase()) || !String(location.pathname || '').includes('/new_web/')) return;
    const store = findVueStore();
    const seq = store?.getters?.seq || {};
    const gameName = String(seq.name || '').trim();
    const phase = String(seq.seq || '').replace(/\s+/g, '').trim();
    if (!store || !['539', '加州彩'].includes(gameName) || !phase) return;
    const common = { root: 'vs968.net', siteName: '風雲', game: gameName, phase };
    const fullCarRows = Array.isArray(store.getters.Play01Numbers) ? store.getters.Play01Numbers : [];
    const fullCarQuotes = {}, fullCarDisabled = {};
    fullCarRows.forEach((row) => {
      const number = String(row?.label ?? row?.key ?? '').padStart(2, '0');
      const price = Number(row?.capital);
      if (/^(0[1-9]|[12]\d|3\d)$/.test(number) && Number.isFinite(price)) {
        fullCarQuotes[number] = price;
        fullCarDisabled[number] = Boolean(row.disabled);
      }
    });
    if (Object.keys(fullCarQuotes).length === 39) {
      window.postMessage({ type: 'SYNC_QUOTE_REPORT', report: {
        ...common, playType: '全車', unitType: 'cars', quotes: fullCarQuotes,
        disabled: fullCarDisabled, capturedAt: new Date().toISOString()
      } }, '*');
    }
    const taihaoRows = Array.isArray(store.getters.Play04Numbers) ? store.getters.Play04Numbers : [];
    const taihaoQuotes = {}, taihaoDisabled = {};
    taihaoRows.forEach((row) => {
      const number = String(row?.label ?? row?.key ?? '').padStart(2, '0');
      const price = Number(row?.capital);
      if (/^\d{2}$/.test(number) && Number.isFinite(price)) {
        taihaoQuotes[number] = price;
        taihaoDisabled[number] = Boolean(row.disabled);
      }
    });
    if (Object.keys(taihaoQuotes).length === 100) {
      window.postMessage({ type: 'SYNC_QUOTE_REPORT', report: {
        ...common, playType: '台號', unitType: 'amount', quotes: taihaoQuotes,
        disabled: taihaoDisabled, capturedAt: new Date().toISOString()
      } }, '*');
    }
  };
  if (/(^|\.)vs968\.net$/.test(location.hostname.toLowerCase()) && String(location.pathname || '').includes('/new_web/')) {
    setTimeout(publishWindQuotes, 500);
    setInterval(publishWindQuotes, 2000);
  }

  const pollSharedLedger = async () => {
    const host = location.hostname.toLowerCase();
    if (sharedLedgerBusy || !(/(^|\.)vs968\.net$|(^|\.)kd998\.net$/.test(host))) return;
    const store = findVueStore();
    if (!store?.dispatch) {
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: 'WAIT_FRAME' } }, '*');
      return;
    }
    sharedLedgerBusy = true;
    try {
      await store.dispatch("Ledger.c520");
      const ledgerState = store.state?.Ledger || Object.values(store.state || {}).find(
        (state) => Array.isArray(state?.seqs) && state.seqs.some((seq) => "casinoLabel" in (seq || {}))
      );
      const seqs = Array.isArray(ledgerState?.seqs) ? ledgerState.seqs : [];
      for (const seq of seqs) await store.dispatch("Ledger.c533", seq.id);
      const rows = seqs.flatMap((seq) => (seq.playItems || []).map((play, sourceOrder) => ({
        gameName: String(seq.casinoLabel || "").trim(),
        phaseName: String(seq.seq || "").trim(),
        playType: String(play.label || "").trim(),
        totalAmount: Number(play.amount),
        winningAmount: Number(play.win),
        sourceOrder
      }))).filter((row) => row.gameName && row.phaseName && row.playType &&
        Number.isFinite(row.totalAmount) && Number.isFinite(row.winningAmount));
      window.postMessage({ type: "SYNC_SHARED_LEDGER_ROWS", rows }, "*");
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: rows.length ? 'OK' : 'EMPTY', count: rows.length } }, '*');
    } catch (error) {
      document.documentElement.dataset.syncLedgerError = String(error).slice(0, 300);
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: 'LEDGER_FAILED' } }, '*');
    } finally {
      sharedLedgerBusy = false;
    }
  };
  const publish = (url, method, body, contentType, response, headers = {}) => {
    if (typeof response !== "string") return;

    // 98／16／28／海勝的當日總帳使用 A07 Query JSON。28 的 API
    // 少一層 /Front/，兩種路徑都只交給總帳資料流。
    // 是不同資料流，直接交給內容腳本保存快照，不可被明細學習／重播覆蓋。
    try {
      const resolved = new URL(String(url || ""), location.href);
      if (/(?:\/api\/Front\/A07|\/api\/FrontA07)\/Query$/i.test(resolved.pathname)) {
        window.postMessage({
          type: "SYNC_LEDGER_RESPONSE",
          url: resolved.href,
          method: String(method || "GET").toUpperCase(),
          response: response.slice(0, 500000)
        }, "*");
        return;
      }
    } catch {}

    const responseLooksLikeDetail =
      response.includes("分組序號報表") ||
      response.includes("下注明細");

    // vs968 detail-list requests are the SuperGateway endpoint with the
    // list parameters observed on the bet-detail page. Do not learn/replay
    // the many other SuperGateway cmd requests (odds/status/config traffic).
    let sharedDetailGateway = false;
    try {
      const host = location.hostname.toLowerCase();
      const resolved = new URL(String(url || ""), location.href);
      sharedDetailGateway =
        (host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net")) &&
        /\/SuperGateway\.php$/i.test(resolved.pathname) &&
        resolved.searchParams.has("game_id") &&
        resolved.searchParams.has("group_id") &&
        (resolved.searchParams.get("sort") || "").toLowerCase() === "time-desc";
    } catch {}

    const usesSharedGateway = (() => {
      const host = location.hostname.toLowerCase();
      return host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net");
    })();

    // On vs968, ONLY the confirmed bet-detail list request may be learned/replayed.
    // This prevents cmd=20..., cmd=51..., odds/status/config traffic from being polled.
    if (usesSharedGateway) {
      // 風雲不同盤別可能把篩選參數放在 POST body，而不是網址列。
      // 只要是已確認的 gateway，或回應本身明確包含下注明細，就允許學習。
      if (!sharedDetailGateway && !responseLooksLikeDetail) return;
    } else if (!responseLooksLikeDetail) {
      return;
    }

    lastRequest = { url, method, body: typeof body === "string" ? body : "", contentType: contentType || "", headers };
    window.postMessage({ type: "SYNC_DETAIL_RESPONSE", url, method, body: typeof body === "string" ? body : "", contentType: contentType || "", headers, response: response.slice(0, 500000) }, "*");
  };
  const nativeFetch = window.fetch;
  window.fetch = async function(input, init = {}) {
    const response = await nativeFetch.apply(this, arguments);
    try {
      const headers = Object.fromEntries(new Headers(init.headers || {}).entries());
      const contentType = headers["content-type"] || "";
      publish(typeof input === "string" ? input : input.url, (init.method || "GET").toUpperCase(), init.body || "", contentType, await response.clone().text(), headers);
    } catch {}
    return response;
  };
  const open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send, setHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function(method, url) { this.__sync = { method: String(method || "GET").toUpperCase(), url: String(url), body: "", contentType: "", headers: {} }; return open.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) { if (this.__sync) { this.__sync.headers[String(name).toLowerCase()] = String(value); if (String(name).toLowerCase() === "content-type") this.__sync.contentType = String(value); } return setHeader.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(body) {
    if (this.__sync) this.__sync.body = typeof body === "string" ? body : "";
    this.addEventListener("load", () => { try { const r = this.__sync || {}; publish(r.url, r.method, r.body, r.contentType, this.responseText || "", r.headers || {}); } catch {} }, { once: true });
    return send.apply(this, arguments);
  };
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.data?.type === "SYNC_POLL_SHARED_LEDGER") {
      await pollSharedLedger();
      return;
    }
    if (event.data?.type === "SYNC_SET_DETAIL_REQUEST") lastRequest = event.data.request || lastRequest;
    if (event.data?.type !== "SYNC_POLL_DETAIL" || !lastRequest) return;
    try {
      const init = { method: lastRequest.method || "GET", credentials: "include", headers: lastRequest.headers || (lastRequest.contentType ? { "content-type": lastRequest.contentType } : {}) };
      if (init.method === "POST") init.body = lastRequest.body || "";
      let pollUrl = lastRequest.url;
      try {
        const u = new URL(pollUrl, location.href);
        if ((location.hostname === "vs968.net" || location.hostname.endsWith(".vs968.net")) && u.searchParams.has("_")) {
          u.searchParams.set("_", String(Date.now()));
          pollUrl = u.href;
        }
      } catch {}
      const response = await nativeFetch(pollUrl, init);
      if (!response.ok) {
        const code = [401, 403, 429].includes(response.status) ? `HTTP_${response.status}` : response.status >= 500 ? 'HTTP_5XX' : 'READ_FAILED';
        window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code } }, '*');
        return;
      }
      publish(pollUrl, init.method, lastRequest.body || "", lastRequest.contentType || "", await response.text(), lastRequest.headers || {});
    } catch {
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code: 'READ_FAILED' } }, '*');
    }
  });
})();
