(() => {
  let lastRequest = null;
  let sharedLedgerBusy = false;

  const findVueStore = () => {
    for (const element of document.querySelectorAll("*")) {
      let vm = element.__vue__;
      for (let depth = 0; vm && depth < 12; depth += 1, vm = vm.$parent) {
        if (vm.$store) return vm.$store;
      }
    }
    return null;
  };

  const pollSharedLedger = async () => {
    const host = location.hostname.toLowerCase();
    if (sharedLedgerBusy || !(/(^|\.)vs968\.net$|(^|\.)kd998\.net$/.test(host))) return;
    const store = findVueStore();
    if (!store?.dispatch) return;
    sharedLedgerBusy = true;
    try {
      await store.dispatch("Ledger.c520");
      const ledgerState = store.state?.Ledger || Object.values(store.state || {}).find(
        (state) => Array.isArray(state?.seqs) && state.seqs.some((seq) => "casinoLabel" in (seq || {}))
      );
      const seqs = Array.isArray(ledgerState?.seqs) ? ledgerState.seqs : [];
      for (const seq of seqs) await store.dispatch("Ledger.c533", seq.id);
      const rows = seqs.flatMap((seq) => (seq.playItems || []).map((play, sourceOrder) => ({
        gameName: String(seq.casinoLabel || "").trim(),
        phaseName: String(seq.seq || "").trim(),
        playType: String(play.label || "").trim(),
        totalAmount: Number(play.amount),
        winningAmount: Number(play.win),
        sourceOrder
      }))).filter((row) => row.gameName && row.phaseName && row.playType &&
        Number.isFinite(row.totalAmount) && Number.isFinite(row.winningAmount));
      window.postMessage({ type: "SYNC_SHARED_LEDGER_ROWS", rows }, "*");
    } catch (error) {
      document.documentElement.dataset.syncLedgerError = String(error).slice(0, 300);
    } finally {
      sharedLedgerBusy = false;
    }
  };
  const publish = (url, method, body, contentType, response, headers = {}) => {
    if (typeof response !== "string") return;

    // 98／16／28／海勝的當日總帳使用 A07 Query JSON。28 的 API
    // 少一層 /Front/，兩種路徑都只交給總帳資料流。
    // 是不同資料流，直接交給內容腳本保存快照，不可被明細學習／重播覆蓋。
    try {
      const resolved = new URL(String(url || ""), location.href);
      if (/(?:\/api\/Front\/A07|\/api\/FrontA07)\/Query$/i.test(resolved.pathname)) {
        window.postMessage({
          type: "SYNC_LEDGER_RESPONSE",
          url: resolved.href,
          method: String(method || "GET").toUpperCase(),
          response: response.slice(0, 500000)
        }, "*");
        return;
      }
    } catch {}

    const responseLooksLikeDetail =
      response.includes("分組序號報表") ||
      response.includes("下注明細");

    // vs968 detail-list requests are the SuperGateway endpoint with the
    // list parameters observed on the bet-detail page. Do not learn/replay
    // the many other SuperGateway cmd requests (odds/status/config traffic).
    let sharedDetailGateway = false;
    try {
      const host = location.hostname.toLowerCase();
      const resolved = new URL(String(url || ""), location.href);
      sharedDetailGateway =
        (host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net")) &&
        /\/SuperGateway\.php$/i.test(resolved.pathname) &&
        resolved.searchParams.has("game_id") &&
        resolved.searchParams.has("group_id") &&
        (resolved.searchParams.get("sort") || "").toLowerCase() === "time-desc";
    } catch {}

    const usesSharedGateway = (() => {
      const host = location.hostname.toLowerCase();
      return host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net");
    })();

    // On vs968, ONLY the confirmed bet-detail list request may be learned/replayed.
    // This prevents cmd=20..., cmd=51..., odds/status/config traffic from being polled.
    if (usesSharedGateway) {
      // 風雲不同盤別可能把篩選參數放在 POST body，而不是網址列。
      // 只要是已確認的 gateway，或回應本身明確包含下注明細，就允許學習。
      if (!sharedDetailGateway && !responseLooksLikeDetail) return;
    } else if (!responseLooksLikeDetail) {
      return;
    }

    lastRequest = { url, method, body: typeof body === "string" ? body : "", contentType: contentType || "", headers };
    window.postMessage({ type: "SYNC_DETAIL_RESPONSE", url, method, body: typeof body === "string" ? body : "", contentType: contentType || "", headers, response: response.slice(0, 500000) }, "*");
  };
  const nativeFetch = window.fetch;
  window.fetch = async function(input, init = {}) {
    const response = await nativeFetch.apply(this, arguments);
    try {
      const headers = Object.fromEntries(new Headers(init.headers || {}).entries());
      const contentType = headers["content-type"] || "";
      publish(typeof input === "string" ? input : input.url, (init.method || "GET").toUpperCase(), init.body || "", contentType, await response.clone().text(), headers);
    } catch {}
    return response;
  };
  const open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send, setHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function(method, url) { this.__sync = { method: String(method || "GET").toUpperCase(), url: String(url), body: "", contentType: "", headers: {} }; return open.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) { if (this.__sync) { this.__sync.headers[String(name).toLowerCase()] = String(value); if (String(name).toLowerCase() === "content-type") this.__sync.contentType = String(value); } return setHeader.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(body) {
    if (this.__sync) this.__sync.body = typeof body === "string" ? body : "";
    this.addEventListener("load", () => { try { const r = this.__sync || {}; publish(r.url, r.method, r.body, r.contentType, this.responseText || "", r.headers || {}); } catch {} }, { once: true });
    return send.apply(this, arguments);
  };
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.data?.type === "SYNC_POLL_SHARED_LEDGER") {
      await pollSharedLedger();
      return;
    }
    if (event.data?.type === "SYNC_SET_DETAIL_REQUEST") lastRequest = event.data.request || lastRequest;
    if (event.data?.type !== "SYNC_POLL_DETAIL" || !lastRequest) return;
    try {
      const init = { method: lastRequest.method || "GET", credentials: "include", headers: lastRequest.headers || (lastRequest.contentType ? { "content-type": lastRequest.contentType } : {}) };
      if (init.method === "POST") init.body = lastRequest.body || "";
      let pollUrl = lastRequest.url;
      try {
        const u = new URL(pollUrl, location.href);
        if ((location.hostname === "vs968.net" || location.hostname.endsWith(".vs968.net")) && u.searchParams.has("_")) {
          u.searchParams.set("_", String(Date.now()));
          pollUrl = u.href;
        }
      } catch {}
      const response = await nativeFetch(pollUrl, init);
      publish(pollUrl, init.method, lastRequest.body || "", lastRequest.contentType || "", await response.text(), lastRequest.headers || {});
    } catch {}
  });
})();
