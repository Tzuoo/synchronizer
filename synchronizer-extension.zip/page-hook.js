(() => {
  let lastRequest = null;
  // page-hook 在 document_start 載入，content.js 則在 document_idle 才開始
  // 接收訊息。保留最後一份已確認的明細回應，讓較晚載入的內容腳本可
  // 主動補領，避免公司端剛更新／重新導向時遺失唯一一次的明細請求。
  let lastDetailResponse = null;
  let detailPollBusy = false;
  let sharedLedgerBusy = false;
  let packageBusy = false;
  let packageNextRead = 0;
  const PAGE_REQUEST_TIMEOUT_MS = 15000;
  function withPageRequestTimeout(task, timeoutMs = PAGE_REQUEST_TIMEOUT_MS, parentSignal) {
    const controller = new AbortController();
    let timer;
    let removeParentAbort = () => {};
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => {
        controller.abort();
        const error = new Error(`Request timeout after ${timeoutMs}ms`);
        error.name = 'TimeoutError';
        reject(error);
      }, timeoutMs);
    });
    const aborted = new Promise((_, reject) => {
      if (!parentSignal) return;
      const abort = () => {
        controller.abort(parentSignal.reason);
        reject(parentSignal.reason instanceof Error ? parentSignal.reason : new DOMException('Aborted', 'AbortError'));
      };
      if (parentSignal.aborted) abort();
      else {
        parentSignal.addEventListener('abort', abort, { once: true });
        removeParentAbort = () => parentSignal.removeEventListener('abort', abort);
      }
    });
    const running = Promise.resolve().then(() => task(controller.signal));
    return Promise.race([running, timeout, aborted]).finally(() => {
      clearTimeout(timer);
      removeParentAbort();
    });
  }
  function isExplicitDeleteFlag(value) {
    return value === true || value === 1 || String(value ?? '').trim() === '1';
  }
  // Local structural diagnostics only: never include orders, IDs or session URLs.
  const packageDiagnostic = (stage, extra = {}) => {
    try {
      const key = window.frameElement?.name === 'sync-detail-frame' ? 'syncPackageBackground' : 'syncPackageVisible';
      const value = JSON.stringify({ stage, ...extra, at: Date.now() });
      document.documentElement.dataset[key] = value;
      window.top.document.documentElement.dataset[key] = value;
    } catch { /* Cross-origin parents must not prevent reading. */ }
  };

  // A06_0's WinNO uses the master ID (not the older ContentID API).
  // Read via the site's own Ajax manager/formatter without opening a dialog.
  const pollAmcPackages = async () => {
    if (packageBusy || Date.now() < packageNextRead || !/(^|\.)pee688\.com$/.test(location.hostname) ||
        !/\/Front\/A\/A06$/.test(location.pathname)) return;
    if (!window.ko?.contextFor || !window.$AjaxManage?.AddAjax || !window.XI?.WinNOData?.GetOrderData) {
      packageDiagnostic('dependencies', { ko: !!window.ko?.contextFor, ajax: !!window.$AjaxManage?.AddAjax, formatter: !!window.XI?.WinNOData?.GetOrderData });
      return;
    }
    packageBusy = true;
    let attempted = false;
    const clean = html => {
      const node = document.createElement('div');
      node.innerHTML = String(html || '').replace(/<br\s*\/?\s*>/gi, '\n');
      return node.textContent.replace(/\u00a0/g, ' ').trim();
    };
    const query = params => withPageRequestTimeout(() => new Promise((resolve, reject) => {
      window.$AjaxManage.AddAjax('/FrontA060/OrderContentQuery', {
        params, success: resolve,
        error: () => reject(new Error('Package query failed'))
      });
    }), 10000);
    try {
      const seen = new Set();
      const candidates = document.querySelectorAll('td[data-bind*="Mo.OnSeeDetails"]');
      packageDiagnostic('candidates', { count: candidates.length });
      for (const cell of candidates) {
        const context = window.ko.contextFor(cell);
        const master = context?.$parent;
        const detail = context?.$data;
        if (!master?.ID || !/套餐/.test(String(master.ItemName || '')) ||
            detail?.OrderData !== '' || !Array.isArray(master.Detail) || master.Detail.length !== 1 ||
            seen.has(String(master.ID))) continue;
        seen.add(String(master.ID));
        attempted = true;
        packageDiagnostic('query');
        const table = cell.closest('table');
        if (!table) continue;
        const snapshot = table.innerText;
        const date = snapshot.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/)?.[0];
        const rows = [];
        let expected = null;
        for (let page = 1; page <= 100; page++) {
          document.documentElement.dataset.syncPackageReadingAt = String(Date.now());
          const result = await query({ ID: master.ID, PageID: page, PageSize: 15, IsShowWin: false });
          packageDiagnostic('response', { rows: Array.isArray(result?.OrderList) ? result.OrderList.length : null, totalType: typeof result?.TotalCnt, total: Number.isFinite(Number(result?.TotalCnt)) ? Number(result.TotalCnt) : null });
          if (!Array.isArray(result?.OrderList) || !Number.isInteger(result.TotalCnt) || result.TotalCnt < 1) throw new Error('Incomplete package');
          if (expected !== null && expected !== result.TotalCnt) throw new Error('Package changed');
          expected = result.TotalCnt;
          rows.push(...result.OrderList);
          if (rows.length >= expected) break;
          if (!result.OrderList.length) throw new Error('Missing package page');
        }
        if (rows.length !== expected || !cell.isConnected || table.innerText !== snapshot || !date) {
          packageDiagnostic('snapshot-rejected', { complete: rows.length === expected, connected: !!cell.isConnected, unchanged: table.innerText === snapshot, date: !!date });
          continue;
        }
        const parts = rows.map(row => ({
          name: clean(row.GroupName) + (row.ItemName ? ' ' + clean(row.ItemName) : ''),
          selection: clean(window.XI.WinNOData.GetOrderData(null, master.ItemID, row.GroupID, row.OrderData, master.GameID)),
          amount: Number(row.TotBet)
        }));
        if (parts.some(p => !p.selection || !Number.isFinite(p.amount)) ||
            parts.reduce((sum, p) => sum + p.amount, 0) !== Number(detail.TotBet)) {
          packageDiagnostic('parts-rejected', { selections: parts.every(p => !!p.selection), amounts: parts.every(p => Number.isFinite(p.amount)), sumMatches: parts.reduce((sum, p) => sum + p.amount, 0) === Number(detail.TotBet) });
          continue;
        }
        packageDiagnostic('posted');
        window.postMessage({ type: 'SYNC_AMC_PACKAGE', package: {
          id: String(master.ID), itemNumber: String(master.RowID), date,
          playType: clean(master.GroupName) + ' ' + clean(master.ItemName),
          gameText: document.body.innerText.split(snapshot)[0],
          unitAmount: Number(detail.Bet), combinationCount: Number(detail.TotCnt),
          betAmount: Number(detail.TotBet), deleted: isExplicitDeleteFlag(master.IsDelete), parts
        } }, '*');
      }
    } catch {
      // Preserve the last structural stage so a rejected response remains inspectable.
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code: 'READ_FAILED' } }, '*');
    } finally {
      packageBusy = false;
      packageNextRead = attempted ? Date.now() + 15000 : 0;
      delete document.documentElement.dataset.syncPackageReadingAt;
    }
  };
  if (/(^|\.)pee688\.com$/.test(location.hostname) && /\/Front\/A\/A06$/.test(location.pathname)) {
    packageDiagnostic('loaded');
    // Probe readiness before the background document's 10-second reload.
    // Successful attempts still have a 15-second cooldown; in-flight work is exclusive.
    setInterval(pollAmcPackages, 1000);
  }

  const findVueStore = () => {
    for (const element of document.querySelectorAll("*")) {
      let vm = element.__vue__;
      for (let depth = 0; vm && depth < 12; depth += 1, vm = vm.$parent) {
        if (vm.$store) return vm.$store;
      }
    }
    return null;
  };

  const pollSharedLedger = async (timeoutMs = PAGE_REQUEST_TIMEOUT_MS) => {
    const host = location.hostname.toLowerCase();
    if (sharedLedgerBusy || !(/(^|\.)vs968\.net$|(^|\.)kd998\.net$/.test(host))) return;
    const store = findVueStore();
    if (!store?.dispatch) {
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: 'WAIT_FRAME' } }, '*');
      return;
    }
    sharedLedgerBusy = true;
    try {
      await withPageRequestTimeout(() => store.dispatch("Ledger.c520"), timeoutMs);
      const ledgerState = store.state?.Ledger || Object.values(store.state || {}).find(
        (state) => Array.isArray(state?.seqs) && state.seqs.some((seq) => "casinoLabel" in (seq || {}))
      );
      const seqs = Array.isArray(ledgerState?.seqs) ? ledgerState.seqs : [];
      for (const seq of seqs) await withPageRequestTimeout(() => store.dispatch("Ledger.c533", seq.id), timeoutMs);
      const rows = seqs.flatMap((seq) => (seq.playItems || []).map((play, sourceOrder) => ({
        gameName: String(seq.casinoLabel || "").trim(),
        phaseName: String(seq.seq || "").trim(),
        playType: String(play.label || "").trim(),
        totalAmount: Number(play.amount),
        winningAmount: Number(play.win),
        sourceOrder
      }))).filter((row) => row.gameName && row.phaseName && row.playType &&
        Number.isFinite(row.totalAmount) && Number.isFinite(row.winningAmount));
      window.postMessage({ type: "SYNC_SHARED_LEDGER_ROWS", rows }, "*");
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: rows.length ? 'OK' : 'EMPTY', count: rows.length } }, '*');
    } catch (error) {
      document.documentElement.dataset.syncLedgerError = String(error).slice(0, 300);
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'ledger', code: 'LEDGER_FAILED' } }, '*');
    } finally {
      sharedLedgerBusy = false;
    }
  };
  const MAX_OBSERVED_RESPONSE_CHARS = 500000;
  const isSupportedOversizedObservation = (url, response) => {
    let resolved;
    try { resolved = new URL(String(url || ''), location.href); } catch { return false; }
    if (/(?:\/api\/Front\/A07|\/api\/FrontA07)\/Query$/i.test(resolved.pathname)) return true;
    const host = location.hostname.toLowerCase();
    if ((host === 'vs968.net' || host.endsWith('.vs968.net') || host === 'kd998.net' || host.endsWith('.kd998.net')) &&
        /\/SuperGateway\.php$/i.test(resolved.pathname) && resolved.searchParams.has('game_id') &&
        resolved.searchParams.has('group_id') && (resolved.searchParams.get('sort') || '').toLowerCase() === 'time-desc') return true;
    return response.includes('分組序號報表') || response.includes('下注明細');
  };
  const rejectOversizedObservedResponse = (url, response) => {
    if (response.length <= MAX_OBSERVED_RESPONSE_CHARS) return false;
    if (isSupportedOversizedObservation(url, response)) {
      window.postMessage({
        type: 'SYNC_DIAGNOSTIC_EVENT',
        event: { stage: 'parse', code: 'PARSE_FAILED' }
      }, '*');
    }
    return true;
  };
  const publish = (url, method, body, contentType, response, headers = {}) => {
    if (typeof response !== "string") return;
    if (rejectOversizedObservedResponse(url, response)) return;

    // 98／16／28／海勝的當日總帳使用 A07 Query JSON。28 的 API
    // 少一層 /Front/，兩種路徑都只交給總帳資料流。
    // 是不同資料流，直接交給內容腳本保存快照，不可被明細學習／重播覆蓋。
    try {
      const resolved = new URL(String(url || ""), location.href);
      if (/(?:\/api\/Front\/A07|\/api\/FrontA07)\/Query$/i.test(resolved.pathname)) {
        window.postMessage({
          type: "SYNC_LEDGER_RESPONSE",
          url: resolved.href,
          method: String(method || "GET").toUpperCase(),
          response
        }, "*");
        return;
      }
    } catch {}

    const responseLooksLikeDetail =
      response.includes("分組序號報表") ||
      response.includes("下注明細");

    // vs968 detail-list requests are the SuperGateway endpoint with the
    // list parameters observed on the bet-detail page. Do not learn/replay
    // the many other SuperGateway cmd requests (odds/status/config traffic).
    let sharedDetailGateway = false;
    try {
      const host = location.hostname.toLowerCase();
      const resolved = new URL(String(url || ""), location.href);
      sharedDetailGateway =
        (host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net")) &&
        /\/SuperGateway\.php$/i.test(resolved.pathname) &&
        resolved.searchParams.has("game_id") &&
        resolved.searchParams.has("group_id") &&
        (resolved.searchParams.get("sort") || "").toLowerCase() === "time-desc";
    } catch {}

    const usesSharedGateway = (() => {
      const host = location.hostname.toLowerCase();
      return host === "vs968.net" || host.endsWith(".vs968.net") || host === "kd998.net" || host.endsWith(".kd998.net");
    })();

    // On vs968, ONLY the confirmed bet-detail list request may be learned/replayed.
    // This prevents cmd=20..., cmd=51..., odds/status/config traffic from being polled.
    if (usesSharedGateway) {
      // 風雲不同盤別可能把篩選參數放在 POST body，而不是網址列。
      // 只要是已確認的 gateway，或回應本身明確包含下注明細，就允許學習。
      if (!sharedDetailGateway && !responseLooksLikeDetail) return;
    } else if (!responseLooksLikeDetail) {
      return;
    }

    lastRequest = { url, method, body: typeof body === "string" ? body : "", contentType: contentType || "", headers };
    lastDetailResponse = {
      type: "SYNC_DETAIL_RESPONSE", url, method,
      body: typeof body === "string" ? body : "", contentType: contentType || "", headers,
      response
    };
    window.postMessage(lastDetailResponse, "*");
  };
  const PASSIVE_OBSERVATION_TIMEOUT_MS = 15000;
  let passiveFetchObservation = 0;
  const latestPassiveObservation = new Map();
  function passiveObservationKey(request) {
    return [String(request.url || ''), String(request.method || 'GET'), String(request.body || '')].join('\u0000');
  }
  function finishPassiveObservation(observation) {
    observation.closed = true;
    clearTimeout(observation.timer);
    if (latestPassiveObservation.get(observation.key) === observation) latestPassiveObservation.delete(observation.key);
  }
  function beginPassiveObservation(request, timeoutMs = PASSIVE_OBSERVATION_TIMEOUT_MS) {
    const key = passiveObservationKey(request);
    const previous = latestPassiveObservation.get(key);
    if (previous) finishPassiveObservation(previous);
    const observation = { key, generation: ++passiveFetchObservation, closed: false, timer: null };
    observation.timer = setTimeout(() => finishPassiveObservation(observation), timeoutMs);
    latestPassiveObservation.set(key, observation);
    return observation;
  }
  async function observeWebsiteFetchResponse(response, request, timeoutMs = PASSIVE_OBSERVATION_TIMEOUT_MS, observation = beginPassiveObservation(request, timeoutMs)) {
    try {
      if (observation.closed) return false;
      const text = await withPageRequestTimeout(() => response.clone().text(), timeoutMs);
      if (observation.closed || latestPassiveObservation.get(observation.key) !== observation) return false;
      publish(request.url, request.method, request.body, request.contentType, text, request.headers);
      return true;
    } catch {
      return false;
    } finally {
      finishPassiveObservation(observation);
    }
  }
  const nativeFetch = window.fetch;
  window.fetch = async function(input, init = {}) {
    let request, observation;
    try {
      const headers = Object.fromEntries(new Headers(init.headers || {}).entries());
      const contentType = headers["content-type"] || "";
      request = {
        url: typeof input === "string" ? input : input.url,
        method: (init.method || "GET").toUpperCase(), body: init.body || "", contentType, headers
      };
      observation = beginPassiveObservation(request);
    } catch {}
    try {
      const response = await nativeFetch.apply(this, arguments);
      if (observation) void observeWebsiteFetchResponse(response, request, PASSIVE_OBSERVATION_TIMEOUT_MS, observation);
      return response;
    } catch (error) {
      if (observation) finishPassiveObservation(observation);
      throw error;
    }
  };
  const open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send, setHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function(method, url) { this.__sync = { method: String(method || "GET").toUpperCase(), url: String(url), body: "", contentType: "", headers: {} }; return open.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) { if (this.__sync) { this.__sync.headers[String(name).toLowerCase()] = String(value); if (String(name).toLowerCase() === "content-type") this.__sync.contentType = String(value); } return setHeader.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(body) {
    if (this.__sync) this.__sync.body = typeof body === "string" ? body : "";
    this.addEventListener("load", () => { try { const r = this.__sync || {}; publish(r.url, r.method, r.body, r.contentType, this.responseText || "", r.headers || {}); } catch {} }, { once: true });
    return send.apply(this, arguments);
  };
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.data?.type === "SYNC_REQUEST_LAST_DETAIL") {
      if (lastDetailResponse) window.postMessage(lastDetailResponse, "*");
      return;
    }
    if (event.data?.type === "SYNC_POLL_SHARED_LEDGER") {
      await pollSharedLedger();
      return;
    }
    if (event.data?.type === "SYNC_SET_DETAIL_REQUEST") lastRequest = event.data.request || lastRequest;
    if (event.data?.type !== "SYNC_POLL_DETAIL" || !lastRequest || detailPollBusy) return;
    detailPollBusy = true;
    try {
      const init = { method: lastRequest.method || "GET", credentials: "include", headers: lastRequest.headers || (lastRequest.contentType ? { "content-type": lastRequest.contentType } : {}) };
      if (init.method === "POST") init.body = lastRequest.body || "";
      let pollUrl = lastRequest.url;
      try {
        const u = new URL(pollUrl, location.href);
        if ((location.hostname === "vs968.net" || location.hostname.endsWith(".vs968.net")) && u.searchParams.has("_")) {
          u.searchParams.set("_", String(Date.now()));
          pollUrl = u.href;
        }
      } catch {}
      const { response, responseText } = await withPageRequestTimeout(async signal => {
        const response = await nativeFetch(pollUrl, { ...init, signal });
        const responseText = response.ok ? await response.text() : '';
        return { response, responseText };
      });
      if (!response.ok) {
        const code = [401, 403, 429].includes(response.status) ? `HTTP_${response.status}` : response.status >= 500 ? 'HTTP_5XX' : 'READ_FAILED';
        window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code } }, '*');
        return;
      }
      publish(pollUrl, init.method, lastRequest.body || "", lastRequest.contentType || "", responseText, lastRequest.headers || {});
    } catch {
      window.postMessage({ type: 'SYNC_DIAGNOSTIC_EVENT', event: { stage: 'read', code: 'READ_FAILED' } }, '*');
    } finally {
      detailPollBusy = false;
    }
  });
})();
