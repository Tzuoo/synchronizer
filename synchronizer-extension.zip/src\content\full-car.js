// 全車比價：只回報畫面本金，並在使用者明確操作後加入網站左側清單。
// 本模組刻意不尋找、不點擊「送出注單」。
const FULL_CAR_ROUTE = /\/Front\/B\/B02(?:$|[?#])/i;
const TAIHAO_ROUTE = /\/Front\/B\/B04(?:$|[?#])/i;
const LEGACY_QUOTE_ROUTE = /\/Front\/B\/(?:B02|B04)(?:$|[?#])/i;

function activeFullCarGame(value) {
  const match = String(value || '').match(/(?:539|天天樂)\s*[-－]\s*全車/);
  return match?.[0].replace(/\s*[-－]\s*全車/, '').trim() || '';
}

function activeLegacyQuoteContext(value) {
  const text = String(value || '');
  const match = text.match(/(539|天天樂)\s*[-－]\s*(全車|台號)/);
  if (!match || (match[1] === '天天樂' && match[2] !== '全車')) return null;
  return { game: match[1], playType: match[2] };
}

// 部分舊版網站工作框架只有 getRandomValues，沒有 randomUUID。
// 此 ID 只用於同頁訊息配對，不含帳號、下注資料或可識別資訊。
function createFullCarRequestId() {
  if (typeof crypto?.randomUUID === 'function') return crypto.randomUUID();
  const bytes = new Uint32Array(2);
  if (typeof crypto?.getRandomValues === 'function') crypto.getRandomValues(bytes);
  else { bytes[0] = Math.floor(Math.random() * 0x100000000); bytes[1] = Math.floor(Math.random() * 0x100000000); }
  return `fullcar-${Date.now().toString(36)}-${bytes[0].toString(36)}${bytes[1].toString(36)}`;
}

function readLegacyQuotePage(view = window) {
  const doc = view.document;
  const isFullCar = FULL_CAR_ROUTE.test(view.location.href);
  const isTaihao = TAIHAO_ROUTE.test(view.location.href);
  if (!isFullCar && !isTaihao) return null;
  const quoteTable = [...doc.querySelectorAll('table')].find((table) => {
    const head = String(table.rows?.[0]?.innerText || '');
    if (isFullCar) return head.includes('正碼') && head.includes('本金') && head.includes('下注金額') && table.querySelector('input.btn3[tabindex]');
    return head.includes('號碼') && head.includes('賠率') && head.includes('本金') && head.includes('金額') && table.querySelector('input');
  });
  if (!quoteTable) return null;
  const quotes = {};
  const inputs = {};
  quoteTable.querySelectorAll(isFullCar ? 'input.btn3[tabindex]' : 'input').forEach((input) => {
    const cell = input.closest('td');
    const cells = [...(cell?.parentElement?.cells || [])];
    const index = cells.indexOf(cell);
    const number = isFullCar
      ? String(input.getAttribute('tabindex') || '').padStart(2, '0')
      : String(cells[index - 1]?.innerText || '').match(/(?:^|\s)(\d{2})(?:\s|$)/)?.[1] || '';
    const priceText = isFullCar ? cells[index - 1]?.innerText : cell?.innerText;
    const price = Number(String(priceText || '').replace(/,/g, '').match(/\d+(?:\.\d+)?/)?.[0]);
    const validNumber = isFullCar ? /^(0[1-9]|[12]\d|3\d)$/ : /^\d{2}$/;
    if (validNumber.test(number) && Number.isFinite(price)) {
      quotes[number] = price;
      inputs[number] = input;
    }
  });
  if (Object.keys(quotes).length !== (isFullCar ? 39 : 100)) return null;
  const frameTexts = [];
  const visited = new Set();
  function collectSameOriginFrameText(frame, depth = 0) {
    if (!frame || visited.has(frame) || depth > 2) return;
    visited.add(frame);
    try {
      const text = frame.document?.body?.innerText || '';
      if (text) frameTexts.push(text);
      for (let index = 0; index < frame.frames.length; index += 1) collectSameOriginFrameText(frame.frames[index], depth + 1);
    } catch { /* ignore inaccessible frames */ }
  }
  collectSameOriginFrameText(window.top);
  const combinedFrameText = frameTexts.join('\n');
  // 只接受實際全車頁標題；不可從外層選單的遊戲名稱猜測盤口。
  const context = activeLegacyQuoteContext(doc.body?.innerText) || activeLegacyQuoteContext(combinedFrameText);
  if (!context || context.playType !== (isFullCar ? '全車' : '台號')) return null;
  const phase = combinedFrameText.match(/\b([A-Z]\d{5,})\s*期(?:\s|$)/)?.[1]
    || combinedFrameText.match(/\b([A-Z]\d{5,})\b/)?.[1] || '';
  const root = rootDomain(view.location.hostname);
  const siteName = root === 'and539.com' ? '海勝2' : root === 'bnd139.com' ? '金好運' : root;
  const cart = {};
  [...doc.querySelectorAll('table')].forEach((table) => {
    if (!String(table.rows?.[0]?.innerText || '').includes('刪單')) return;
    [...table.rows].slice(1).forEach((row) => {
      const cells = [...row.cells].map((cell) => cell.innerText.trim());
      if (/^(0[1-9]|[12]\d|3\d)$/.test(cells[0]) && /^\d+(?:\.\d+)?$/.test(cells[1])) cart[cells[0]] = Number(cells[1]);
    });
  });
  return { root, siteName, game: context.game, playType: context.playType, phase, quotes, inputs, cart, quoteTable };
}

function readFullCarPage(view = window) {
  const page = readLegacyQuotePage(view);
  return page?.playType === '全車' ? page : null;
}

function reportFullCarPage() {
  const page = readLegacyQuotePage();
  if (!page) return;
  chrome.runtime.sendMessage({ type: 'FULL_CAR_REPORT', report: {
    root: page.root, siteName: page.siteName, game: page.game, playType: page.playType,
    phase: page.phase, quotes: page.quotes, cart: page.cart, capturedAt: new Date().toISOString()
  } }).catch(() => {});
  // 金好運的外層網址不會因內部框架切換而變動；只把已驗證的全車工作頁
  // 告知同源外層，用隱藏框架續讀，不寫入登入前綴或任何下注內容。
  if (window.top !== window) window.top.postMessage({ type: 'SYNC_FULL_CAR_ROUTE', game: page.game, playType: page.playType, url: location.href }, location.origin);
}

// 網站以 Ajax 更新本金時，文字節點通常會直接變動；即時回報，
// 並保留 2 秒輪詢作為網站整張換表但未觸發可觀察變動時的備援。
const observedFullCarTables = new WeakSet();
function observeFullCarPriceChanges() {
  const page = readLegacyQuotePage();
  if (!page?.quoteTable || observedFullCarTables.has(page.quoteTable)) return;
  observedFullCarTables.add(page.quoteTable);
  let timer = 0;
  new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(reportFullCarPage, 120);
  }).observe(page.quoteTable, { childList: true, subtree: true, characterData: true });
}

const backgroundQuoteRoutes = new Map();
window.addEventListener('message', (event) => {
  if (window.top !== window || event.origin !== location.origin || event.data?.type !== 'SYNC_FULL_CAR_ROUTE') return;
  const game = String(event.data.game || '');
  const playType = String(event.data.playType || '全車');
  const url = String(event.data.url || '');
  let path = '';
  try { path = new URL(url, location.href).pathname; } catch { return; }
  const root = rootDomain(location.hostname);
  if (!['bnd139.com', 'and539.com'].includes(root) || !['539', '天天樂'].includes(game)
      || !['全車', '台號'].includes(playType) || !LEGACY_QUOTE_ROUTE.test(path)
      || (playType === '全車') !== FULL_CAR_ROUTE.test(path) || (game === '天天樂' && playType !== '全車')) return;
  backgroundQuoteRoutes.set(`${game}|${playType}`, { game, playType, url });
  // 第一次離開全車頁前立刻建立續讀框架；不能等下一輪 10 秒維護，
  // 否則剛切到台號時報價可能先過期而被比價頁判成離線。
  ensureBackgroundFullCar();
});

function ensureBackgroundFullCar() {
  if (window.top !== window) return;
  backgroundQuoteRoutes.forEach((route, key) => {
    let frame = [...document.querySelectorAll('iframe[data-sync-full-car]')].find((item) => item.dataset.syncQuoteKey === key);
    if (!frame) {
      frame = document.createElement('iframe');
      frame.name = `sync-quote-${route.playType === '台號' ? 'taihao' : 'full-car'}-frame`;
      frame.dataset.syncFullCar = '1';
      frame.dataset.syncQuoteKey = key;
      frame.setAttribute('aria-hidden', 'true');
      frame.style.cssText = 'position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;border:0;left:-10000px;top:-10000px';
      document.documentElement.appendChild(frame);
    }
    if (frame.dataset.syncUrl !== route.url) {
      frame.dataset.syncUrl = route.url;
      frame.src = route.url;
    }
  });
}

window.addEventListener('message', (event) => {
  if (event.source !== window || event.data?.type !== 'SYNC_QUOTE_REPORT') return;
  const report = event.data.report;
  if (!report || report.root !== rootDomain(location.hostname) || !['全車', '台號'].includes(report.playType)) return;
  chrome.runtime.sendMessage({ type: 'QUOTE_REPORT', report }).catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!['QUOTE_PREFLIGHT', 'QUOTE_ADD_CART'].includes(message?.type) || !['vs968.net', 'kd998.net'].includes(rootDomain(location.hostname))) return;
  const requestId = createFullCarRequestId();
  const timer = setTimeout(() => {
    window.removeEventListener('message', receive);
    sendResponse({ ok: false, error: '風雲暫存操作逾時' });
  }, 5000);
  function receive(event) {
    if (event.source !== window || event.data?.type !== 'SYNC_WIND_CART_RESULT' || event.data.requestId !== requestId) return;
    clearTimeout(timer);
    window.removeEventListener('message', receive);
    sendResponse(event.data.response || { ok: false, error: '風雲未回應' });
  }
  window.addEventListener('message', receive);
  window.postMessage({ type: 'SYNC_WIND_CART_COMMAND', requestId,
    command: message.type === 'QUOTE_PREFLIGHT' ? 'PREFLIGHT' : 'ADD_CART',
    game: message.game, playType: message.playType, orders: message.orders }, '*');
  return true;
});

function setSiteInputValue(input, value) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
  if (setter) setter.call(input, String(value)); else input.value = String(value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: '1' }));
}

function eachSameOriginFrame(frame, callback, depth = 0, visited = new Set()) {
  if (!frame || visited.has(frame) || depth > 3) return;
  visited.add(frame);
  try {
    callback(frame);
    for (let index = 0; index < frame.frames.length; index += 1) eachSameOriginFrame(frame.frames[index], callback, depth + 1, visited);
  } catch { /* ignore inaccessible frames */ }
}

function isBackgroundFullCarFrame(frame) {
  try { return frame.frameElement?.dataset?.syncFullCar === '1'; } catch { return true; }
}

function legacyVisibleFullCar(game, root) {
  let found = null;
  eachSameOriginFrame(window.top, (frame) => {
    if (found || isBackgroundFullCarFrame(frame)) return;
    const page = readFullCarPage(frame);
    if (page?.root === root && page.game === game) found = { frame, page };
  });
  return found;
}

function currentLegacyGame() {
  let game = '';
  eachSameOriginFrame(window.top, (frame) => {
    if (game || isBackgroundFullCarFrame(frame)) return;
    const text = String(frame.document?.body?.innerText || '');
    const match = text.match(/(?:^|\s|[-－])(539|天天樂)\s*(?:[-－]|已開盤|未開盤)/);
    if (match) game = match[1];
  });
  return game;
}

function clickLegacyFullCarNavigation(game) {
  let clicked = false;
  eachSameOriginFrame(window.top, (frame) => {
    if (clicked || isBackgroundFullCarFrame(frame)) return;
    const link = [...frame.document.querySelectorAll('a,button,input[type="button"],[onclick]')].find((element) =>
      String(element.textContent || element.value || '').trim() === '全車');
    if (link) { link.click(); clicked = true; }
  });
  if (clicked) return true;
  const route = backgroundQuoteRoutes.get(`${game}|全車`);
  if (!route) return false;
  eachSameOriginFrame(window.top, (frame) => {
    if (clicked || frame === window.top || isBackgroundFullCarFrame(frame)) return;
    try {
      if (/\/Front\/B\/B\d+(?:$|[?#])/i.test(frame.location.href)) {
        frame.location.href = route.url;
        clicked = true;
      }
    } catch { /* ignore inaccessible frames */ }
  });
  return clicked;
}

function waitForVisibleLegacyFullCar(game, root, timeout = 5000) {
  return new Promise((resolve) => {
    const startedAt = Date.now();
    const check = () => {
      const target = legacyVisibleFullCar(game, root);
      if (target) return resolve(target);
      if (Date.now() - startedAt >= timeout) return resolve(null);
      setTimeout(check, 100);
    };
    check();
  });
}

function waitForMatchingLegacyFullCar(frame, orders, timeout = 2000) {
  return new Promise((resolve) => {
    const startedAt = Date.now();
    let latest = null;
    const check = () => {
      latest = readFullCarPage(frame) || latest;
      const ready = latest && orders.every((order) => latest.quotes[order.number] === order.price
        && latest.inputs[order.number]);
      if (ready || Date.now() - startedAt >= timeout) return resolve(latest);
      setTimeout(check, 100);
    };
    check();
  });
}

function expectedCartIncrease(orders) {
  return orders.reduce((result, order) => {
    result[order.number] = (result[order.number] || 0) + Number(order.cars || 0);
    return result;
  }, {});
}

async function addLegacyVisibleFullCar(message) {
  const orders = Array.isArray(message.orders) ? message.orders : [];
  const game = String(message.game || '');
  const root = String(message.root || rootDomain(location.hostname));
  let target = legacyVisibleFullCar(game, root);
  let switched = false;
  if (!target) {
    if (currentLegacyGame() !== game) return { ok: false, error: `請先切到${game}，再由同步器自動跳到全車` };
    if (!clickLegacyFullCarNavigation(game)) return { ok: false, error: '找不到網站的全車導覽' };
    target = await waitForVisibleLegacyFullCar(game, root);
    switched = true;
  }
  if (!target) return { ok: false, error: '尚未切換到全車頁，請稍後重新比價' };
  const { frame } = target;
  const page = switched ? await waitForMatchingLegacyFullCar(frame, orders) : target.page;
  const error = orders.find((order) => page.quotes[order.number] !== order.price) ? '本金已變更，請重新比價'
    : orders.find((order) => !page.inputs[order.number] || !(Number(order.cars) > 0)) ? '號碼或車數無效' : '';
  if (error || message.command === 'PREFLIGHT') return { ok: !error, error, current: { phase: page.phase, quotes: page.quotes, cart: page.cart } };
  orders.forEach((order) => setSiteInputValue(page.inputs[order.number], order.cars));
  const addButton = [...frame.document.querySelectorAll('button,input[type="button"]')].find((button) =>
    String(button.innerText || button.value || '').trim() === '加入注單');
  if (!addButton) return { ok: false, error: '找不到加入注單按鈕' };
  const before = page.cart;
  const expected = expectedCartIncrease(orders);
  addButton.click();
  const confirmed = await new Promise((resolve) => {
    const startedAt = Date.now();
    const check = () => {
      const next = readFullCarPage(frame);
      const complete = next && Object.entries(expected).every(([number, cars]) => Number(next.cart[number] || 0) >= Number(before[number] || 0) + cars);
      if (complete) return resolve(next);
      if (Date.now() - startedAt >= 2000) return resolve(null);
      setTimeout(check, 100);
    };
    check();
  });
  if (!confirmed) return { ok: false, error: '網站未確認左側清單已更新，未回報加入成功' };
  chrome.runtime.sendMessage({ type: 'FULL_CAR_REPORT', report: {
    root: confirmed.root, siteName: confirmed.siteName, game: confirmed.game, playType: confirmed.playType,
    phase: confirmed.phase, quotes: confirmed.quotes, cart: confirmed.cart, capturedAt: new Date().toISOString()
  } }).catch(() => {});
  return { ok: true, count: orders.length };
}

function delegateLegacyVisibleFullCar(message, sendResponse) {
  const requestId = createFullCarRequestId();
  const timer = setTimeout(() => {
    window.removeEventListener('message', receive);
    sendResponse({ ok: false, error: '網站暫存操作逾時' });
  }, 7000);
  function receive(event) {
    if (event.source !== window.top || event.data?.type !== 'SYNC_BND_VISIBLE_FULL_CAR_RESULT' || event.data.requestId !== requestId) return;
    clearTimeout(timer);
    window.removeEventListener('message', receive);
    sendResponse(event.data.response || { ok: false, error: '網站未回應暫存結果' });
  }
  window.addEventListener('message', receive);
  window.top.postMessage({ type: 'SYNC_BND_VISIBLE_FULL_CAR_COMMAND', requestId,
    command: message.type === 'FULL_CAR_PREFLIGHT' ? 'PREFLIGHT' : 'ADD_CART', root: message.root,
    game: message.game, orders: message.orders }, location.origin);
}

window.addEventListener('message', (event) => {
  if (window.top !== window || event.origin !== location.origin || event.data?.type !== 'SYNC_BND_VISIBLE_FULL_CAR_COMMAND') return;
  addLegacyVisibleFullCar(event.data).then((response) => {
    event.source?.postMessage({ type: 'SYNC_BND_VISIBLE_FULL_CAR_RESULT', requestId: event.data.requestId, response }, event.origin);
  }).catch((error) => {
    event.source?.postMessage({ type: 'SYNC_BND_VISIBLE_FULL_CAR_RESULT', requestId: event.data.requestId,
      response: { ok: false, error: String(error?.message || error) } }, event.origin);
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!['FULL_CAR_PREFLIGHT', 'FULL_CAR_ADD_CART'].includes(message?.type)) return;
  // 舊版網站的隱藏報價框架不持有使用者可見頁面的左側清單狀態。
  // 一律委派給最外層，在目前可見的工作框架確認清單真的增加後才回報成功。
  if (['bnd139.com', 'and539.com'].includes(rootDomain(location.hostname)) && window.top !== window) {
    delegateLegacyVisibleFullCar(message, sendResponse);
    return true;
  }
  const page = readFullCarPage();
  if (!page || page.root !== message.root || (message.game && page.game !== message.game) || (message.playType && page.playType !== message.playType)) return;
  const orders = Array.isArray(message.orders) ? message.orders : [];
  const error = orders.find((order) => page.quotes[order.number] !== order.price) ? '本金已變更，請重新比價'
    : orders.find((order) => !page.inputs[order.number] || !(Number(order.cars) > 0)) ? '號碼或車數無效'
    : '';
  if (error || message.type === 'FULL_CAR_PREFLIGHT') {
    sendResponse({ ok: !error, error, current: { phase: page.phase, quotes: page.quotes, cart: page.cart } });
    return;
  }
  try {
    orders.forEach((order) => setSiteInputValue(page.inputs[order.number], order.cars));
    const addButton = [...document.querySelectorAll('button,input[type="button"]')].find((button) =>
      String(button.innerText || button.value || '').trim() === '加入注單');
    if (!addButton) throw new Error('找不到加入注單按鈕');
    addButton.click();
    setTimeout(() => {
      reportFullCarPage();
      sendResponse({ ok: true, count: orders.length });
    }, 300);
    return true;
  } catch (errorValue) {
    sendResponse({ ok: false, error: String(errorValue?.message || errorValue) });
  }
});

if (LEGACY_QUOTE_ROUTE.test(location.href)) {
  setTimeout(() => { observeFullCarPriceChanges(); reportFullCarPage(); }, 300);
  setInterval(() => { observeFullCarPriceChanges(); reportFullCarPage(); }, 2000);
}

if (window.top === window) setInterval(ensureBackgroundFullCar, 10000);
