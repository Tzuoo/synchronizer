function scrapeAmcOrders(root = document) {
  if (
    !["amc283.com", "pee688.com"].includes(rootDomain(location.hostname))
  ) {
    return [];
  }

  // 與 98 / 16 / 28 / 海勝共用柱碰 DOM 解析。
  // 長柱完整從下注內容欄位讀取，並直接讀網站的每碰金額／碰數／下注金額。
  const directPillarOrders = scrapeCommonPillarRows(root);

  const hostname =
    location.hostname.toLowerCase();

  const pageText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  const textOrders = [...directPillarOrders];

  const blocks =
    pageText.split(
      /單項金額總計/
    );

  let activeGameSection = "";

  for (
    let index = 0;
    index < blocks.length - 1;
    index++
  ) {
    const block =
      blocks[index];

    activeGameSection = gameSectionFromText(block, activeGameSection);

    const next =
      blocks[index + 1];

    const time =
      block.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    const play =
      block.match(
        /(全車(?:\s*單碰)?|特碼(?:\s*單碰)?|[二三四五星]星\s*(?:連柱碰|柱碰|連碰)|台號|特尾\S*|套餐|自選不中|雙面|快速輸入)/
      );

    const summary =
      next.match(
        /^\s*(\d+(?:\.\d+)?)(?:\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\))?/
      );

    if (
      !time ||
      !play ||
      !summary
    ) {
      continue;
    }

    const event =
      play[1].replace(
        /\s+/g,
        ""
      );

    const total =
      Number(summary[1]);

    const placedAt =
      `${time[0]
        .replace(/\//g, "-")
        .replace(/\s+/, "T")}+08:00`;
    const itemNumber = itemNumberFromOrderContext(root, time[0], event);

    // 同頁可同時出現柱碰、連碰、全車與單碰。柱碰採 DOM 結果，
    // 其餘玩法仍繼續解析，避免因一批柱碰讓整頁提早結束。
    if (
      /柱碰/.test(event) &&
      directPillarOrders.some(
        (order) =>
          String(order.placedAt || "").replace(/\s+/g, "T") ===
            String(placedAt || "").replace(/\s+/g, "T") &&
          order.event === event
      )
    ) {
      continue;
    }

    if (/^特尾三/.test(event)) {
      const items = [
        ...block.matchAll(
          /(?:^|\s)(\d{3})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      const selections = items
        .map((item) => `${item[1]} ${Number(item[2])}`)
        .join("、");

      textOrders.push(
        enrichedBet(
          {
            id: `${hostname}|text-order|${time[0]}|特尾三單碰|${selections}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, "特尾三單碰"),
            selection: selections,
            odds: null,
            stake: total,
            potentialPayout: total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            itemNumber,
            playType: "特尾三單碰",
            unitAmount: null,
            combinationCount: null,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    } else if (/^特碼/.test(event)) {
      // 航海的特碼單碰是一個號碼一列：
      // 下注內容、賠率、本金、下注金額、中獎、退水漲跌、退水金額、小計。
      // 只保留實際的「號碼 + 下注金額」，其他欄位不送到同步器。
      const items = [
        ...block.matchAll(
          /(?:^|\s)(\d{1,2})\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      const selections = items
        .map((item) => `${item[1].padStart(2, "0")} ${Number(item[4])}`)
        .join("、");

      textOrders.push(
        enrichedBet(
          {
            id: `${hostname}|text-order|${time[0]}|特碼單碰|${selections}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, "特碼單碰"),
            selection: selections,
            odds: null,
            stake: total,
            potentialPayout: total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            itemNumber,
            playType: "特碼單碰",
            unitAmount: null,
            combinationCount: null,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    } else if (/^全車/.test(event)) {
      const items = [];

      const itemPattern =
        /(?:^|\s)(\d{1,2})\s+(?:\d+(?:\.\d+)?)\s+(?:\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s*\(\s*(\d+(?:\.\d+)?)\s*車/g;

      for (
        const match of block.matchAll(
          itemPattern
        )
      ) {
        items.push({
          line:
            `${match[1].padStart(2, "0")} ${Number(match[3])}車`,
          cars:
            Number(match[3])
        });
      }

      if (!items.length) {
        continue;
      }

      const selections =
        [
          ...new Set(
            items.map(
              (item) =>
                item.line
            )
          )
        ].join("、");

      const cars =
        Number(summary[2]) ||
        items.reduce(
          (sum, item) =>
            sum + item.cars,
          0
        );

      textOrders.push(
        enrichedBet(
          {
            id:
              `${hostname}|text-order|${time[0]}|${event}|${selections}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, event === "全車" ? "全車單碰" : event),
            selection:
              selections,
            odds: null,
            stake: cars,
            potentialPayout:
              total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            itemNumber,
            playType:
              event === "全車"
                ? "全車單碰"
                : event,
            unitAmount: null,
            carCount: cars,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    } else {
      const numberMatches = [
        ...block.matchAll(
          /\d{1,2}(?:\s*,\s*\d{1,2})+/g
        )
      ];

      const numberMatch =
        numberMatches.at(-1);

      if (!numberMatch) {
        continue;
      }

      // 連柱碰會先列出各行下注號碼，再以「碰」列出碰撞號碼。
      // 必須保存全部原始分組，不能只取最後一行，也不能自行改成柱碰或連碰。
      const selection = /連柱碰/.test(event)
        ? numberMatches.map((match, matchIndex) => {
            const numbers = match[0].replace(/\s*,\s*/g, ", ").trim();
            return matchIndex === numberMatches.length - 1 ? `碰 ${numbers}` : numbers;
          }).join("、")
        : numberMatch[0].replace(
            /\s*,\s*/g,
            ", "
          );

      const tail =
        block.slice(
          (numberMatch.index || 0) +
          numberMatch[0].length
        );

      const values = [
        ...tail.matchAll(
          /\d+(?:\.\d+)?/g
        )
      ].map(
        (value) =>
          Number(value[0])
      );

      const totalIndex =
        values.lastIndexOf(total);

      const eachAmount =
        totalIndex >= 2
          ? values[
              totalIndex - 2
            ]
          : total;

      const comboCount = /連柱碰/.test(event) && totalIndex >= 1
        ? values[totalIndex - 1]
        : combinationCountFor(
            event,
            selection
          );

      textOrders.push(
        enrichedBet(
          {
            id:
              `${hostname}|text-order|${time[0]}|${event}|${selection}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, event),
            selection,
            odds: null,
            stake: eachAmount,
            potentialPayout:
              total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            itemNumber,
            playType: event,
            unitAmount:
              eachAmount,
            combinationCount:
              comboCount,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    }
  }

  if (textOrders.length) {
    return textOrders;
  }

  const rows = [
    ...root.querySelectorAll("tr")
  ];

  const orders = [];

  let current = null;

  const flush = () => {
    if (
      !current ||
      !current.time ||
      !current.items.length ||
      !current.stake
    ) {
      return;
    }

    const selections =
      current.items
        .map(
          (item) =>
            `${item.number} ${item.unit}`
        )
        .join("、");

    orders.push(
      enrichedBet(
        {
          id:
            `${hostname}|order|${current.time}|${current.play}|${selections}|${current.stake}`,
          source: "航海",
          account: "",
          placedAt:
            `${current.time.replace(" ", "T")}+08:00`,
          event:
            current.play,
          selection:
            `${current.play} ${selections}`,
          odds:
            current.odds,
          stake:
            current.stake,
          potentialPayout:
            null,
          status:
            current.status || "待結算",
          result:
            null,
          reconciled:
            false
        },
        {
          playType:
            current.play,
          unitAmount:
            current.stake,
          betAmount:
            current.stake,
          rawText:
            selections,
          parseStatus:
            "partial"
        }
      )
    );
  };

  for (
    const row of rows
  ) {
    const cells = [
      ...row.querySelectorAll(
        "td,th"
      )
    ]
      .map(closestText)
      .filter(Boolean);

    const line =
      cells.join(" ");

    const dateTime =
      line.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    if (dateTime) {
      flush();

      const play =
        cells.find(
          (cell) =>
            /全車|二三四星|台號|特尾|套餐|自選不中|雙面|快速/.test(cell)
        ) ||
        "下注";

      current = {
        time:
          dateTime[0].replace(/\//g, "-"),
        play,
        items: [],
        stake: 0,
        odds: null,
        status: orderStatusFromText(line)
      };
    }

    if (!current) {
      continue;
    }

    if (orderStatusFromText(line) !== "待結算") {
      current.status = orderStatusFromText(line);
    }

    const unitMatch =
      line.match(
        /(\d+(?:\.\d+)?)\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\)/
      );

    if (
      unitMatch &&
      !line.includes("單項金額總計")
    ) {
      const numberCell =
        cells.find(
          (cell) =>
            /^\d{1,2}(?:\s+\d{1,2})*$/.test(cell)
        );

      const numbers =
        numberCell
          ? numberCell.match(
              /\b\d{1,2}\b/g
            ) || []
          : [];

      numbers.forEach(
        (number) => {
          const unit =
            `${unitMatch[2]}車`;

          if (
            !current.items.some(
              (item) =>
                item.number === number &&
                item.unit === unit
            )
          ) {
            current.items.push({
              number,
              unit
            });
          }
        }
      );

      const odds =
        cells
          .map(numeric)
          .find(
            (value) =>
              value &&
              value > 1 &&
              value < 10000
          );

      if (odds) {
        current.odds = odds;
      }
    }

    if (
      line.includes(
        "單項金額總計"
      )
    ) {
      const total =
        line.match(
          /(\d+(?:\.\d+)?)\s*\(/
        );

      if (total) {
        current.stake =
          Number(total[1]);
      }

      flush();

      current = null;
    }
  }

  flush();

  return orders;
}

