const SITE_NAMES = {
  "vs968.net": "風雲", "hyp98.com": "98", "kd998.net": "喜", "cj3688.com": "喜代",
  "188hot.net": "16", "bnd139.com": "28",
  "umh693.com": "海勝", "amc283.com": "航海", "pee688.com": "航海", "sk6688.net": "sk6688",
  "nan688.com": "nan688", "la688.com": "la688", "jgm258.com": "jgm258",
  "bnm988.com": "bnm988"
};

// 供實際網頁診斷目前載入的擴充版本，不會顯示在使用者畫面。
document.documentElement.dataset.syncExtensionVersion =
  chrome.runtime.getManifest().version;

const HOST_NAMES = {
  "www.vs968.net": "風雲",
  "www.hyp98.com": "98",
  "w1.hyp98.com": "98",
  "w0.188hot.net": "16"
};

function rootDomain(hostname) {
  const parts = hostname.split(".");
  return parts.slice(-2).join(".");
}

function accountFromDocument(root) {
  const value = (root?.body?.innerText || root?.body?.textContent || "")
    .replace(/\u00a0/g, " ");
  const match = value.match(
    /(?:會員\s*)?(?:帳號|账号)\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9._-]{1,31})/i
  );
  return match?.[1] || "";
}

function detectActualAccount() {
  let current = window;
  for (let depth = 0; depth < 12; depth += 1) {
    try {
      const account = accountFromDocument(current.document);
      if (account) return account;
      if (current.parent === current) break;
      current = current.parent;
    } catch {
      break;
    }
  }
  return "";
}

let lastReportedAccount = "";

function reportActualAccount() {
  const account = detectActualAccount();
  if (!account || account === lastReportedAccount) return account;
  lastReportedAccount = account;
  safeMessage({ type: "REGISTER_ACTUAL_ACCOUNT", account });
  return account;
}

function text(node, selector) {
  return (node.querySelector(selector)?.textContent || "").trim();
}

function numeric(value) {
  const parsed = Number(String(value).replace(/[^0-9.-]/g, ""));
  return Number.isFinite(parsed) ? parsed : null;
}

function starCountFor(play) {
  return ({ "二": 2, "三": 3, "四": 4, "五": 5 })[String(play || "")[0]] || null;
}

function parsePillarsFromText(value) {
  const raw = String(value || "")
    .replace(/\u00a0/g, " ")
    .replace(/，/g, ",");
  const markers = [...raw.matchAll(/第\s*(\d{1,2})\s*柱/g)];
  const pillars = [];

  for (let i = 0; i < markers.length; i++) {
    const marker = markers[i];
    const start = (marker.index || 0) + marker[0].length;
    const end = i + 1 < markers.length ? markers[i + 1].index : raw.length;
    const segment = raw.slice(start, end);
    const numbers = (segment.match(/\b\d{1,2}\b/g) || [])
      .map((n) => Number(n))
      .filter((n) => n >= 1 && n <= 49);

    if (numbers.length) {
      pillars.push({
        index: Number(marker[1]),
        numbers
      });
    }
  }

  return pillars;
}

function formatPillarSelection(value) {
  const pillars = parsePillarsFromText(value);
  if (!pillars.length) return "";

  // 同步器畫面欄寬有限；柱碰改成逐柱換行，
  // 長柱每 10 個號碼再換一行，避免文字溢出到右側欄位。
  return pillars
    .map((pillar) => {
      const prefix = `第${String(pillar.index).padStart(2, "0")}柱 `;
      const nums = pillar.numbers.map((n) => String(n).padStart(2, "0"));
      const chunks = [];
      for (let i = 0; i < nums.length; i += 10) {
        chunks.push(nums.slice(i, i + 10).join(", "));
      }
      return prefix + chunks.join("\n      ");
    })
    .join("\n");
}

function pillarCombinationCountFor(play, selection) {
  const star = starCountFor(play);
  if (!star || !/柱碰/.test(String(play || ""))) return null;

  const sizes = parsePillarsFromText(selection).map((pillar) => pillar.numbers.length);
  if (sizes.length < star) return null;

  // 柱碰：從不同柱選 star 柱，各柱各取 1 號。
  // 例如二星柱碰 2/2/4 = 2*2 + 2*4 + 2*4 = 20 碰；
  // 三星柱碰 2/2/4 = 2*2*4 = 16 碰。
  const dp = Array(star + 1).fill(0);
  dp[0] = 1;
  for (const size of sizes) {
    for (let k = star; k >= 1; k--) {
      dp[k] += dp[k - 1] * size;
    }
  }
  return dp[star] || null;
}

function combinationCountFor(play, selection) {
  if (/柱碰/.test(String(play || ""))) {
    return pillarCombinationCountFor(play, selection);
  }

  const nums = (String(selection || "").match(/\b\d{1,2}\b/g) || []).length;
  const star = starCountFor(play);
  if (!star || !/連碰/.test(String(play || "")) || nums < star) return null;

  let result = 1;
  for (let i = 1; i <= star; i++) {
    result = result * (nums - star + i) / i;
  }

  return Math.round(result);
}


function orderStatusFromText(...values) {
  const value = values
    .filter((item) => item != null)
    .map((item) => String(item))
    .join(" ")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (/已\s*刪\s*單|刪\s*單|已\s*刪\s*除|已\s*删\s*除|deleted/i.test(value)) {
    return "已刪單";
  }

  if (/已\s*取\s*消|已\s*撤\s*單|cancelled|canceled/i.test(value)) {
    return "已取消";
  }

  return "待結算";
}

function enrichedBet(base, extra = {}) {
  return {
    ...base,
    itemNumber: extra.itemNumber == null ? null : String(extra.itemNumber).trim(),
    playType: extra.playType ?? base.event ?? null,
    unitAmount: extra.unitAmount ?? null,
    combinationCount: extra.combinationCount ?? null,
    carCount: extra.carCount ?? null,
    betAmount: extra.betAmount ?? base.potentialPayout ?? base.stake ?? null,
    principal: extra.principal ?? null,
    rawText: extra.rawText ?? "",
    parseStatus: extra.parseStatus ?? "parsed",
  };
}

function exactItemNumber(value) {
  const match = String(value || "").trim().match(/^(?:項次\s*[:：]?\s*)?(\d{1,5})$/);
  return match ? match[1] : null;
}

function itemNumberFromOrderContext(root, dateTime, playType) {
  const date = String(dateTime || "").replace(/\//g, "-").trim();
  const dateKey = date.replace(/\s+/g, "");
  const play = String(playType || "").replace(/\s+/g, "").trim();
  if (!dateKey || !play) return null;
  for (const cell of root.querySelectorAll("td,th")) {
    const itemNumber = exactItemNumber(cell.innerText || cell.textContent);
    if (!itemNumber) continue;
    const rowText = (cell.closest("tr")?.innerText || cell.closest("tr")?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/\//g, "-");
    const rowKey = rowText.replace(/\s+/g, "");
    if (rowKey.includes(dateKey) && rowKey.includes(play)) return itemNumber;
  }
  return null;
}

function gameSectionFromText(value, fallback = "") {
  const matches = [...String(value || "").matchAll(/【\s*([^】]+?)\s*】\s*第\s*[^\s】]+\s*期/g)];
  return matches.length ? matches.at(-1)[1].trim() : fallback;
}

function eventWithGameSection(gameSection, playType) {
  const game = String(gameSection || "").trim();
  const play = String(playType || "").trim();
  return game && play ? `${game} / ${play}` : play;
}

function safeMessage(message) {
  try {
    if (!chrome?.runtime?.id) return Promise.resolve();
    return chrome.runtime.sendMessage(message).catch(() => {});
  } catch {
    return Promise.resolve();
  }
}

