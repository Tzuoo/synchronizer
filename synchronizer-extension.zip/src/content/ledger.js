function taiwanDateKey(value = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Taipei",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(value);
}

function parseA07LedgerResponse(responseText, capturedAt = new Date()) {
  const root = rootDomain(location.hostname);
  if (!["hyp98.com", "188hot.net", "bnd139.com", "umh693.com", "and539.com", "pee688.com"].includes(root)) return [];

  let payload;
  try {
    payload = JSON.parse(String(responseText || ""));
  } catch {
    return [];
  }

  const games = Array.isArray(payload) ? payload : [payload];
  const source = SITE_NAMES[root] || root;
  const date = taiwanDateKey(capturedAt);
  const capturedAtIso = capturedAt.toISOString();
  const rows = [];

  const amount = (value) => {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  };

  for (const game of games) {
    const gameName = String(game?.GameName || "").trim();
    const periods = Array.isArray(game?.DataList) ? game.DataList : [];

    for (const period of periods) {
      const phaseName = String(period?.PhaseName || period?.PhasesName || "").trim();
      const groups = Array.isArray(period?.DataList) ? period.DataList : [];

      for (const group of groups) {
        const playType = String(group?.GroupName || "").trim();
        const totalAmount = amount(group?.TotBet);
        const winningAmount = amount(group?.TotBetWinLose);
        if (!gameName || !phaseName || !playType || totalAmount == null || winningAmount == null) continue;

        rows.push({
          date,
          source,
          account: "",
          gameName,
          phaseName,
          playType,
          totalAmount,
          winningAmount,
          capturedAt: capturedAtIso,
          parseStatus: "parsed"
        });
      }
    }
  }

  return rows;
}

function normalizeLedgerPhaseName(value) {
  const text = String(value || "").replace(/[>＞]\s*$/, "").trim();
  const match = text.match(/^第\s*(.+?)\s*期$/);
  return match ? match[1].trim() : text;
}

function scrapeSharedLedger(root = document, capturedAt = new Date()) {
  const domain = rootDomain(location.hostname);
  if (!["kd998.net", "vs968.net"].includes(domain)) return [];
  const ledger = root.querySelector("#ledger_01");
  if (!ledger) return [];

  const clean = (node) => (node?.innerText || node?.textContent || "")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const labels = [...ledger.querySelectorAll(".tr.tr-head .th")].map(clean);
  const nameIndex = labels.findIndex((value) => value === "名稱");
  const totalIndex = labels.findIndex((value) => value === "總量");
  const winningIndex = labels.findIndex((value) => value === "中獎");
  if (nameIndex < 0 || totalIndex < 0 || winningIndex < 0) return [];

  const source = SITE_NAMES[domain];
  const date = taiwanDateKey(capturedAt);
  const capturedAtIso = capturedAt.toISOString();
  const rows = [];

  for (const row of ledger.querySelectorAll(".tr.tr-body")) {
    const cells = [...row.children];
    const phaseName = normalizeLedgerPhaseName(clean(cells[0]));
    const playType = clean(cells[nameIndex]);
    const totalAmount = numeric(clean(cells[totalIndex]));
    const winningAmount = numeric(clean(cells[winningIndex]));
    const group = row.closest(".bet_group.f_group");
    const gameName = clean(group?.querySelector(":scope > .panel_title"));
    if (!gameName || !phaseName || !playType || totalAmount == null || winningAmount == null) continue;

    rows.push({
      date,
      source,
      account: "",
      gameName,
      phaseName,
      playType,
      totalAmount,
      winningAmount,
      capturedAt: capturedAtIso,
      parseStatus: "parsed"
    });
  }

  return rows;
}

function storeLedgerSnapshot(rows) {
  if (!rows.length) return;
  const actualAccount = reportActualAccount();
  safeMessage({
    type: "STORE_LEDGER_SNAPSHOT",
    rows: rows.map((row) => actualAccount ? { ...row, account: actualAccount } : row)
  });
}

window.addEventListener('message', (event) => {
  if (event.source !== window || event.data?.type !== 'SYNC_DIAGNOSTIC_EVENT') return;
  const value = event.data.event;
  if (!value || !['read', 'ledger'].includes(value.stage)) return;
  safeMessage({ type: 'SITE_DIAGNOSTIC', state: { event: { stage: value.stage, code: value.code, count: value.count } } });
});

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.type !== "SYNC_LEDGER_RESPONSE") return;
  try {
    const url = new URL(event.data.url, location.href);
    if (url.origin !== location.origin || !/(?:\/api\/Front\/A07|\/api\/FrontA07)\/Query$/i.test(url.pathname)) return;
    const rows = parseA07LedgerResponse(event.data.response || "");
    safeMessage({ type: 'SITE_DIAGNOSTIC', state: { event: { stage: 'ledger', code: rows.length ? 'OK' : 'EMPTY', count: rows.length } } });
    document.documentElement.dataset.syncLedgerCount = String(rows.length);
    storeLedgerSnapshot(rows);
  } catch {}
});

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.type !== "SYNC_SHARED_LEDGER_ROWS") return;
  const root = rootDomain(location.hostname);
  if (!["vs968.net", "kd998.net"].includes(root) || !Array.isArray(event.data.rows)) return;
  const capturedAt = new Date();
  const rows = event.data.rows.map((row) => ({
    date: taiwanDateKey(capturedAt),
    source: SITE_NAMES[root] || root,
    account: "",
    gameName: String(row.gameName || "").trim(),
    phaseName: normalizeLedgerPhaseName(row.phaseName),
    playType: String(row.playType || "").trim(),
    totalAmount: Number(row.totalAmount),
    winningAmount: Number(row.winningAmount),
    capturedAt: capturedAt.toISOString(),
    parseStatus: "parsed"
  })).filter((row) => row.gameName && row.phaseName && row.playType &&
    Number.isFinite(row.totalAmount) && Number.isFinite(row.winningAmount));
  document.documentElement.dataset.syncLedgerCount = String(rows.length);
  storeLedgerSnapshot(rows);
});

function syncLedgerDom() {
  const rows = scrapeSharedLedger();
  document.documentElement.dataset.syncLedgerCount = String(rows.length);
  storeLedgerSnapshot(rows);
}

setInterval(syncLedgerDom, 10000);
syncLedgerDom();
