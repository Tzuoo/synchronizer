// 539 全車比價第一階段：只回報畫面本金，並在使用者明確操作後加入網站左側清單。
// 本模組刻意不尋找、不點擊「送出注單」。
function readFullCarPage() {
  if (!/\/Front\/B\/B02(?:$|[?#])/i.test(location.href)) return null;
  const quoteTable = [...document.querySelectorAll('table')].find((table) => {
    const head = String(table.rows?.[0]?.innerText || '');
    return head.includes('正碼') && head.includes('本金') && head.includes('下注金額') && table.querySelector('input.btn3[tabindex]');
  });
  if (!quoteTable) return null;
  const quotes = {};
  const inputs = {};
  quoteTable.querySelectorAll('input.btn3[tabindex]').forEach((input) => {
    const number = String(input.getAttribute('tabindex') || '').padStart(2, '0');
    const cell = input.closest('td');
    const cells = [...(cell?.parentElement?.cells || [])];
    const index = cells.indexOf(cell);
    const price = Number(String(cells[index - 1]?.innerText || '').replace(/,/g, '').trim());
    if (/^(0[1-9]|[12]\d|3\d)$/.test(number) && Number.isFinite(price)) {
      quotes[number] = price;
      inputs[number] = input;
    }
  });
  if (Object.keys(quotes).length !== 39) return null;
  const frameTexts = [];
  const visited = new Set();
  function collectSameOriginFrameText(frame, depth = 0) {
    if (!frame || visited.has(frame) || depth > 2) return;
    visited.add(frame);
    try {
      const text = frame.document?.body?.innerText || '';
      if (text) frameTexts.push(text);
      for (let index = 0; index < frame.frames.length; index += 1) collectSameOriginFrameText(frame.frames[index], depth + 1);
    } catch { /* ignore inaccessible frames */ }
  }
  collectSameOriginFrameText(window.top);
  const combinedFrameText = frameTexts.join('\n');
  const phase = combinedFrameText.match(/\b([A-Z]\d{5,})\s*期(?:\s|$)/)?.[1]
    || combinedFrameText.match(/\b([A-Z]\d{5,})\b/)?.[1] || '';
  const root = rootDomain(location.hostname);
  const siteName = root === 'and539.com' ? '海勝2' : root === 'bnd139.com' ? '金好運' : root;
  const cart = {};
  [...document.querySelectorAll('table')].forEach((table) => {
    if (!String(table.rows?.[0]?.innerText || '').includes('刪單')) return;
    [...table.rows].slice(1).forEach((row) => {
      const cells = [...row.cells].map((cell) => cell.innerText.trim());
      if (/^(0[1-9]|[12]\d|3\d)$/.test(cells[0]) && /^\d+(?:\.\d+)?$/.test(cells[1])) cart[cells[0]] = Number(cells[1]);
    });
  });
  return { root, siteName, game: '539', playType: '全車', phase, quotes, inputs, cart };
}

function reportFullCarPage() {
  const page = readFullCarPage();
  if (!page) return;
  chrome.runtime.sendMessage({ type: 'FULL_CAR_REPORT', report: {
    root: page.root, siteName: page.siteName, game: page.game, playType: page.playType,
    phase: page.phase, quotes: page.quotes, cart: page.cart, capturedAt: new Date().toISOString()
  } }).catch(() => {});
}

window.addEventListener('message', (event) => {
  if (event.source !== window || event.data?.type !== 'SYNC_QUOTE_REPORT') return;
  const report = event.data.report;
  if (!report || report.root !== rootDomain(location.hostname) || !['全車', '台號'].includes(report.playType)) return;
  chrome.runtime.sendMessage({ type: 'QUOTE_REPORT', report }).catch(() => {});
});

function setSiteInputValue(input, value) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
  if (setter) setter.call(input, String(value)); else input.value = String(value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: '1' }));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!['FULL_CAR_PREFLIGHT', 'FULL_CAR_ADD_CART'].includes(message?.type)) return;
  const page = readFullCarPage();
  if (!page || page.root !== message.root) return;
  const orders = Array.isArray(message.orders) ? message.orders : [];
  const error = !page.phase || page.phase !== message.phase ? '期數已變更，請重新比價'
    : orders.find((order) => page.quotes[order.number] !== order.price) ? '本金已變更，請重新比價'
    : orders.find((order) => !page.inputs[order.number] || !(Number(order.cars) > 0)) ? '號碼或車數無效'
    : '';
  if (error || message.type === 'FULL_CAR_PREFLIGHT') {
    sendResponse({ ok: !error, error, current: { phase: page.phase, quotes: page.quotes, cart: page.cart } });
    return;
  }
  try {
    orders.forEach((order) => setSiteInputValue(page.inputs[order.number], order.cars));
    const addButton = [...document.querySelectorAll('button,input[type="button"]')].find((button) =>
      String(button.innerText || button.value || '').trim() === '加入注單');
    if (!addButton) throw new Error('找不到加入注單按鈕');
    addButton.click();
    setTimeout(() => {
      reportFullCarPage();
      sendResponse({ ok: true, count: orders.length });
    }, 300);
    return true;
  } catch (errorValue) {
    sendResponse({ ok: false, error: String(errorValue?.message || errorValue) });
  }
});

if (/\/Front\/B\/B02(?:$|[?#])/i.test(location.href)) {
  setTimeout(reportFullCarPage, 300);
  setInterval(reportFullCarPage, 2000);
}
