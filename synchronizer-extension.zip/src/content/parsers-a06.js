function read188ColumnMeta(selectionCell) {
  if (!selectionCell) return null;

  const clean = (node) =>
    (node?.innerText || node?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();

  const number = (node) => {
    const raw = clean(node).replace(/,/g, "").trim();
    return /^-?\d+(?:\.\d+)?$/.test(raw) ? Number(raw) : null;
  };

  const normalize = (value) => String(value || "").replace(/\s+/g, "");
  let row = selectionCell.closest("tr");

  for (let depth = 0; row && depth < 6; depth++) {
    const rowCells = [...row.cells];
    const selectionIndex = rowCells.findIndex(
      (cell) => cell === selectionCell || cell.contains(selectionCell)
    );

    if (selectionIndex >= 0) {
      let headerRow = row.previousElementSibling;
      for (let back = 0; headerRow && back < 8; back++, headerRow = headerRow.previousElementSibling) {
        if (headerRow.tagName !== "TR") continue;
        const headerCells = [...headerRow.cells];
        const labels = headerCells.map((cell) => normalize(clean(cell)));
        const hSelection = labels.findIndex((x) => x.includes("下注內容"));
        const hUnit = labels.findIndex((x) => x.includes("每碰金額"));
        const hCombo = labels.findIndex((x) => x === "碰數" || x.includes("碰數"));
        const hTotal = labels.findIndex((x) => x === "下注金額" || x.includes("下注金額"));

        if (hSelection < 0 || hCombo < 0 || hTotal < 0) continue;

        const delta = selectionIndex - hSelection;
        const at = (headerIndex) => rowCells[headerIndex + delta] || null;
        const combo = number(at(hCombo));
        const unit = hUnit >= 0 ? number(at(hUnit)) : null;
        const total = number(at(hTotal));

        if (Number.isFinite(combo) && combo > 0) {
          return {
            combinationCount: combo,
            unitAmount: Number.isFinite(unit) ? unit : null,
            betAmount: Number.isFinite(total) ? total : null,
            headerRow,
            dataRow: row
          };
        }
      }
    }

    const table = row.closest("table");
    const parentCell = table?.parentElement?.closest("td");
    row = parentCell?.closest("tr") || null;
  }

  return null;
}

function scrapeCommonPillarRows(root = document) {
  const domain = rootDomain(location.hostname);
  if (!["188hot.net", "bnd139.com", "hyp98.com", "umh693.com", "amc283.com", "pee688.com"].includes(domain)) return [];

  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[domain] || domain;
  const orders = [];
  const seen = new Set();

  const cleanText = (node) =>
    (node?.innerText || node?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();

  const strictNumber = (value) => {
    const cleaned = String(value ?? "").replace(/,/g, "").trim();
    return /^-?\d+(?:\.\d+)?$/.test(cleaned) ? Number(cleaned) : null;
  };

  // 找出真正包含柱碰內容的 td。98 / 16 / 28 / 海勝 / 航海共用這套表格時，
  // 都從實際下注內容欄位完整讀取第01柱到最後一柱。
  const selectionCells = [...root.querySelectorAll("td")].filter((cell) => {
    const raw = cleanText(cell);
    return /第\s*0?1\s*柱/.test(raw) && /第\s*0?2\s*柱/.test(raw);
  });

  for (const selectionCell of selectionCells) {
    const selection = formatPillarSelection(cleanText(selectionCell));
    if (!selection) continue;

    // 網站可能在 td 內再包小 table。由目前 selection td 往外找，
    // 選第一個「selection 後面至少有 5 個數值欄」的 tr，避免抓到內層排版列。
    let row = selectionCell.closest("tr");
    let cells = [];
    let selectionIndex = -1;
    let numericAfter = [];

    for (let depth = 0; row && depth < 5; depth++) {
      cells = [...row.children].filter((el) => /^(TD|TH)$/.test(el.tagName));
      selectionIndex = cells.findIndex((cell) => cell === selectionCell || cell.contains(selectionCell));
      if (selectionIndex >= 0) {
        numericAfter = cells.slice(selectionIndex + 1).map((cell) => strictNumber(cleanText(cell)));
        if (numericAfter.length >= 5 && numericAfter.slice(0, 5).filter((v) => v != null).length >= 4) {
          break;
        }
      }
      const table = row.closest("table");
      const parentCell = table?.parentElement?.closest("td");
      row = parentCell?.closest("tr") || null;
    }

    if (selectionIndex < 0 || numericAfter.length < 5) continue;

    // 優先依表頭欄名直接讀「碰數」；找不到表頭時才沿用舊的欄位順序。
    const columnMeta = read188ColumnMeta(selectionCell);
    const odds = numericAfter[0];
    const principal = numericAfter[1];
    const unitAmount = columnMeta?.unitAmount ?? numericAfter[2];
    const combinationCount = columnMeta?.combinationCount ?? numericAfter[3];
    const betAmount = columnMeta?.betAmount ?? numericAfter[4];

    if (!(Number.isFinite(unitAmount) && unitAmount > 0 &&
          Number.isFinite(combinationCount) && combinationCount > 0 &&
          Number.isFinite(betAmount) && betAmount > 0)) continue;

    // 玩法、日期可能在 rowspan 或外層 row。從目前 row 往外/往上取一小段文字判斷。
    let contextText = cleanText(row);
    let cursor = row;
    for (let i = 0; i < 3 && !/([二三四五星]星)\s*柱碰/.test(contextText); i++) {
      const prev = cursor?.previousElementSibling;
      if (prev) contextText = `${cleanText(prev)} ${contextText}`;
      cursor = prev;
    }
    if (!/([二三四五星]星)\s*柱碰/.test(contextText)) {
      const tableText = cleanText(row?.closest("table"));
      contextText = `${contextText} ${tableText.slice(0, 3000)}`;
    }

    const playMatch = contextText.match(/([二三四五星]星)\s*柱碰/);
    if (!playMatch) continue;
    const event = `${playMatch[1]}柱碰`;

    const dateTime = contextText.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/)?.[0];
    const placedAt = dateTime
      ? `${dateTime.replace(/\//g, "-").replace(/\s+/, "T")}+08:00`
      : new Date().toISOString();

    // 和舊版 fallback 使用相同 id 前綴，讓後端以 UPSERT 更新原本那筆資料，
    // 不會因為修正碰數而新增重複訂單。
    const id = `${hostname}|table-order|${placedAt}|${event}|${selection}|${betAmount}`;
    if (seen.has(id)) continue;
    seen.add(id);

    orders.push(enrichedBet({
      id,
      source,
      account: "",
      placedAt,
      event,
      selection,
      odds: Number.isFinite(odds) ? odds : null,
      stake: unitAmount,
      potentialPayout: betAmount,
      status: orderStatusFromText(contextText, cleanText(row)),
      result: null,
      reconciled: false
    }, {
      itemNumber: itemNumberFromOrderContext(root, dateTime, event),
      playType: event,
      unitAmount,
      combinationCount,
      carCount: null,
      betAmount,
      principal: Number.isFinite(principal) ? principal : null,
      rawText: cleanText(row),
      parseStatus: "parsed"
    }));
  }

  return orders;
}

function scrape188SkyRows(root = document) {
  const domain = rootDomain(location.hostname);
  if (!["188hot.net", "bnd139.com", "hyp98.com"].includes(domain)) return [];

  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[domain] || domain;
  const orders = [];
  const seenContainers = new Set();

  const clean = (node) => (node?.innerText || node?.textContent || "")
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+/g, " ")
    .trim();

  const selectionCells = [...root.querySelectorAll("td")].filter((cell) => {
    const value = clean(cell);
    return /特碼\s*\d/.test(value) && /正碼\s*\d/.test(value);
  });

  for (const selectionCell of selectionCells) {
    let container = selectionCell;
    for (let depth = 0; container && depth < 12; depth++, container = container.parentElement) {
      const value = clean(container);
      if (
        /天碰[一二三四五六七八九十]+\s*(?:單碰|連碰)/.test(value) &&
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/.test(value) &&
        /單項金額總計/.test(value)
      ) break;
    }

    if (!container || seenContainers.has(container)) continue;
    seenContainers.add(container);

    const block = clean(container);
    const playMatch = block.match(/天碰([一二三四五六七八九十]+)\s*(單碰|連碰)/);
    if (!playMatch) continue;
    const event = `天碰${playMatch[1]}${playMatch[2]}`;
    const dateTime = block.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/)?.[0];
    const summary = block.match(/單項金額總計\s*(\d+(?:\.\d+)?)/);
    const total = summary ? Number(summary[1]) : 0;
    if (!dateTime || !(total > 0)) continue;

    const itemMatches = [...block.matchAll(
      /特碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)\s*正碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)(?:\s*顯示去除)?\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)/g
    )];
    if (!itemMatches.length) continue;

    const selection = itemMatches.map((item) =>
      `特碼 ${item[1].replace(/\s*,\s*/g, ", ")}／正碼 ${item[2].replace(/\s*,\s*/g, ", ")}`
    ).join("\n");
    const units = [...new Set(itemMatches.map((item) => Number(item[5])))];
    // 同批可能有不同每碰金額；不可用整批總額冒充單位金額。
    const eachAmount = units.length === 1 ? units[0] : null;
    const combinationCount = itemMatches.reduce((sum, item) => sum + Number(item[6]), 0);
    const placedAt = `${dateTime.replace(/\//g, "-").replace(/\s+/, "T")}+08:00`;
    // ID 也必須保留網站實際玩法名稱，避免天碰一／二／三互相覆寫。
    const id = `${hostname}|table-order|${placedAt}|${event}|${selection}|${total}`;

    orders.push(enrichedBet({
      id,
      source,
      account: "",
      placedAt,
      event,
      selection,
      odds: null,
      stake: eachAmount,
      potentialPayout: total,
      status: orderStatusFromText(block),
      result: null,
      reconciled: false
    }, {
      itemNumber: itemNumberFromOrderContext(root, dateTime, event),
      playType: event,
      unitAmount: eachAmount,
      combinationCount,
      carCount: null,
      betAmount: total,
      principal: null,
      rawText: block,
      parseStatus: "parsed"
    }));
  }

  return orders;
}

function scrape188Orders(root = document) {
  const directPillarOrders = scrapeCommonPillarRows(root);
  const directSkyOrders = scrape188SkyRows(root);
  const domain =
    rootDomain(location.hostname);

  if (
    ![
      "188hot.net",
      "bnd139.com",
      "hyp98.com"
    ].includes(domain)
  ) {
    return [];
  }

  const hostname =
    location.hostname.toLowerCase();

  const source =
    HOST_NAMES[hostname] ||
    SITE_NAMES[domain] ||
    domain;

  const pageText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  // 柱碰與連碰可能同時出現在同一張明細表。
  // 舊版只要先抓到任何柱碰就直接 return，導致同頁的連碰整批漏傳。
  // 先保留可靠的 DOM 柱碰結果，再繼續解析其他玩法；相同 id 由 seen 去重。
  const orders = [...directPillarOrders, ...directSkyOrders];
  const seen = new Set(orders.map((order) => order.id));

  // 188 / 98 / 28 的柱碰內容會在下注內容欄位內換行。
  // 直接從該 td 讀完整文字，避免 pageText 正規表示式在換行處截斷最後一柱。
  const pillarCellEntries = [...root.querySelectorAll("td")]
    .map((cell) => {
      const raw = (cell.innerText || cell.textContent || "").replace(/\u00a0/g, " ");
      if (!/第\s*0?1\s*柱/.test(raw) || !/第\s*0?2\s*柱/.test(raw)) return null;

      const selection = formatPillarSelection(raw);
      if (!selection) return null;

      return { cell, selection };
    })
    .filter(Boolean);
  let pillarSelectionIndex = 0;

  // 以網站真正的「單項金額總計」切分批次。舊版限制往前最多 1600 字，
  // 遇到同頁大量表格或隱藏欄位時，會把其中一批的日期／玩法切掉。
  const totalSegments188 = pageText.split(/單項金額總計/);
  let activeGameSection188 = "";
  const blocks188 = totalSegments188
    .slice(0, -1)
    .map((segment, index) => {
      activeGameSection188 = gameSectionFromText(segment, activeGameSection188);
      const summary = totalSegments188[index + 1].match(
        /^\s*(\d+(?:\.\d+)?)(?:\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\))?/
      );
      return summary ? [null, segment.slice(-6000), summary[1], summary[2], activeGameSection188] : null;
    })
    .filter(Boolean);

  for (const block of blocks188) {
    const textBlock =
      block[1];

    const gameSection = block[4];

    const total =
      numeric(block[2]);

    const totalCars =
      numeric(block[3]);

    const dateTime =
      textBlock.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      )?.[0];

    const placedAt =
      dateTime
        ? `${dateTime
            .replace(/\//g, "-")
            .replace(/\s+/, "T")}+08:00`
        : new Date().toISOString();

    const isFullCar =
      /全車\s*單碰/.test(
        textBlock
      );

    const isSpecialSingle =
      /特碼\s*單碰/.test(
        textBlock
      );

    const isTailThreeSingle =
      /特尾三\s*單碰/.test(
        textBlock
      );

    const isSkyTwoCombo =
      /天碰[一二三四五六七八九十]+\s*(?:單碰|連碰)/.test(
        textBlock
      );

    let event = "";
    let selection = "";
    let eachAmount = 0;
    let pillarEntry = null;
    let webCombinationCount = null;

    if (isTailThreeSingle) {
      event = "特尾三單碰";

      const items = [
        ...textBlock.matchAll(
          /(?:^|\s)(\d{3})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) continue;

      selection = items
        .map((item) => `${item[1]} ${Number(item[2])}`)
        .join("、");
      eachAmount = total;
    } else if (isSkyTwoCombo) {
      const skyMatch = textBlock.match(/天碰([一二三四五六七八九十]+)\s*(單碰|連碰)/);
      event = skyMatch ? `天碰${skyMatch[1]}${skyMatch[2]}` : "";

      const items = [
        ...textBlock.matchAll(
          /特碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)\s*正碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)(?:\s*顯示去除)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?/g
        )
      ];

      if (!items.length) continue;

      selection = items
        .map((item) =>
          `特碼 ${item[1].replace(/\s*,\s*/g, ", ")}／正碼 ${item[2].replace(/\s*,\s*/g, ", ")}`
        )
        .join("\n");

      const unitAmounts = [...new Set(items.map((item) => Number(item[3])))];
      // 同批可能有不同每碰金額；各組金額保留在 rawText，由顯示端逐組呈現。
      eachAmount = unitAmounts.length === 1 ? unitAmounts[0] : null;
      webCombinationCount = items.reduce((sum, item) => sum + Number(item[4]), 0);
    } else if (isSpecialSingle) {
      event = "特碼單碰";

      const items = [
        ...textBlock.matchAll(
          /(?:^|\s)(\d{1,2})\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      selection =
        items
          .map(
            (item) =>
              `${item[1].padStart(2, "0")} ${Number(item[4])}`
          )
          .join("、");

      eachAmount =
        total;
    } else if (isFullCar) {
      event = "全車單碰";

      const items = [
        ...textBlock.matchAll(
          /(?:^|\s)(\d{1,2})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      selection =
        items
          .map(
            (item) =>
              `${item[1].padStart(2, "0")} ${Number(item[2])}車`
          )
          .join("、");

      eachAmount =
        totalCars ||
        items.reduce(
          (sum, item) =>
            sum + Number(item[2]),
          0
        );
    } else {
      const playParts =
        textBlock.match(
          /([二三四五星]星)\s*(柱碰|連碰)/
        );

      event =
        playParts
          ? `${playParts[1]}${playParts[2]}`
          : "";

      const pillars = [
        ...textBlock.matchAll(
          /第\s*(\d{1,2})\s*柱\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)/g
        )
      ];

      const numberMatches = [
        ...textBlock.matchAll(
          /\d{1,2}(?:\s*,\s*\d{1,2})+/g
        )
      ];

      const numberMatch =
        numberMatches.at(-1);

      if (
        !event ||
        (!pillars.length && !numberMatch)
      ) {
        continue;
      }

      if (/柱碰/.test(event)) {
        pillarEntry = pillarCellEntries[pillarSelectionIndex++] || null;
        const domSelection = pillarEntry?.selection || "";
        const columnMeta = read188ColumnMeta(pillarEntry?.cell);
        if (columnMeta?.combinationCount) {
          webCombinationCount = columnMeta.combinationCount;
        }
        selection = domSelection || (pillars.length
          ? pillars
              .map(
                (pillar) =>
                  `第${pillar[1].padStart(2, "0")}柱 ${pillar[2].replace(/\s*,\s*/g, ", ")}`
              )
              .join("、")
          : "");
      } else {
        // 連碰號碼過多時，網站會在同一個下注內容 td 內自動換行。
        // numberMatches.at(-1) 只會留下最後一行；改為從下注時間後、
        // 「顯示去除」按鈕前的完整內容依原順序讀取全部號碼。
        const afterDate = dateTime && textBlock.includes(dateTime)
          ? textBlock.slice(textBlock.indexOf(dateTime) + dateTime.length)
          : textBlock;
        const hasSelectionBoundary = /顯示去除/.test(afterDate);
        const selectionRegion = afterDate.split(/顯示去除|新增備註/)[0];
        const wrappedNumbers = hasSelectionBoundary
          ? [...selectionRegion.matchAll(/(?:^|[^\d])(\d{1,2})(?=[^\d]|$)/g)]
              .map((match) => match[1].padStart(2, "0"))
          : [];
        selection = wrappedNumbers.length
          ? wrappedNumbers.join(", ")
          : numberMatch[0].replace(/\s*,\s*/g, ", ");
      }

      const lastSelectionMatch =
        /柱碰/.test(event) && pillars.length
          ? pillars.at(-1)
          : numberMatch;

      const tail =
        textBlock.slice(
          (lastSelectionMatch.index || 0) +
          lastSelectionMatch[0].length
        );

      const values = [
        ...tail.matchAll(
          /\d+(?:\.\d+)?/g
        )
      ].map(
        (value) =>
          Number(value[0])
      );

      const totalIndex =
        values.lastIndexOf(
          total
        );

      // 網站欄位順序：賠率、本金、每碰金額、碰數、下注金額。
      // 直接取下注金額前一格的「碰數」，不自行計算。
      if (/柱碰/.test(event) && webCombinationCount == null && totalIndex >= 1) {
        webCombinationCount = values[totalIndex - 1];
      }

      eachAmount =
        totalIndex >= 2
          ? values[
              totalIndex - 2
            ]
          : total;
    }

    if (
      !event ||
      !selection ||
      !total ||
      total <= 0 ||
      !eachAmount ||
      eachAmount <= 0
    ) {
      continue;
    }

    const id =
      `${hostname}|table-order|${placedAt}|${event}|${selection}|${total}`;

    if (seen.has(id)) {
      const existing = orders.find((order) => order.id === id);
      if (existing && gameSection) existing.event = eventWithGameSection(gameSection, existing.playType || event);
      continue;
    }

    seen.add(id);

    // 柱碰直接採用網站明細中的「碰數」欄位；其他玩法維持既有邏輯。
    const comboCount = /柱碰|天碰/.test(event)
      ? webCombinationCount
      : combinationCountFor(event, selection);

    orders.push(
      enrichedBet(
        {
          id,
          source,
          account: "",
          placedAt,
          event: eventWithGameSection(gameSection, event),
          selection,
          odds: null,
          stake: eachAmount,
          potentialPayout: total,
          status: orderStatusFromText(textBlock),
          result: null,
          reconciled: false
        },
        {
          itemNumber: itemNumberFromOrderContext(root, dateTime, event),
          playType: event,
          unitAmount:
            isFullCar
              ? null
              : eachAmount,
          combinationCount:
            comboCount,
          carCount:
            isFullCar
              ? eachAmount
              : null,
          betAmount: total,
          rawText: textBlock,
          parseStatus: "parsed"
        }
      )
    );
  }

  return orders;
}

