function findDetailsLink() {
  return [...document.querySelectorAll("a,button,[role='button']")].find(
    (item) => (item.textContent || "").replace(/\s+/g, "").includes("下注明細")
  );
}

function findDetailsUrl() {
  const link = findDetailsLink();

  if (!link) {
    return location.href;
  }

  const raw =
    link.getAttribute(
      "href"
    ) || "";

  if (
    !raw ||
    raw === "#" ||
    /^javascript:/i.test(raw)
  ) {
    if (
      location.pathname.includes(
        "/new_web/index.php"
      )
    ) {
      const target =
        new URL(
          location.href
        );

      target.hash =
        "#/main/main06";

      return target.href;
    }

    return location.href;
  }

  try {
    return new URL(
      raw,
      location.href
    ).href;
  } catch {
    return "";
  }
}

function isInsideSyncDetailFrame() {
  // The 188/98/28/海勝/航海 family uses a frameset. The hidden bootstrap
  // iframe therefore contains nested frames, and the navigation link usually
  // lives in a child frame rather than in the bootstrap frame itself.
  let current = window;
  for (let depth = 0; depth < 12; depth += 1) {
    try {
      if (current.name === "sync-detail-frame") return true;
      if (current.frameElement?.dataset?.syncDetails === "1") return true;
      if (current.parent === current) break;
      current = current.parent;
    } catch {
      break;
    }
  }
  return false;
}

function openDetailsInsideBackgroundFrame() {
  if (
    !isInsideSyncDetailFrame() ||
    document.querySelector(
      "#bet_details"
    )
  ) {
    return;
  }

  const link = findDetailsLink();

  if (link) {
    link.click();
  }
}

function expandBackgroundDetailPageSize() {
  if (!isInsideSyncDetailFrame()) return;

  // A06 預設每頁 15 筆；航海一天超過 15 筆時會出現第 2 頁，
  // 舊版背景框架只解析目前頁面。自動切到網站提供的 50 筆選項，
  // 讓兩頁資料在同一份 DOM 中完整解析，且不改動使用者正在看的頁面。
  const pageSizeSelect = [...document.querySelectorAll("select")].find((select) => {
    const optionTexts = [...select.options].map((option) => option.textContent.trim());
    return optionTexts.includes("15") && optionTexts.includes("50");
  });

  if (!pageSizeSelect) return;

  const option50 = [...pageSizeSelect.options].find(
    (option) => option.textContent.trim() === "50"
  );
  if (!option50) return;

  if (pageSizeSelect.value === option50.value) return;

  pageSizeSelect.value = option50.value;
  pageSizeSelect.dispatchEvent(new Event("input", { bubbles: true }));
  pageSizeSelect.dispatchEvent(new Event("change", { bubbles: true }));
}

function isInsideSyncLedgerFrame() {
  return window.name === "sync-ledger-frame" ||
    document.documentElement?.dataset?.syncLedger === "1";
}

function directLedgerUrl() {
  const root = rootDomain(location.hostname);
  // 只加入已確認的 A07 頁面；其他共版網站不可猜。
  if (!["hyp98.com", "188hot.net", "bnd139.com", "umh693.com", "and539.com", "pee688.com"].includes(root)) return "";

  const marker = "/Front/";
  const idx = location.pathname.indexOf(marker);
  if (idx < 0) return "";
  const prefix = location.pathname.slice(0, idx);
  return `${location.origin}${prefix}/Front/A/A07`;
}

// 建立與更新框架共用一處；明細和總帳仍各自保存名稱、URL 與更新週期。
function ensureSyncFrame(kind, url) {
  let frame = document.querySelector(`iframe[data-sync-${kind}]`);
  if (!frame) {
    frame = document.createElement("iframe");
    frame.name = kind === "ledger" ? "sync-ledger-frame" : "sync-detail-frame";
    frame.setAttribute(`data-sync-${kind}`, "1");
    frame.setAttribute("aria-hidden", "true");
    frame.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;border:0;left:-10000px;top:-10000px";
    document.documentElement.appendChild(frame);
  }

  if (frame.getAttribute("data-sync-url") !== url) {
    frame.setAttribute("data-sync-url", url);
    frame.src = url;
  }
}

function ensureBackgroundLedger() {
  if (window.top !== window || isInsideSyncLedgerFrame()) return;
  const url = directLedgerUrl();
  if (url) ensureSyncFrame("ledger", url);
}

function refreshBackgroundLedger() {
  ensureBackgroundLedger();
  const frame = document.querySelector("iframe[data-sync-ledger]");
  const url = frame?.getAttribute("data-sync-url");
  if (!frame || !url) return;
  const refreshed = new URL(url);
  refreshed.searchParams.set("_sync", String(Date.now()));
  frame.src = refreshed.href;
}

function directA06Url() {
  const root = rootDomain(location.hostname);
  const directRoots = [
    "hyp98.com", "kd998.net", "cj3688.com", "188hot.net",
    "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"
  ];
  if (!directRoots.includes(root)) return "";

  // These sites use a per-login/site prefix before /Front/. Keep that prefix
  // from the current URL and go straight to the real bet-detail document.
  const marker = "/Front/";
  const idx = location.pathname.indexOf(marker);
  if (idx < 0) return "";
  const prefix = location.pathname.slice(0, idx);
  return `${location.origin}${prefix}/Front/A/A06`;
}

function ensureBackgroundDetails() {
  // 風雲不另開第二個 SPA，以免新工作頁干擾既有登入工作階段。
  if (rootDomain(location.hostname) === 'vs968.net') {
    document.querySelectorAll('iframe[data-sync-details]').forEach(frame => frame.remove());
    return;
  }
  if (window.top !== window || window.name === "sync-detail-frame") return;

  const root = rootDomain(location.hostname);
  const supportedRoots = [
    "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
    "188hot.net", "bnd139.com", "umh693.com", "and539.com", "amc283.com", "pee688.com"
  ];
  if (!supportedRoots.includes(root)) return;
  if (root === 'vs968.net') return; // 登入工作框自行管理，不從郵局外殼重開 SPA。

  // 188/98/28/海勝/航海 family: A06 is the confirmed detail document.
  // Load it directly in a hidden same-origin frame so its own scripts render
  // the table; content.js in that frame then uses the existing DOM parsers.
  const a06 = directA06Url();
  if (a06) {
    ensureSyncFrame("details", a06);
    return;
  }

  // Other gateway sites keep the learned-request flow; do not duplicate 喜 SPA.
  chrome.storage.local.get(["learnedDetailRequests"], ({ learnedDetailRequests = {} }) => {
    if (learnedDetailRequests[root]) {
      document.querySelectorAll("iframe[data-sync-details]").forEach((frame) => frame.remove());
      return;
    }
    const url = findDetailsUrl();
    if (!url) return;
    ensureSyncFrame("details", url);
  });
}

function refreshBackgroundDetails() {
  ensureBackgroundDetails();
  const frame = document.querySelector("iframe[data-sync-details]");
  const url = frame?.getAttribute("data-sync-url");
  if (frame && url && directA06Url()) {
    // Let this site's package query finish instead of destroying its document.
    // The lease expires after a stalled/failed reader, so refresh cannot stop forever.
    if (rootDomain(location.hostname) === 'pee688.com') {
      try {
        const started = Number(frame.contentDocument?.documentElement?.dataset?.syncPackageReadingAt);
        const age = Date.now() - started;
        if (started > 0 && age >= 0 && age < 15000) return;
      } catch { /* Existing refresh remains the recovery path. */ }
    }
    // Reload the confirmed A06 document. Cache-busting avoids stale HTML while
    // preserving same-origin login cookies/session.
    const u = new URL(url);
    u.searchParams.set("_sync", String(Date.now()));
    frame.src = u.href;
  }
}

// Fresh-install / cross-page bootstrap: if this extension has no learned
// detail request yet, silently open the site's detail route inside a 1px
// hidden frame. The frame is removed automatically after learning succeeds.
if (isInsideSyncDetailFrame()) {
  setTimeout(expandBackgroundDetailPageSize, 300);
  setTimeout(expandBackgroundDetailPageSize, 1000);
  setTimeout(expandBackgroundDetailPageSize, 2500);
  setInterval(expandBackgroundDetailPageSize, 1000);
  setTimeout(openDetailsInsideBackgroundFrame, 400);
  setTimeout(openDetailsInsideBackgroundFrame, 1400);
  setTimeout(openDetailsInsideBackgroundFrame, 3000);
  setTimeout(openDetailsInsideBackgroundFrame, 6000);
}

if (window.top === window) {
  setTimeout(ensureBackgroundDetails, 700);
  setInterval(() => {
    if (directA06Url()) refreshBackgroundDetails();
    else ensureBackgroundDetails();
  }, 10000);

  // 總帳與下注明細使用不同背景框架。A07 每分鐘更新一次當日快照，
  // 避免頻繁重載造成網站卡頓，也不會把輪詢結果重複累加。
  setTimeout(ensureBackgroundLedger, 1200);
  setInterval(refreshBackgroundLedger, 60000);
}

// 喜網站不建立第二個 /new_web/ SPA。實站確認同一工作階段同時載入
// 隱藏 main07 會讓主頁被踢回登入畫面。總帳由既有工作框內的 Vuex
// 背景讀取，手動總帳頁由 syncLedgerDom 補充；明細維持 gateway 輪詢。
