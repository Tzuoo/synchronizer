function scrapeUmhOrders(root = document) {
  if (
    rootDomain(location.hostname) !==
    "umh693.com"
  ) {
    return [];
  }

  // 柱碰優先直接讀實際下注內容 td。
  // 不再用整頁文字正規表示式截取，避免第三柱很長時被下一欄資料截斷。
  const directPillarOrders = scrapeCommonPillarRows(root);

  const hostname =
    location.hostname.toLowerCase();

  // 柱碰資料只作為欄位補強，不可先插入結果陣列；否則柱碰會全部跑到
  // 全車／連碰前面，破壞下注明細原始批次順序。
  const orders = [];
  const seen = new Set();
  const signatureCounts = new Map();

  const pageText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  // 依網站每批末尾的「單項金額總計」逐批切開，不限制往前字數。
  // 固定 1200 字的視窗遇到較長批次會遺失日期／玩法，造成少批。
  const totalSegments = pageText.split(/單項金額總計/);
  let activeGameSection = "";
  const blocks = totalSegments.slice(0, -1).map((segment, index) => {
    activeGameSection = gameSectionFromText(segment, activeGameSection);
    const summary = totalSegments[index + 1].match(/^\s*(\d+(?:\.\d+)?)/);
    return summary ? { text: segment, total: summary[1], batchIndex: index, gameSection: activeGameSection } : null;
  }).filter(Boolean);

  for (const block of blocks) {
    const textBlock = block.text;

    const playParts =
      textBlock.match(
        /([二三四五星]星)\s*(連柱碰|柱碰|連碰)/
      );

    let play =
      playParts
        ? `${playParts[1]}${playParts[2]}`
        : textBlock.match(
            /(?:全車|[二三四五星]星[^\s]*碰|台號|特尾三|套餐|雙面|快速輸入)/
          )?.[0];

    if (play === "全車" && /全車\s*單碰/.test(textBlock)) {
      play = "全車單碰";
    }

    const pillars = [
      ...textBlock.matchAll(
        /第\s*(\d{1,2})\s*柱\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)/g
      )
    ];

    const numberMatches = [
      ...textBlock.matchAll(
        /\d{1,2}(?:\s*,\s*\d{1,2})+/g
      )
    ];

    let selection =
      pillars.length
        ? pillars
            .map(
              (pillar) =>
                `第${pillar[1].padStart(2, "0")}柱 ${pillar[2].replace(/\s*,\s*/g, ", ")}`
            )
            .join("、")
        : numberMatches
            .at(-1)?.[0]
            ?.replace(/\s*,\s*/g, ", ");

    if (play === "全車單碰") {
      const items = [...textBlock.matchAll(
        /(?:^|\s)(\d{1,2})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\)/g
      )];
      if (items.length) {
        selection = items.map((item) =>
          `${item[1].padStart(2, "0")} ${Number(item[2])}車`
        ).join("、");
      }
    }

    const dateTime =
      textBlock.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      )?.[0];

    const total =
      numeric(block.total);

    const startIndex =
      (pillars.at(-1)?.index ??
        numberMatches.at(-1)?.index ??
        0) +
      (
        pillars.at(-1)?.[0]?.length ??
        numberMatches.at(-1)?.[0]?.length ??
        0
      );

    const valuesAfterNumbers = [
      ...textBlock
        .slice(startIndex)
        .matchAll(
          /\d+(?:\.\d+)?/g
        )
    ].map(
      (value) =>
        Number(value[0])
    );

    const totalIndex =
      valuesAfterNumbers.lastIndexOf(total);

    const linked = /連柱碰/.test(play || "") ? readLinkedPillarBlock(textBlock, total, dateTime) : null;
    if (/連柱碰/.test(play || "")) {
      if (!linked) continue;
      selection = linked.selection;
    }
    const eachAmount = linked?.unitAmount ?? (
      totalIndex >= 2
        ? valuesAfterNumbers[
            totalIndex - 2
          ]
        : total);

    if (
      !play ||
      !selection ||
      !total ||
      total <= 0 ||
      !eachAmount ||
      eachAmount <= 0
    ) {
      continue;
    }

    const placedAt =
      dateTime
        ? `${dateTime
            .replace(/\//g, "-")
            .replace(/\s+/, "T")}+08:00`
        : new Date().toISOString();

    const directPillar = /柱碰/.test(play)
      ? directPillarOrders.find((order) =>
          String(order.placedAt || "").replace(/\s+/g, "T") ===
            String(placedAt || "").replace(/\s+/g, "T") &&
          order.event === play &&
          (!selection || order.selection === selection)
        )
      : null;

    if (directPillar) {
      selection = directPillar.selection;
    }

    // 第一筆沿用既有 ID，讓後端 UPSERT 更新舊資料；只有網站真的出現第二個
    // 完全相同批次時才加序號，保留真實重複而不製造版本升級重複資料。
    const baseId = directPillar?.id ||
      `${hostname}|text-table-order|${placedAt}|${play}|${selection}|${total}`;
    const occurrence = signatureCounts.get(baseId) || 0;
    signatureCounts.set(baseId, occurrence + 1);
    const id = occurrence ? `${baseId}|batch-${occurrence + 1}` : baseId;

    if (seen.has(id)) continue;

    seen.add(id);

    const comboCount = linked?.combinationCount ?? directPillar?.combinationCount ??
      combinationCountFor(play, selection);
    const carCount = play === "全車單碰"
      ? [...String(selection).matchAll(/(\d+(?:\.\d+)?)\s*車/g)]
          .reduce((sum, item) => sum + Number(item[1]), 0)
      : null;

    orders.push(
      enrichedBet(
        {
          id,
          source: "海勝",
          account: "",
          placedAt,
          event: eventWithGameSection(block.gameSection, play),
          selection,
          odds: directPillar?.odds ?? null,
          stake: directPillar?.unitAmount ?? eachAmount,
          potentialPayout: total,
          status: orderStatusFromText(textBlock),
          result: null,
          reconciled: false
        },
        {
          itemNumber: directPillar?.itemNumber ?? itemNumberFromOrderContext(root, dateTime, play),
          playType: play,
          unitAmount: play === "全車單碰" ? null : (directPillar?.unitAmount ?? eachAmount),
          combinationCount:
            comboCount,
          carCount: carCount > 0 ? carCount : null,
          betAmount: total,
          rawText: textBlock,
          parseStatus: "parsed"
        }
      )
    );
  }

  if (orders.length) {
    return orders;
  }

  let currentTime = "";

  for (
    const row of root.querySelectorAll("tr")
  ) {
    const raw =
      (
        row.innerText ||
        row.textContent ||
        ""
      )
        .replace(/\u00a0/g, " ")
        .replace(/\s+/g, " ")
        .trim();

    if (
      !raw ||
      /^(頁次|玩法|下注內容|賠率|本金|每碰金額|碰數|下注金額)/.test(raw)
    ) {
      continue;
    }

    const dateTime =
      raw.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    if (dateTime) {
      currentTime =
        dateTime[0].replace(/\//g, "-");
    }

    const play =
      raw.match(
        /(?:全車|[二三四五星]星連碰|[二三四五星]星[^\s]*碰|台號|特尾三|套餐|雙面|快速輸入)/
      )?.[0];

    const numberMatch =
      raw.match(
        /\d{1,2}(?:\s*,\s*\d{1,2})+/
      );

    if (
      !play ||
      !numberMatch
    ) {
      continue;
    }

    const cells = [
      ...row.querySelectorAll("td")
    ].map(
      (cell) =>
        (
          cell.innerText ||
          cell.textContent ||
          ""
        )
          .replace(/\s+/g, " ")
          .trim()
    );

    const stake =
      cells.length >= 8
        ? numeric(cells[7])
        : null;

    if (
      !stake ||
      stake <= 0
    ) {
      continue;
    }

    const selection =
      numberMatch[0].replace(
        /\s*,\s*/g,
        ", "
      );

    const id =
      `${hostname}|table-order|${currentTime}|${play}|${selection}|${stake}`;

    if (seen.has(id)) {
      continue;
    }

    seen.add(id);

    const comboCount =
      combinationCountFor(
        play,
        selection
      );

    orders.push(
      enrichedBet(
        {
          id,
          source: "海勝",
          account: "",
          placedAt:
            currentTime
              ? `${currentTime.replace(" ", "T")}+08:00`
              : new Date().toISOString(),
          event: play,
          selection,
          odds: null,
          stake,
          potentialPayout: null,
          status: orderStatusFromText(raw),
          result: null,
          reconciled: false
        },
        {
          playType: play,
          unitAmount: stake,
          combinationCount:
            comboCount,
          betAmount:
            comboCount
              ? stake * comboCount
              : stake,
          rawText: raw,
          parseStatus: "partial"
        }
      )
    );
  }

  if (orders.length) {
    return orders;
  }

  const fallbackText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  const fallbackBlocks =
    fallbackText.matchAll(
      /([\s\S]{0,1200}?)單項金額總計\s*(\d+(?:\.\d+)?)/g
    );

  for (
    const block of fallbackBlocks
  ) {
    const textBlock =
      block[1];

    const play =
      textBlock.match(
        /(?:全車|[二三四五星]星連碰|[二三四五星]星[^\s]*碰|台號|特尾三|套餐|雙面|快速輸入)/
      )?.[0];

    const numberMatches = [
      ...textBlock.matchAll(
        /\d{1,2}(?:\s*,\s*\d{1,2})+/g
      )
    ];

    const numberMatch =
      numberMatches.at(-1);

    const dateTime =
      textBlock.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      )?.[0];

    const stake =
      numeric(block[2]);

    if (
      !play ||
      !numberMatch ||
      !stake ||
      stake <= 0
    ) {
      continue;
    }

    const selection =
      numberMatch[0].replace(
        /\s*,\s*/g,
        ", "
      );

    const placedAt =
      dateTime
        ? `${dateTime
            .replace(/\//g, "-")
            .replace(" ", "T")}+08:00`
        : new Date().toISOString();

    const id =
      `${hostname}|text-table-order|${placedAt}|${play}|${selection}|${stake}`;

    if (seen.has(id)) {
      continue;
    }

    seen.add(id);

    const comboCount =
      combinationCountFor(
        play,
        selection
      );

    orders.push(
      enrichedBet(
        {
          id,
          source: "海勝",
          account: "",
          placedAt,
          event: play,
          selection,
          odds: null,
          stake,
          potentialPayout: null,
          status: orderStatusFromText(textBlock),
          result: null,
          reconciled: false
        },
        {
          playType: play,
          unitAmount: stake,
          combinationCount:
            comboCount,
          betAmount:
            comboCount
              ? stake * comboCount
              : stake,
          rawText: textBlock,
          parseStatus: "partial"
        }
      )
    );
  }

  return orders;
}
