# 擴充內容腳本來源

`content/` 是唯一手動維護的內容腳本來源；上層 `content.js` 是產物，不可直接修改。
這些檔案依固定順序組成同一支腳本，不是獨立載入的 ES modules，刻意保留原有函式提升、共用狀態與啟動順序。

| 檔案 | 職責 |
| --- | --- |
| shared.js | 網站與帳號辨識、文字、組合、項次及訊息工具 |
| parsers-dom.js | 一般明細 DOM、喜批次及分組報表解析 |
| parsers-umh.js | 海勝明細解析 |
| parsers-a06.js | A06 同型網站欄位、柱碰、天碰與批次解析 |
| parsers-amc.js | AMC 類型明細解析 |
| parsers-gateway.js | Gateway JSON 與回應格式解析 |
| ledger.js | A07／共版總帳解析、快照及總帳訊息接收 |
| sync.js | 明細接收、上傳、原始順序、重播、心跳及背景喚醒 |
| frames.js | 明細／總帳框架生命週期與啟動排程 |

從專案根目錄執行：

```powershell
node 'GitHub網頁原始碼/tools/build-extension.mjs'
node 'GitHub網頁原始碼/tools/build-extension.mjs' --check
```

`Build-ExtensionUpdate.ps1` 會先產生入口、跑回歸測試，再製作 ZIP。公司端只載入已產生的 `content.js`，不需要 Node 或自行建置。
跨檔函式仍共用原有腳本作用域；調整介面時須搜尋所有引用。網站用語、順序、批次與金額規則見專案根目錄唯一共用紀錄 `AGENTS.md`。
