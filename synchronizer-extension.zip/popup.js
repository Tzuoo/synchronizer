const formatTime = (value) => value ? new Date(value).toLocaleString() : "—";
const diagnosticNames = { "vs968.net": "風雲", "kd998.net": "喜" };

chrome.storage.local.get(
  ["lastSync", "lastHeartbeat", "lastPoll", "learnedAt", "syncToken", "siteDiagnostics", "installationId", "diagnosticDeviceLabel"],
  ({ lastSync, lastHeartbeat, lastPoll, learnedAt, syncToken, siteDiagnostics = {}, installationId, diagnosticDeviceLabel }) => {
    const deviceId = document.querySelector("#device-id");
    deviceId.textContent = installationId ? `裝置識別：${installationId}` : "裝置識別：尚未建立，請稍後重新開啟";
    const deviceLabel = document.querySelector("#device-label");
    deviceLabel.value = ["公司", "家裡"].includes(diagnosticDeviceLabel) ? diagnosticDeviceLabel : "";
    deviceLabel.disabled = false;
    deviceLabel.addEventListener("change", async () => {
      deviceLabel.disabled = true;
      try {
        await chrome.storage.local.set({ diagnosticDeviceLabel: deviceLabel.value });
        document.querySelector("#device-note").textContent = "名稱已儲存；診斷將依裝置分開回報，其他裝置不會覆蓋。";
      } catch {
        document.querySelector("#device-note").textContent = "名稱儲存失敗，請重新開啟後再試。";
      } finally {
        deviceLabel.disabled = false;
      }
    });
    const status = document.querySelector("#status");
    if (!syncToken) status.textContent = "尚未設定同步權杖";
    else if (lastHeartbeat?.ok) status.textContent = `已連線：${lastHeartbeat.site}\n${formatTime(lastHeartbeat.at)}`;
    else if (lastSync?.ok) status.textContent = `已同步 ${lastSync.count} 筆\n${formatTime(lastSync.at)}`;
    else status.textContent = lastHeartbeat?.error ? `連線失敗：${lastHeartbeat.error}` : "等待網站連線";

    if (learnedAt) status.textContent += `\n航海明細路徑已學習：${formatTime(learnedAt)}`;
    if (lastPoll?.ok) status.textContent += `\n背景讀取成功：${lastPoll.count} 筆 ${formatTime(lastPoll.at)}`;
    if (lastPoll && !lastPoll.ok) status.textContent += `\n背景讀取失敗：${lastPoll.error}`;

    const diagnostics = document.querySelector("#diagnostics");
    diagnostics.replaceChildren(...Object.entries(diagnosticNames).map(([site, name]) => {
      const state = siteDiagnostics[site] || {};
      const card = document.createElement("section");
      card.className = "diagnostic-card";
      const upload = state.uploadAt
        ? (state.uploadOk ? `上傳成功 ${state.uploadCount || 0} 筆` : `上傳失敗：${state.uploadError || "未知錯誤"}`)
        : "尚無上傳紀錄";
      const title = document.createElement("strong");
      title.textContent = name;
      const frame = document.createElement("span");
      frame.className = state.frameOk ? "ok" : "warn";
      frame.textContent = state.frameOk ? "工作框正常" : "尚未偵測工作框";
      const poll = document.createElement("div");
      poll.textContent = state.pollState || "尚無背景讀取紀錄";
      const result = document.createElement("div");
      result.textContent = `解析：${state.parsedCount ?? "—"} 筆　${upload}`;
      const updated = document.createElement("small");
      updated.textContent = `最後更新：${formatTime(state.updatedAt)}`;
      card.append(title, frame, poll, result, updated);
      return card;
    }));
  }
);

document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());

let latestFullCarPlan = null;

function parseFullCarOrders(text) {
  const rows = String(text || '').split(/[\n,;]+/).map((row) => row.trim()).filter(Boolean);
  const orders = rows.map((row) => {
    const match = row.match(/^(\d{1,2})\s*(?:[:=xX*]|\s)\s*(\d+(?:\.\d+)?)$/);
    if (!match) throw new Error(`格式錯誤：${row}`);
    const number = match[1].padStart(2, '0');
    const cars = Number(match[2]);
    if (!/^(0[1-9]|[12]\d|3\d)$/.test(number) || !(cars > 0)) throw new Error(`號碼或車數無效：${row}`);
    return { number, cars };
  });
  if (!orders.length) throw new Error('請先輸入號碼與車數');
  return orders;
}

function chooseBalancedSite(choices, counts) {
  const minimumCount = Math.min(...choices.map((row) => Number(counts[row.report.root]) || 0));
  const leastUsed = choices.filter((row) => (Number(counts[row.report.root]) || 0) === minimumCount);
  return leastUsed[Math.floor(Math.random() * leastUsed.length)];
}

async function buildFullCarPlan() {
  const result = document.querySelector('#full-car-result');
  const addButton = document.querySelector('#add-full-car');
  latestFullCarPlan = null;
  addButton.disabled = true;
  try {
    const orders = parseFullCarOrders(document.querySelector('#full-car-orders').value);
    const response = await chrome.runtime.sendMessage({ type: 'GET_FULL_CAR_REPORTS' });
    const reports = (response?.reports || []).filter((row) => ['and539.com', 'bnd139.com'].includes(row.root));
    if (reports.length !== 2) throw new Error('請確認海勝2與金好運都停在 539 全車頁');
    const phases = new Set(reports.map((row) => row.phase));
    if (phases.size !== 1 || !reports[0].phase) throw new Error('兩站期數不同或尚未辨識，禁止加入');
    const { fullCarTieCounts = {} } = await chrome.storage.local.get(['fullCarTieCounts']);
    const plannedCounts = { ...fullCarTieCounts };
    const targets = new Map();
    const lines = [];
    for (const order of orders) {
      const priced = reports.map((report) => ({ report, price: report.quotes?.[order.number] })).filter((row) => Number.isFinite(row.price));
      if (priced.length !== 2) throw new Error(`${order.number} 無法取得兩站完整本金`);
      const minimum = Math.min(...priced.map((row) => row.price));
      const choices = priced.filter((row) => row.price === minimum);
      const tied = choices.length > 1;
      const chosen = tied ? chooseBalancedSite(choices, plannedCounts) : choices[0];
      if (tied) plannedCounts[chosen.report.root] = (Number(plannedCounts[chosen.report.root]) || 0) + 1;
      const target = { root: chosen.report.root, siteName: chosen.report.siteName, phase: chosen.report.phase,
        orders: [{ number: order.number, cars: order.cars, price: chosen.price }], tied };
      const sequence = targets.get('sequence') || [];
      sequence.push(target);
      targets.set('sequence', sequence);
      lines.push(`${order.number} × ${order.cars}車 → ${chosen.report.siteName}（${chosen.price}${tied ? '，同價平均' : ''}）`);
    }
    latestFullCarPlan = targets.get('sequence') || [];
    result.textContent = `期數 ${reports[0].phase}\n${lines.join('\n')}`;
    result.className = 'best';
    addButton.disabled = false;
  } catch (error) {
    result.textContent = String(error?.message || error);
    result.className = 'warn';
  }
}

document.querySelector('#compare-full-car').addEventListener('click', buildFullCarPlan);
document.querySelector('#add-full-car').addEventListener('click', async () => {
  const result = document.querySelector('#full-car-result');
  const button = document.querySelector('#add-full-car');
  if (!latestFullCarPlan) return;
  button.disabled = true;
  try {
    const preflight = await chrome.runtime.sendMessage({ type: 'FULL_CAR_COMMAND', command: 'FULL_CAR_PREFLIGHT', targets: latestFullCarPlan });
    if (!preflight?.ok) throw new Error((preflight?.results || []).filter((row) => !row.ok).map((row) => `${row.root}：${row.error}`).join('\n') || '加入前檢查失敗');
    const { fullCarTieCounts = {} } = await chrome.storage.local.get(['fullCarTieCounts']);
    for (const target of latestFullCarPlan) {
      const added = await chrome.runtime.sendMessage({ type: 'FULL_CAR_COMMAND', command: 'FULL_CAR_ADD_CART', targets: [target] });
      if (!added?.ok) throw new Error((added?.results || []).filter((row) => !row.ok).map((row) => `${row.root}：${row.error}`).join('\n') || '加入清單失敗');
      if (target.tied) {
        fullCarTieCounts[target.root] = (Number(fullCarTieCounts[target.root]) || 0) + 1;
        // 逐筆保存；即使後一筆加入失敗，已成功的同價分配仍會納入下次平衡。
        await chrome.storage.local.set({ fullCarTieCounts });
      }
    }
    result.textContent += '\n已加入網站左側清單；尚未送出注單。';
    result.className = 'best';
    latestFullCarPlan = null;
  } catch (error) {
    result.textContent = String(error?.message || error);
    result.className = 'warn';
    button.disabled = false;
  }
});
