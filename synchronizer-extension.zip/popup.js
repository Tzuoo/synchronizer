chrome.storage.local.get(["lastSync", "lastHeartbeat", "lastPoll", "learnedAt", "syncToken"], ({ lastSync, lastHeartbeat, lastPoll, learnedAt, syncToken }) => {
  const status = document.querySelector("#status");
  if (!syncToken) {
    status.textContent = "\u5c1a\u672a\u8a2d\u5b9a\u540c\u6b65\u6b0a\u6756";
  } else if (lastHeartbeat?.ok) {
    status.textContent = `\u5df2\u9023\u7dda\uff1a${lastHeartbeat.site}\n${new Date(lastHeartbeat.at).toLocaleString()}`;
  } else if (lastSync?.ok) {
    status.textContent = `\u5df2\u540c\u6b65 ${lastSync.count} \u7b46\n${new Date(lastSync.at).toLocaleString()}`;
  } else {
    status.textContent = lastHeartbeat?.error ? `\u9023\u7dda\u5931\u6557\uff1a${lastHeartbeat.error}` : "\u7b49\u5f85\u7db2\u7ad9\u9023\u7dda";
  }
  if (learnedAt) status.textContent += `\n\u822a\u6d77\u660e\u7d30\u8def\u5f91\u5df2\u5b78\u7fd2\uff1a${new Date(learnedAt).toLocaleString()}`;
  if (lastPoll?.ok) status.textContent += `\n\u80cc\u666f\u8b80\u53d6\u6210\u529f\uff1a${lastPoll.count} \u7b46 ${new Date(lastPoll.at).toLocaleString()}`;
  if (lastPoll && !lastPoll.ok) status.textContent += `\n\u80cc\u666f\u8b80\u53d6\u5931\u6557\uff1a${lastPoll.error}`;
});

document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
