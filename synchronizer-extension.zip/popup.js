const formatTime = (value) => value ? new Date(value).toLocaleString() : "—";

chrome.storage.local.get(
  ["lastSync", "lastHeartbeat", "lastPoll", "learnedAt", "syncToken", "installationId", "diagnosticDeviceLabel"],
  ({ lastSync, lastHeartbeat, lastPoll, learnedAt, syncToken, installationId, diagnosticDeviceLabel }) => {
    const deviceId = document.querySelector("#device-id");
    deviceId.textContent = installationId ? `裝置識別：${installationId}` : "裝置識別：尚未建立，請稍後重新開啟";
    const deviceLabel = document.querySelector("#device-label");
    deviceLabel.value = ["公司", "家裡"].includes(diagnosticDeviceLabel) ? diagnosticDeviceLabel : "";
    deviceLabel.disabled = false;
    deviceLabel.addEventListener("change", async () => {
      deviceLabel.disabled = true;
      try {
        await chrome.storage.local.set({ diagnosticDeviceLabel: deviceLabel.value });
        document.querySelector("#device-note").textContent = "名稱已儲存；診斷將依裝置分開回報，其他裝置不會覆蓋。";
      } catch {
        document.querySelector("#device-note").textContent = "名稱儲存失敗，請重新開啟後再試。";
      } finally {
        deviceLabel.disabled = false;
      }
    });
    const status = document.querySelector("#status");
    if (!syncToken) status.textContent = "尚未設定同步權杖";
    else if (lastHeartbeat?.ok) status.textContent = `已連線：${lastHeartbeat.site}\n${formatTime(lastHeartbeat.at)}`;
    else if (lastSync?.ok) status.textContent = `已同步 ${lastSync.count} 筆\n${formatTime(lastSync.at)}`;
    else status.textContent = lastHeartbeat?.error ? `連線失敗：${lastHeartbeat.error}` : "等待網站連線";

    if (learnedAt) status.textContent += `\n航海明細路徑已學習：${formatTime(learnedAt)}`;
    if (lastPoll?.ok) status.textContent += `\n背景讀取成功：${lastPoll.count} 筆 ${formatTime(lastPoll.at)}`;
    if (lastPoll && !lastPoll.ok) status.textContent += `\n背景讀取失敗：${lastPoll.error}`;

  }
);

document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
