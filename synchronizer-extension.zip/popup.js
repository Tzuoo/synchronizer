const formatTime = (value) => value ? new Date(value).toLocaleString() : "—";
const diagnosticNames = { "vs968.net": "風雲", "kd998.net": "喜" };

chrome.storage.local.get(
  ["lastSync", "lastHeartbeat", "lastPoll", "learnedAt", "syncToken", "siteDiagnostics"],
  ({ lastSync, lastHeartbeat, lastPoll, learnedAt, syncToken, siteDiagnostics = {} }) => {
    const status = document.querySelector("#status");
    if (!syncToken) status.textContent = "尚未設定同步權杖";
    else if (lastHeartbeat?.ok) status.textContent = `已連線：${lastHeartbeat.site}\n${formatTime(lastHeartbeat.at)}`;
    else if (lastSync?.ok) status.textContent = `已同步 ${lastSync.count} 筆\n${formatTime(lastSync.at)}`;
    else status.textContent = lastHeartbeat?.error ? `連線失敗：${lastHeartbeat.error}` : "等待網站連線";

    if (learnedAt) status.textContent += `\n航海明細路徑已學習：${formatTime(learnedAt)}`;
    if (lastPoll?.ok) status.textContent += `\n背景讀取成功：${lastPoll.count} 筆 ${formatTime(lastPoll.at)}`;
    if (lastPoll && !lastPoll.ok) status.textContent += `\n背景讀取失敗：${lastPoll.error}`;

    const diagnostics = document.querySelector("#diagnostics");
    diagnostics.replaceChildren(...Object.entries(diagnosticNames).map(([site, name]) => {
      const state = siteDiagnostics[site] || {};
      const card = document.createElement("section");
      card.className = "diagnostic-card";
      const upload = state.uploadAt
        ? (state.uploadOk ? `上傳成功 ${state.uploadCount || 0} 筆` : `上傳失敗：${state.uploadError || "未知錯誤"}`)
        : "尚無上傳紀錄";
      const title = document.createElement("strong");
      title.textContent = name;
      const frame = document.createElement("span");
      frame.className = state.frameOk ? "ok" : "warn";
      frame.textContent = state.frameOk ? "工作框正常" : "尚未偵測工作框";
      const poll = document.createElement("div");
      poll.textContent = state.pollState || "尚無背景讀取紀錄";
      const result = document.createElement("div");
      result.textContent = `解析：${state.parsedCount ?? "—"} 筆　${upload}`;
      const updated = document.createElement("small");
      updated.textContent = `最後更新：${formatTime(state.updatedAt)}`;
      card.append(title, frame, poll, result, updated);
      return card;
    }));
  }
);

document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
