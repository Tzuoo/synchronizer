function scrape(root = document) {
  const details = root.querySelector("#bet_details");
  if (!details) return [];

  const domain = rootDomain(location.hostname);
  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[domain] || domain;
  const bets = [];

  root.querySelectorAll("#bet_details .bet_group").forEach((group) => {
    const groupName = text(group, ".panel_title span") || "未分類";

    group.querySelectorAll(".bet_item").forEach((item) => {
      const number = text(item, ".bet_item_no").replace(/\s+/g, " ");
      const dateLine = text(item, ".bet_cnt > p.btm--gold");
      const date = (dateLine.match(/\d{4}-\d{2}-\d{2}/) || [""])[0];
      const time = text(item, ".bet_time");

      const placedAt =
        date && time
          ? `${date}T${time}+08:00`
          : new Date().toISOString();

      item
        .querySelectorAll(
          ".table .tr:not(.bg--title--black):not(.sumup_row)"
        )
        .forEach((row, rowIndex) => {
          const play = text(row, ".col-play");
          const content = text(row, ".col-content");

          if (!play && !content) return;

          const odds = numeric(text(row, ".col-odds"));
          const stake = numeric(text(row, ".col-money")) || 0;
          const carCount = numeric(text(row, ".col-unit"));
          const total = numeric(text(row, ".col-total"));
          // 僅六合台號的網站明細會以「本金 × 支數」形成該列下注額。
          // 大樂／539 台號的 .col-money 已是該列實際下注金額，不能再乘支數。
          // groupName 是網站原始盤口標題，不能只因玩法同為台號就猜成六合。
          const isWindSixTaihao = source === "風雲" &&
            /^六合\s*[／/]/.test(groupName) && play === "台號" && carCount > 0;
          const betAmount = isWindSixTaihao ? stake * carCount : stake;

          const rawId =
            `${hostname}|${groupName}|${number}|${date}|${time}|${rowIndex}|${play}|${content}`;

          bets.push(
            enrichedBet(
              {
                id: rawId,
                source,
                account: "",
                placedAt,
                event: groupName,
                selection: `${play} ${content}`.trim(),
                odds,
                stake,
                potentialPayout:
                  source === "風雲"
                    ? betAmount
                    : total,
                status: orderStatusFromText(closestText(item), closestText(row)),
                result: null,
                reconciled: false
              },
              {
                itemNumber: exactItemNumber(number),
                playType: play || groupName,
                unitAmount: stake || null,
                carCount: carCount > 0 ? carCount : null,
                betAmount:
                  source === "風雲"
                    ? betAmount
                    : (total ?? stake),
                rawText: closestText(row),
                parseStatus: "parsed"
              }
            )
          );
        });
    });
  });

  return bets;
}

function betRowNumberByHeader(row, label) {
  const header = row.closest(".table")?.querySelector(".bg--title--black");
  const index = [...(header?.children || [])].findIndex(cell =>
    String(cell.textContent || "").replace(/\s+/g, "") === label);
  const value = index >= 0 ? row.children[index]?.textContent?.trim() : "";
  return value && /^\d[\d,]*(?:\.\d+)?$/.test(value) ? Number(value.replace(/,/g, "")) : null;
}

function scrapeKdOrders(root = document) {
  if (rootDomain(location.hostname) !== "kd998.net") return [];

  const details = root.querySelector("#bet_details");
  if (!details) return [];

  const hostname = location.hostname.toLowerCase();
  const source = SITE_NAMES["kd998.net"];
  const bets = [];

  details.querySelectorAll(".bet_group").forEach((group) => {
    const groupName = text(group, ".panel_title span") || "下注明細";
    const groupId = group.id || groupName;

    group.querySelectorAll(".bet_item").forEach((item, itemIndex) => {
      const number = text(item, ".bet_item_no").replace(/\s+/g, " ");
      const dateLine = text(item, ".bet_cnt > p.btm--gold");
      const date = (dateLine.match(/\d{4}-\d{2}-\d{2}/) || [""])[0];
      const time = text(item, ".bet_time");
      if (!date || !time) return;

      const rows = [...item.querySelectorAll(".table .tr:not(.bg--title--black):not(.sumup_row)")]
        .map((row) => ({
          play: text(row, ".col-play"),
          content: text(row, ".col-content"),
          odds: numeric(text(row, ".col-odds")),
          principal: numeric(text(row, ".col-capital")),
          amount: numeric(text(row, ".col-money")),
          carsText: text(row, ".col-unit"),
          eachAmount: betRowNumberByHeader(row, "每碰金額"),
          combinationCount: betRowNumberByHeader(row, "碰數"),
          payout: numeric(text(row, ".col-total")),
          rawText: closestText(row)
        }))
        .filter((row) => row.play || row.content);
      if (!rows.length) return;

      const summary = item.querySelector(".table .sumup_row");
      const betAmount = numeric(text(summary, ".col-money"));
      const payout = numeric(text(summary, ".col-total"));
      const carCount = numeric(text(summary, ".col-unit"));
      const amounts = rows.map((row) => row.amount).filter((value) => value != null);
      const learnedCarUnits = {};
      rows.forEach((row) => {
        const cars = numeric(row.carsText);
        if (row.play && row.amount > 0 && cars > 0) learnedCarUnits[row.play] = row.amount / cars;
      });
      if (Object.keys(learnedCarUnits).length) {
        chrome.storage.local.get(["kdCarUnits"], ({ kdCarUnits = {} }) => {
          chrome.storage.local.set({ kdCarUnits: { ...kdCarUnits, ...learnedCarUnits } });
        });
      }
      const isSpecialPackage = rows.every(row => row.play === "特殊包牌");
      const unitAmount = isSpecialPackage
        ? (rows.every(row => row.eachAmount > 0 && row.eachAmount === rows[0].eachAmount) ? rows[0].eachAmount : null)
        : amounts.length === rows.length && amounts.every((value) => value === amounts[0])
        ? amounts[0]
        : null;
      const plays = [...new Set(rows.map((row) => row.play).filter(Boolean))];
      const playType = plays.join("／") || groupName;
      const selection = rows.map((row) => [
        row.play,
        row.content,
        row.amount == null ? "" : `下注金額 ${row.amount}`,
        row.carsText ? `車數 ${row.carsText}` : ""
      ].filter(Boolean).join("｜")).join("\n");
      const placedAt = `${date}T${time}+08:00`;

      bets.push(enrichedBet({
        id: `${hostname}|kd-batch|${groupId}|${number || itemIndex}|${date}|${time}`,
        source,
        account: "",
        placedAt,
        event: playType,
        selection,
        odds: rows.every((row) => row.odds === rows[0].odds) ? rows[0].odds : null,
        stake: unitAmount || 0,
        potentialPayout: payout,
        status: orderStatusFromText(closestText(item)),
        result: null,
        reconciled: false
      }, {
        itemNumber: exactItemNumber(number),
        playType,
        unitAmount,
        combinationCount: isSpecialPackage && rows.every(row => row.combinationCount > 0)
          ? rows.reduce((sum, row) => sum + row.combinationCount, 0) : null,
        carCount,
        betAmount: betAmount ?? amounts.reduce((sum, value) => sum + value, 0),
        principal: rows.reduce((sum, row) => sum + (row.principal || 0), 0) || null,
        rawText: [groupName, closestText(item)].join(" "),
        parseStatus: "parsed"
      }));
    });
  });

  return bets;
}

function closestText(node) {
  return (node?.textContent || "")
    .trim()
    .replace(/\s+/g, " ");
}

function scrapeGroupedReportFrom(root) {
  if (["amc283.com", "pee688.com"].includes(rootDomain(location.hostname))) return [];

  const pageText =
    root.body?.innerText ||
    root.body?.textContent ||
    "";

  if (!pageText.includes("分組序號報表")) return [];

  const domain = rootDomain(location.hostname);
  const hostname = location.hostname.toLowerCase();
  const source =
    HOST_NAMES[hostname] ||
    SITE_NAMES[domain] ||
    domain;

  const bets = [];
  const rows = [...root.querySelectorAll("tr")];

  let currentTicket = "";
  let currentTime = "";
  let currentEvent = "分組序號報表";

  rows.forEach((row, rowIndex) => {
    const cells = [
      ...row.querySelectorAll("td,th")
    ]
      .map(closestText)
      .filter(Boolean);

    const line = cells.join(" ");

    if (!line) return;

    const ticket =
      line.match(/[A-Z]\d{5,}\s*-\s*\d{3}/i) ||
      line.match(/\b\d{6,}\b/);

    if (ticket) {
      currentTicket = ticket[0].replace(/\s+/g, "");
    }

    const dateTime =
      line.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    if (dateTime) {
      currentTime =
        dateTime[0].replace(/\//g, "-");
    }

    const event =
      line.match(
        /(大樂|六合|539|天天樂|固定賠)/
      );

    if (event) {
      currentEvent = event[1];
    }

    const numericCells =
      cells.map(numeric);

    const hasMoney =
      numericCells.some(
        (n) => n && n > 0
      );

    const hasPlay =
      cells.some(
        (c) =>
          /正碼|特碼|台號|二星|三星|四星|全車|固定賠/.test(c)
      );

    const hasNumber =
      cells.some(
        (c) =>
          /^\d{1,2}$/.test(c) ||
          /^\d{3,4}$/.test(c)
      );

    if (
      !hasMoney ||
      (!hasPlay && !hasNumber)
    ) {
      return;
    }

    if (
      line.includes("總計") ||
      line.includes("小計") ||
      line.includes("列印")
    ) {
      return;
    }

    const play =
      cells.find(
        (c) =>
          /正碼|特碼|台號|二星|三星|四星|全車|固定賠/.test(c)
      ) ||
      currentEvent;

    const content =
      cells.find(
        (c) =>
          /^\d{1,2}$/.test(c) ||
          /^\d{3,4}$/.test(c) ||
          /\d{1,2}[,，]\d{1,2}/.test(c)
      ) ||
      "";

    const odds =
      numericCells.find(
        (n) =>
          n &&
          n > 1 &&
          n < 10000
      ) ||
      null;

    const stakeCandidates =
      numericCells.filter(
        (n) =>
          n &&
          n >= 1
      );

    const stake =
      stakeCandidates.length
        ? stakeCandidates[
            stakeCandidates.length - 1
          ]
        : 0;

    const placedAt =
      currentTime
        ? `${currentTime.replace(" ", "T")}+08:00`
        : new Date().toISOString();

    bets.push(
      enrichedBet(
        {
          id:
            `${hostname}|grouped|${currentTicket}|${currentTime}|${rowIndex}|${play}|${content}|${stake}`,
          source,
          account: "",
          placedAt,
          event:
            currentTicket
              ? `${currentEvent} / ${currentTicket}`
              : currentEvent,
          selection:
            `${play} ${content}`.trim(),
          odds,
          stake,
          potentialPayout: null,
          status: orderStatusFromText(line),
          result: null,
          reconciled: false
        },
        {
          itemNumber: itemNumberFromOrderContext(root, dateTime, play),
          playType: play,
          unitAmount:
            stake || null,
          betAmount:
            stake || null,
          rawText: line,
          parseStatus: "partial"
        }
      )
    );
  });

  return bets;
}
