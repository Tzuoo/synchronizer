importScripts("config.js");
const DASHBOARD = "https://live-bet-reconciliation.tsoyis0520.chatgpt.site";
const DEFAULT_ACCOUNTS = {
  "w0.188hot.net":"you320",
  "vs968.net":"a0593", "kd998.net":"a0593", "hyp98.com":"a6539",
  "188hot.net":"you320", "bnd139.com":"a0593",
  "umh693.com":"0593", "amc283.com":"a0593", "sk6688.net":"a0593",
  "nan688.com":"a6539", "la688.com":"a6539", "jgm258.com":"a0593",
  "bnm988.com":"380"
};

function rootDomain(hostname) {
  const parts = hostname.split(".");
  return parts.slice(-2).join(".");
}

function pruneLedgerSnapshotsForToday() {
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Taipei" }).format(new Date());
  return chrome.storage.local.get(["ledgerSnapshots"]).then(({ ledgerSnapshots = [] }) => {
    const current = ledgerSnapshots.filter((row) => row?.date === today);
    if (current.length !== ledgerSnapshots.length) {
      return chrome.storage.local.set({ ledgerSnapshots: current });
    }
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["syncToken", "detectedAccounts"], ({ syncToken, detectedAccounts = {} }) => {
    if (!syncToken && DEFAULT_SYNC_TOKEN) chrome.storage.local.set({ syncToken: DEFAULT_SYNC_TOKEN });
    // 1.6.31 曾把下單群組 Fxxxxxx 誤當成喜網站登入帳號；升級時移除錯誤快取。
    delete detectedAccounts["kd998.net"];
    Object.keys(detectedAccounts).forEach((key) => {
      if (key === "kd998.net" || key.endsWith(".kd998.net")) delete detectedAccounts[key];
    });
    chrome.storage.local.set({ detectedAccounts });
  });
});

chrome.runtime.onStartup.addListener(pruneLedgerSnapshotsForToday);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "REGISTER_ACTUAL_ACCOUNT" && message.account) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const account = String(message.account).trim();
    if (!hostname || !account) {
      sendResponse({ ok: false });
      return;
    }
    chrome.storage.local.get(["detectedAccounts"], ({ detectedAccounts = {} }) => {
      const detected = { account, at: new Date().toISOString() };
      detectedAccounts[hostname] = detected;
      detectedAccounts[domain] = detected;
      chrome.storage.local.set({ detectedAccounts })
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: String(error) }));
    });
    return true;
  }
  if (message?.type === "POLL_STATUS") {
    chrome.storage.local.set({ lastPoll: { ...message.state, at: new Date().toISOString() } })
      .then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "LEARN_DETAIL_REQUEST" && message.request) {
    const request = message.request;
    const key = request.root || rootDomain(request.host || "");
    chrome.storage.local.get(["learnedDetailRequests"], ({ learnedDetailRequests = {} }) => {
      learnedDetailRequests[key] = { ...request, learnedAt: new Date().toISOString() };
      chrome.storage.local.set({ learnedDetailRequests })
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: String(error) }));
    });
    return true;
  }
  if (message?.type === "STORE_LEDGER_SNAPSHOT" && Array.isArray(message.rows)) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    chrome.storage.local.get(
      ["ledgerSnapshots", "siteAccounts", "detectedAccounts"],
      ({ ledgerSnapshots = [], siteAccounts = {}, detectedAccounts = {} }) => {
        try {
          const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Taipei" }).format(new Date());
          const fallback = siteAccounts[hostname] || siteAccounts[domain] ||
            DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || "未設定";
          const detected = detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "";
          const incoming = message.rows
            .filter((row) => row && row.date === today)
            .map((row) => {
              const account = String(row.account || detected || fallback);
              const id = [domain || hostname, account, row.date, row.gameName, row.phaseName, row.playType].join("|");
              return { ...row, id, account, host: hostname, root: domain };
            });

          // 只保留台灣時間今天；相同鍵直接覆寫最新快照，輪詢不可累加。
          const latest = new Map(
            ledgerSnapshots
              .filter((row) => row?.date === today && row?.id)
              .map((row) => [row.id, row])
          );
          incoming.forEach((row) => latest.set(row.id, row));
          const next = [...latest.values()];
          chrome.storage.local.set({
            ledgerSnapshots: next,
            lastLedgerCapture: {
              ok: true,
              at: new Date().toISOString(),
              site: domain || hostname,
              count: incoming.length
            }
          })
            .then(() => sendResponse({ ok: true, count: incoming.length }))
            .catch((error) => sendResponse({ ok: false, error: String(error) }));
        } catch (error) {
          sendResponse({ ok: false, error: String(error) });
        }
      }
    );
    return true;
  }
  if (message?.type === "SYNC_HEARTBEAT") {
    pruneLedgerSnapshotsForToday().catch(() => {});
  }
  const isHeartbeat = message?.type === "SYNC_HEARTBEAT";
  if (!isHeartbeat && (message?.type !== "SYNC_BETS" || !Array.isArray(message.bets))) return;
  chrome.storage.local.get(
    ["syncToken", "siteAccounts", "detectedAccounts"],
    async ({ syncToken, siteAccounts = {}, detectedAccounts = {} }) => {
    if (!syncToken) {
      sendResponse({ ok: false, error: "尚未完成同步設定" });
      return;
    }
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const detected = domain === "kd998.net"
      ? ""
      : (detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "");
    const fallback = siteAccounts[hostname] || siteAccounts[domain] || DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || message.account || "未設定";
    const bets = isHeartbeat ? [] : message.bets.map((bet) => {
      const account = String(bet.account || detected || fallback);
      const originalId = String(bet.id || "");
      const separator = originalId.indexOf("|");
      const stableTail = separator >= 0 ? originalId.slice(separator + 1) : originalId;
      // 網站會更換 w0 / w1 / w3 等子網域。訂單 ID 使用主網域與實際帳號，
      // 避免同一帳號的同一筆下注因換入口網址而被當成新資料。
      const stableId = `${domain || hostname}|${account}|${stableTail}`;
      return { ...bet, id: stableId, account };
    });
    try {
      const response = await fetch(`${DASHBOARD}/api/bets`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": `Bearer ${syncToken}`,
          "OAI-Sites-Authorization": `Bearer ${syncToken}`
        },
        body: JSON.stringify({ bets })
      });
      const result = await response.json().catch(() => ({}));
      const state = { ok: response.ok, at: new Date().toISOString(), count: bets.length, error: response.ok ? "" : (result.error || `HTTP ${response.status}`) };
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
      }
      sendResponse(state);
    } catch (error) {
      const state = { ok: false, at: new Date().toISOString(), count: 0, error: String(error) };
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
      }
      sendResponse(state);
    }
    }
  );
  return true;
});
