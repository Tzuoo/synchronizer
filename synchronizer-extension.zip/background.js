importScripts("config.js");
importScripts("diagnostics.js");
const DASHBOARD = "https://live-bet-reconciliation.tsoyis0520.chatgpt.site";
const DEFAULT_ACCOUNTS = {
  "w0.188hot.net":"you320",
  "vs968.net":"a0593", "kd998.net":"a0593", "hyp98.com":"a6539",
  "188hot.net":"you320", "bnd139.com":"a0593",
  "umh693.com":"0593", "and539.com":"0593", "amc283.com":"a0593", "pee688.com":"a0593", "sk6688.net":"a0593",
  "nan688.com":"a6539", "la688.com":"a6539", "jgm258.com":"a0593",
  "bnm988.com":"380"
};

const BACKGROUND_ALARM = "synchronizer-background-poll";
const LOCAL_PREVIEW_CACHE = "http://127.0.0.1:8765/__sync/cache";
const fullCarFrames = new Map();
const quoteFrames = new Map();
const fullCarFrameKey = (report) => [report.root, report.game, report.playType].join('|');
let localPreviewRefreshPromise = null;
let localPreviewRefreshAt = 0;
function utf8Base64(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 32768) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
  }
  return btoa(binary);
}
async function refreshLocalPreviewCache(force = false) {
  if (localPreviewRefreshPromise) return localPreviewRefreshPromise;
  if (!force && Date.now() - localPreviewRefreshAt < 2000) return;
  localPreviewRefreshAt = Date.now();
  localPreviewRefreshPromise = (async () => {
    const { syncToken } = await chrome.storage.local.get(['syncToken']);
    if (!syncToken) return;
    const response = await fetch(`${DASHBOARD}/api/extension-preview`, {
      headers: { authorization: `Bearer ${syncToken}`, 'OAI-Sites-Authorization': `Bearer ${syncToken}` }
    });
    if (!response.ok) return;
    const payload = await response.json().catch(() => ({}));
    if (!Array.isArray(payload.bets)) return;
    await fetch(LOCAL_PREVIEW_CACHE, {
      method: 'POST',
      headers: { 'content-type': 'text/plain', 'x-sync-encoding': 'base64' },
      body: utf8Base64(JSON.stringify({ bets: payload.bets }))
    });
  })().catch(() => {}).finally(() => { localPreviewRefreshPromise = null; });
  return localPreviewRefreshPromise;
}

// 舊版全車頁的「加入注單」會一次讀取整張表格；同一網站的不同號碼若
// 拆成連續點擊，第二次起可能被網站的更新鎖忽略。合併不同號碼為一次
// 表格寫入，但遇到相同號碼時另開批次，保留使用者刻意輸入的重複下注。
function batchFullCarTargets(targets) {
  const batches = [];
  const currentBySite = new Map();
  for (const target of targets) {
    const key = [target?.channel, target?.root, target?.game, target?.playType].join('|');
    for (const order of Array.isArray(target?.orders) ? target.orders : []) {
      let batch = currentBySite.get(key);
      if (!batch || batch.orders.some((item) => item.number === order.number)) {
        batch = { ...target, orders: [], tiedCount: 0 };
        batches.push(batch);
        currentBySite.set(key, batch);
      }
      batch.orders.push(order);
      if (target.tied) batch.tiedCount += 1;
    }
  }
  return batches;
}
chrome.alarms.create(BACKGROUND_ALARM, { periodInMinutes: 1 });
chrome.runtime.onStartup.addListener(() => refreshLocalPreviewCache(true).catch(() => {}));
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== BACKGROUND_ALARM) return;
  refreshLocalPreviewCache(true).catch(() => {});
  flushRemoteDiagnostics().catch(() => {});
  chrome.tabs.query({}).then(async (tabs) => {
    await Promise.allSettled(tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) => chrome.tabs.sendMessage(tab.id, { type: "SYNC_BACKGROUND_TICK" })));
    const { siteDiagnostics = {} } = await chrome.storage.local.get(['siteDiagnostics']);
    const roots = new Set(tabs.flatMap(tab => { try { return [rootDomain(new URL(tab.url).hostname)]; } catch { return []; } }));
    for (const site of ['vs968.net', 'kd998.net']) {
      if (roots.has(site) && Date.now() - (Date.parse(siteDiagnostics[site]?.stages?.frame?.eventAt) || 0) > 120000) {
        await updateSiteDiagnostic(site, { event: { stage: 'frame', code: 'WAIT_FRAME' } });
      }
    }
  }).catch(() => {});
});

let diagnosticQueue = Promise.resolve();
function updateSiteDiagnostic(site, patch) {
  const task = diagnosticQueue.then(() => writeSiteDiagnostic(site, patch));
  diagnosticQueue = task.catch(() => {});
  return task;
}
async function writeSiteDiagnostic(site, patch) {
  const key = rootDomain(String(site || "").toLowerCase());
  if (!key) return;
  const { siteDiagnostics = {} } = await chrome.storage.local.get(["siteDiagnostics"]);
  const now = new Date().toISOString();
  const stages = { ...(siteDiagnostics[key]?.stages || {}) };
  const legacy = siteDiagnostics[key];
  if (!stages.upload && legacy?.uploadAt && typeof legacy.uploadOk === 'boolean' && Number.isFinite(Date.parse(legacy.uploadAt))) {
    stages.upload = SyncDiagnostics.record({}, { stage: 'upload', code: legacy.uploadOk ? 'OK' : SyncDiagnostics.errorCode(legacy.uploadError, 'UPLOAD_FAILED'), count: legacy.uploadCount }, legacy.uploadAt);
  }
  const events = [];
  if (patch.frameOk === true) events.push({ stage: 'frame', code: 'OK' });
  if (patch.requestReady === false) events.push({ stage: 'read', code: 'WAIT_REQUEST' });
  if (patch.responseOk === true) events.push({ stage: 'read', code: 'OK' }, { stage: 'parse', code: patch.parsedCount ? 'OK' : 'EMPTY', count: patch.parsedCount });
  if (typeof patch.uploadOk === 'boolean') events.push({ stage: 'upload', code: patch.uploadOk ? 'OK' : SyncDiagnostics.errorCode(patch.uploadError, 'UPLOAD_FAILED'), count: patch.uploadCount });
  if (patch.event) events.push(patch.event);
  for (const event of events) {
    const next = SyncDiagnostics.record(stages[event.stage], event, now);
    if (next.eventAt) stages[event.stage] = next;
  }
  const { event: ignoredEvent, ...localPatch } = patch;
  siteDiagnostics[key] = {
    ...(siteDiagnostics[key] || {}),
    ...localPatch,
    stages,
    site: key,
    extensionVersion: chrome.runtime.getManifest().version,
    updatedAt: now
  };
  await chrome.storage.local.set({ siteDiagnostics });
}

let diagnosticUploadBusy = false;
async function flushRemoteDiagnostics() {
  if (diagnosticUploadBusy) return;
  diagnosticUploadBusy = true;
  try {
    await diagnosticQueue;
    const legacy = await chrome.storage.local.get(['siteDiagnostics']);
    for (const [site, value] of Object.entries(legacy.siteDiagnostics || {})) {
      if (!value.stages && value.uploadAt) await updateSiteDiagnostic(site, {});
    }
    const { syncToken, installationId, diagnosticDeviceLabel, siteDiagnostics } = await chrome.storage.local.get(['syncToken', 'installationId', 'diagnosticDeviceLabel', 'siteDiagnostics']);
    if (!syncToken) return;
    const rows = SyncDiagnostics.rows(siteDiagnostics);
    if (!rows.length) return;
    const response = await fetch(`${DASHBOARD}/api/diagnostics`, {
      method: 'POST', signal: AbortSignal.timeout(15000),
      headers: { 'content-type': 'application/json', authorization: `Bearer ${syncToken}`, 'OAI-Sites-Authorization': `Bearer ${syncToken}` },
      body: JSON.stringify({ installationId: await getInstallationId(installationId), deviceLabel: ['公司', '家裡'].includes(diagnosticDeviceLabel) ? diagnosticDeviceLabel : '', extensionVersion: chrome.runtime.getManifest().version, rows })
    });
    await chrome.storage.local.set({ diagnosticRemoteUpload: { ok: response.ok, at: new Date().toISOString() } });
  } catch {
    // Retain local errors and retry next alarm; never generate a notification.
    await chrome.storage.local.set({ diagnosticRemoteUpload: { ok: false, at: new Date().toISOString() } });
  } finally { diagnosticUploadBusy = false; }
}

function rootDomain(hostname) {
  const parts = hostname.split(".");
  return parts.slice(-2).join(".");
}

// A07 有些站會把同一期寫成「【C115220】」，另一些回應則是
// 「C115220」。這只是外框格式，不是另一個期別；必須在建立快照鍵前
// 統一，否則輪詢會把同一期玩法加兩次。
function canonicalLedgerPhaseName(value) {
  let text = String(value || "").replace(/\u00a0/g, " ").replace(/[>＞]\s*$/, "").trim();
  let previous = "";
  while (text && text !== previous) {
    previous = text;
    const paired = text.match(/^[【\[（(]\s*(.*?)\s*[】\]）)]$/);
    if (paired) text = paired[1].trim();
  }
  const match = text.match(/^第\s*(.+?)\s*期$/);
  return match ? match[1].trim() : text;
}

function clientSiteKey(installationId, domain) {
  return `${String(installationId || "").trim()}|${String(domain || "").trim()}`;
}

function stableBetTail(bet, fallbackTail, occurrence) {
  const itemNumber = String(bet?.itemNumber || "").trim();
  const placedAt = String(bet?.placedAt || "").trim();
  const event = String(bet?.event || "").trim();
  const selection = String(bet?.selection || "").replace(/\s+/g, " ").trim();
  // 有網站把金額放在舊 ID 最後一段；金額被畫面暫時解析錯誤時會變成
  // 新訂單。來源實際項次、時間、玩法與內容齊全時改用它們作為穩定鍵。
  // 同一項內真正完全相同的兩列仍保留 occurrence，不能任意合併。
  if (itemNumber && placedAt && event && selection) {
    return `source-item|${itemNumber}|${placedAt}|${event}|${selection}|${occurrence}`;
  }
  return fallbackTail;
}

let installationIdPromise;

async function getInstallationId(existingId) {
  const current = String(existingId || "").trim();
  if (current) return current;
  if (!installationIdPromise) {
    installationIdPromise = chrome.storage.local.get(["installationId"]).then(async ({ installationId }) => {
      const stored = String(installationId || "").trim();
      if (stored) return stored;
      const created = crypto.randomUUID();
      await chrome.storage.local.set({ installationId: created });
      return created;
    });
  }
  return installationIdPromise;
}

async function uploadLedgerRows(rows, syncToken) {
  const response = await fetch(`${DASHBOARD}/api/ledger`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${syncToken}`,
      "OAI-Sites-Authorization": `Bearer ${syncToken}`
    },
    body: JSON.stringify({ rows })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
  return result;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["syncToken", "detectedAccounts", "installationId"], async ({ syncToken, detectedAccounts = {}, installationId }) => {
    if (!syncToken && DEFAULT_SYNC_TOKEN) {
      syncToken = DEFAULT_SYNC_TOKEN;
      await chrome.storage.local.set({ syncToken });
    }
    await getInstallationId(installationId);
    // 1.6.31 曾把下單群組 Fxxxxxx 誤當成喜網站登入帳號；升級時移除錯誤快取。
    Object.keys(detectedAccounts).forEach((key) => {
      if (key === "kd998.net" || key.endsWith(".kd998.net")) delete detectedAccounts[key];
    });
    await chrome.storage.local.set({ detectedAccounts });
    refreshLocalPreviewCache(true).catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "QUOTE_REPORT" && message.report && Number.isInteger(sender?.tab?.id)) {
    const report = { ...message.report, tabId: sender.tab.id, frameId: sender.frameId, receivedAt: Date.now() };
    quoteFrames.set([report.root, report.game, report.playType].join('|'), report);
    sendResponse({ ok: true });
    return;
  }
  if (message?.type === "GET_QUOTE_REPORTS") {
    const reports = [...quoteFrames.values()].filter((report) => Date.now() - report.receivedAt < 10000);
    sendResponse({ ok: true, reports });
    return;
  }
  if (message?.type === "FULL_CAR_REPORT" && message.report && Number.isInteger(sender?.tab?.id)) {
    const report = { ...message.report, tabId: sender.tab.id, frameId: sender.frameId, receivedAt: Date.now() };
    fullCarFrames.set(fullCarFrameKey(report), report);
    sendResponse({ ok: true });
    return;
  }
  if (message?.type === "GET_FULL_CAR_REPORTS") {
    const reports = [...fullCarFrames.values()].filter((report) => Date.now() - report.receivedAt < 10000);
    sendResponse({ ok: true, reports });
    return;
  }
  if (message?.type === "PLAN_FULL_CAR" && Array.isArray(message.orders)) {
    const game = String(message.game || '539');
    const playType = String(message.playType || '全車');
    const reports = [
      ...[...fullCarFrames.values()].filter((report) => Date.now() - report.receivedAt < 10000 && report.game === game && report.playType === playType),
      ...[...quoteFrames.values()].filter((report) => Date.now() - report.receivedAt < 10000 && report.game === game && report.playType === playType)
    ].filter((report, index, all) => all.findIndex((item) => item.root === report.root) === index);
    chrome.storage.local.get(["fullCarTieCounts"], ({ fullCarTieCounts = {} }) => {
      try {
        if (!reports.length) throw new Error(`目前沒有已開啟且可取得 ${game} ${playType} 報價的網站`);
        const counts = { ...fullCarTieCounts }, plan = [];
        for (const order of message.orders) {
          const priced = reports.map((report) => ({ report, price: report.quotes?.[order.number] })).filter((row) => Number.isFinite(row.price));
          if (!priced.length) throw new Error(`${order.number} 無法從已開啟網站取得本金`);
          const minimum = Math.min(...priced.map((row) => row.price));
          const choices = priced.filter((row) => row.price === minimum);
          const least = Math.min(...choices.map((row) => Number(counts[row.report.root]) || 0));
          const candidates = choices.filter((row) => (Number(counts[row.report.root]) || 0) === least);
          const chosen = candidates[Math.floor(Math.random() * candidates.length)], tied = choices.length > 1;
          if (tied) counts[chosen.report.root] = (Number(counts[chosen.report.root]) || 0) + 1;
          plan.push({ root: chosen.report.root, siteName: chosen.report.siteName, phase: chosen.report.phase,
            channel: quoteFrames.has([chosen.report.root, game, playType].join('|')) ? "quote" : "fullCar", game, playType,
            orders: [{ number: order.number, cars: order.cars, value: order.cars, price: chosen.price }], tied });
        }
        sendResponse({ ok: true, plan });
      } catch (error) { sendResponse({ ok: false, error: String(error?.message || error) }); }
    });
    return true;
  }
  if (message?.type === "FULL_CAR_ADD_SEQUENCE" && Array.isArray(message.targets)) {
    (async () => {
      const targets = batchFullCarTargets(message.targets);
      if (!targets.length) throw new Error("沒有可加入清單的號碼");
      const results = [];
      for (const target of targets) {
        const frame = target.channel === "quote" ? quoteFrames.get([target.root, target.game, target.playType].join('|')) : fullCarFrames.get(fullCarFrameKey(target));
        if (!frame || Date.now() - frame.receivedAt >= 10000) throw new Error(`${target.siteName || target.root}：網站目前未連線`);
        const preflight = await chrome.tabs.sendMessage(frame.tabId, target.channel === "quote"
          ? { type: "QUOTE_PREFLIGHT", game: target.game, playType: target.playType, orders: target.orders }
          : { type: "FULL_CAR_PREFLIGHT", root: target.root, game: target.game, playType: target.playType, orders: target.orders }, { frameId: frame.frameId });
        if (!preflight?.ok) throw new Error(`${target.siteName || target.root}：${preflight?.error || "加入前檢查失敗"}`);
      }
      for (const target of targets) {
        const frame = target.channel === "quote" ? quoteFrames.get([target.root, target.game, target.playType].join('|')) : fullCarFrames.get(fullCarFrameKey(target));
        const added = await chrome.tabs.sendMessage(frame.tabId, target.channel === "quote"
          ? { type: "QUOTE_ADD_CART", game: target.game, playType: target.playType, orders: target.orders }
          : { type: "FULL_CAR_ADD_CART", root: target.root, game: target.game, playType: target.playType, orders: target.orders }, { frameId: frame.frameId });
        if (!added?.ok) throw new Error(`${target.siteName || target.root}：${added?.error || "加入清單失敗"}`);
        results.push({ root: target.root, ok: true });
        if (target.tiedCount) {
          const { fullCarTieCounts = {} } = await chrome.storage.local.get(["fullCarTieCounts"]);
          fullCarTieCounts[target.root] = (Number(fullCarTieCounts[target.root]) || 0) + target.tiedCount;
          await chrome.storage.local.set({ fullCarTieCounts });
        }
      }
      sendResponse({ ok: true, results });
    })().catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }
  if (message?.type === "FULL_CAR_COMMAND" && ["FULL_CAR_PREFLIGHT", "FULL_CAR_ADD_CART"].includes(message.command)) {
    const targets = Array.isArray(message.targets) ? message.targets : [];
    Promise.all(targets.map(async (target) => {
      const frame = fullCarFrames.get(fullCarFrameKey({ root: target.root, game: target.game || '539', playType: target.playType || '全車' }));
      if (!frame || Date.now() - frame.receivedAt >= 10000) return { root: target.root, ok: false, error: "網站全車頁未連線" };
      try {
        const result = await chrome.tabs.sendMessage(frame.tabId, {
          type: message.command, root: target.root, orders: target.orders
        }, { frameId: frame.frameId });
        return { root: target.root, ...(result || { ok: false, error: "網站未回應" }) };
      } catch (error) { return { root: target.root, ok: false, error: String(error) }; }
    })).then((results) => sendResponse({ ok: results.every((row) => row.ok), results }));
    return true;
  }
  if (message?.type === "SITE_DIAGNOSTIC" && message.state) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    updateSiteDiagnostic(hostname, message.state)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  }
  if (message?.type === "REGISTER_ACTUAL_ACCOUNT" && message.account) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const account = String(message.account).trim();
    if (!hostname || !account) {
      sendResponse({ ok: false });
      return;
    }
    chrome.storage.local.get(["detectedAccounts"], ({ detectedAccounts = {} }) => {
      const detected = { account, at: new Date().toISOString() };
      detectedAccounts[hostname] = detected;
      detectedAccounts[domain] = detected;
      chrome.storage.local.set({ detectedAccounts })
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: String(error) }));
    });
    return true;
  }
  if (message?.type === "POLL_STATUS") {
    chrome.storage.local.set({ lastPoll: { ...message.state, at: new Date().toISOString() } })
      .then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "LEARN_DETAIL_REQUEST" && message.request) {
    const request = message.request;
    const key = request.root || rootDomain(request.host || "");
    chrome.storage.local.get(["learnedDetailRequests"], ({ learnedDetailRequests = {} }) => {
      learnedDetailRequests[key] = { ...request, learnedAt: new Date().toISOString() };
      chrome.storage.local.set({ learnedDetailRequests })
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: String(error) }));
    });
    return true;
  }
  if (message?.type === "STORE_LEDGER_SNAPSHOT" && Array.isArray(message.rows)) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    chrome.storage.local.get(
      ["ledgerSnapshots", "siteAccounts", "detectedAccounts", "syncToken", "installationId"],
      async ({ ledgerSnapshots = [], siteAccounts = {}, detectedAccounts = {}, syncToken, installationId }) => {
        try {
          const fallback = siteAccounts[hostname] || siteAccounts[domain] ||
            DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || "未設定";
          const detected = detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "";
          const clientId = await getInstallationId(installationId);
          const clientSite = clientSiteKey(clientId, domain || hostname);
          const incoming = message.rows
            .filter((row) => row && row.date)
            .map((row, sourceOrder) => {
              const account = String(row.account || detected || fallback);
              const phaseName = canonicalLedgerPhaseName(row.phaseName);
              const id = [clientSite, account, row.date, row.gameName, phaseName, row.playType].join("|");
              return { ...row, id, account, phaseName, host: hostname, root: clientSite, sourceRoot: domain, sourceOrder };
            });

          // 網站仍顯示的跨日資料也必須保留；相同鍵只覆寫最新快照，輪詢不可累加。
          const latest = new Map(
            ledgerSnapshots
              .filter((row) => row?.id)
              .map((row) => [row.id, row])
          );
          incoming.forEach((row) => latest.set(row.id, row));
          const next = [...latest.values()];
          await chrome.storage.local.set({
            ledgerSnapshots: next,
            lastLedgerCapture: {
              ok: true,
              at: new Date().toISOString(),
              site: domain || hostname,
              count: incoming.length
            }
          });
          if (!syncToken) throw new Error("尚未完成同步設定");
          const result = await uploadLedgerRows(incoming.map((row) => ({ ...row, site: row.source })), syncToken);
          await chrome.storage.local.set({ lastLedgerUpload: { ok: true, at: new Date().toISOString(), count: result.accepted } });
          await updateSiteDiagnostic(domain, { event: { stage: 'ledgerUpload', code: 'OK', count: incoming.length } });
          sendResponse({ ok: true, count: incoming.length, uploaded: result.accepted });
        } catch (error) {
          await updateSiteDiagnostic(domain, { event: { stage: 'ledgerUpload', code: SyncDiagnostics.errorCode(error, 'UPLOAD_FAILED') } });
          sendResponse({ ok: false, error: String(error) });
        }
      }
    );
    return true;
  }
  const isHeartbeat = message?.type === "SYNC_HEARTBEAT";
  if (!isHeartbeat && (message?.type !== "SYNC_BETS" || !Array.isArray(message.bets))) return;
  chrome.storage.local.get(
    ["syncToken", "siteAccounts", "detectedAccounts", "installationId"],
    async ({ syncToken, siteAccounts = {}, detectedAccounts = {}, installationId }) => {
    if (!syncToken) {
      sendResponse({ ok: false, error: "尚未完成同步設定" });
      return;
    }
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const detected = domain === "kd998.net"
      ? ""
      : (detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "");
    const fallback = siteAccounts[hostname] || siteAccounts[domain] || DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || message.account || "未設定";
    const clientId = await getInstallationId(installationId);
    const clientSite = clientSiteKey(clientId, domain || hostname);
    const sourceOccurrences = new Map();
    const bets = isHeartbeat ? [] : message.bets.map((bet) => {
      const account = String(bet.account || detected || fallback);
      const originalId = String(bet.id || "");
      const separator = originalId.indexOf("|");
      const stableTail = separator >= 0 ? originalId.slice(separator + 1) : originalId;
      const itemKey = [String(bet.itemNumber || ""), String(bet.placedAt || ""), String(bet.event || ""), String(bet.selection || "")].join("\u0000");
      const occurrence = sourceOccurrences.get(itemKey) || 0;
      sourceOccurrences.set(itemKey, occurrence + 1);
      // 網站會更換 w0 / w1 / w3 等子網域。訂單 ID 使用主網域與實際帳號，
      // 避免同一帳號的同一筆下注因換入口網址而被當成新資料。
      const stableId = `${clientSite}|${account}|${stableBetTail(bet, stableTail, occurrence)}`;
      return { ...bet, id: stableId, account };
    });
    try {
      const response = await fetch(`${DASHBOARD}/api/bets`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": `Bearer ${syncToken}`,
          "OAI-Sites-Authorization": `Bearer ${syncToken}`
        },
        body: JSON.stringify({
          bets,
          client: {
            installationId: clientId,
            extensionVersion: chrome.runtime.getManifest().version,
            site: clientSite
          }
        })
      });
      const result = await response.json().catch(() => ({}));
      const state = { ok: response.ok, at: new Date().toISOString(), count: bets.length, error: response.ok ? "" : (result.error || `HTTP ${response.status}`) };
      if (response.ok) refreshLocalPreviewCache().catch(() => {});
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
        await updateSiteDiagnostic(domain, { event: { stage: 'heartbeat', code: state.ok ? 'OK' : SyncDiagnostics.errorCode(state.error, 'UPLOAD_FAILED') } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
        await updateSiteDiagnostic(domain || hostname, {
          uploadOk: state.ok,
          uploadAt: state.at,
          uploadCount: state.count,
          uploadError: state.error
        });
      }
      sendResponse(state);
    } catch (error) {
      const state = { ok: false, at: new Date().toISOString(), count: 0, error: String(error) };
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
        await updateSiteDiagnostic(domain, { event: { stage: 'heartbeat', code: SyncDiagnostics.errorCode(state.error, 'UPLOAD_FAILED') } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
        await updateSiteDiagnostic(domain || hostname, {
          uploadOk: false,
          uploadAt: state.at,
          uploadCount: 0,
          uploadError: state.error
        });
      }
      sendResponse(state);
    }
    }
  );
  return true;
});
