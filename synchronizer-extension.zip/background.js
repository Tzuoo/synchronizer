importScripts("config.js");
importScripts("diagnostics.js");
const DASHBOARD = "https://live-bet-reconciliation.tsoyis0520.chatgpt.site";
const DEFAULT_ACCOUNTS = {
  "w0.188hot.net":"you320",
  "vs968.net":"a0593", "kd998.net":"a0593", "hyp98.com":"a6539",
  "188hot.net":"you320", "bnd139.com":"a0593",
  "umh693.com":"0593", "amc283.com":"a0593", "pee688.com":"a0593", "sk6688.net":"a0593",
  "nan688.com":"a6539", "la688.com":"a6539", "jgm258.com":"a0593",
  "bnm988.com":"380"
};

const BACKGROUND_ALARM = "synchronizer-background-poll";
chrome.alarms.create(BACKGROUND_ALARM, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== BACKGROUND_ALARM) return;
  flushRemoteDiagnostics().catch(() => {});
  chrome.tabs.query({}).then(async (tabs) => {
    await Promise.allSettled(tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) => chrome.tabs.sendMessage(tab.id, { type: "SYNC_BACKGROUND_TICK" })));
    const { siteDiagnostics = {} } = await chrome.storage.local.get(['siteDiagnostics']);
    const roots = new Set(tabs.flatMap(tab => { try { return [rootDomain(new URL(tab.url).hostname)]; } catch { return []; } }));
    for (const site of ['vs968.net', 'kd998.net']) {
      if (roots.has(site) && Date.now() - (Date.parse(siteDiagnostics[site]?.stages?.frame?.eventAt) || 0) > 120000) {
        await updateSiteDiagnostic(site, { event: { stage: 'frame', code: 'WAIT_FRAME' } });
      }
    }
  }).catch(() => {});
});

let diagnosticQueue = Promise.resolve();
function updateSiteDiagnostic(site, patch) {
  const task = diagnosticQueue.then(() => writeSiteDiagnostic(site, patch));
  diagnosticQueue = task.catch(() => {});
  return task;
}
async function writeSiteDiagnostic(site, patch) {
  const key = rootDomain(String(site || "").toLowerCase());
  if (!key) return;
  const { siteDiagnostics = {} } = await chrome.storage.local.get(["siteDiagnostics"]);
  const now = new Date().toISOString();
  const stages = { ...(siteDiagnostics[key]?.stages || {}) };
  const legacy = siteDiagnostics[key];
  if (!stages.upload && legacy?.uploadAt && typeof legacy.uploadOk === 'boolean' && Number.isFinite(Date.parse(legacy.uploadAt))) {
    stages.upload = SyncDiagnostics.record({}, { stage: 'upload', code: legacy.uploadOk ? 'OK' : SyncDiagnostics.errorCode(legacy.uploadError, 'UPLOAD_FAILED'), count: legacy.uploadCount }, legacy.uploadAt);
  }
  const events = [];
  if (patch.frameOk === true) events.push({ stage: 'frame', code: 'OK' });
  if (patch.requestReady === false) events.push({ stage: 'read', code: 'WAIT_REQUEST' });
  if (patch.responseOk === true) events.push({ stage: 'read', code: 'OK' }, { stage: 'parse', code: patch.parsedCount ? 'OK' : 'EMPTY', count: patch.parsedCount });
  if (typeof patch.uploadOk === 'boolean') events.push({ stage: 'upload', code: patch.uploadOk ? 'OK' : SyncDiagnostics.errorCode(patch.uploadError, 'UPLOAD_FAILED'), count: patch.uploadCount });
  if (patch.event) events.push(patch.event);
  for (const event of events) {
    const next = SyncDiagnostics.record(stages[event.stage], event, now);
    if (next.eventAt) stages[event.stage] = next;
  }
  const { event: ignoredEvent, ...localPatch } = patch;
  siteDiagnostics[key] = {
    ...(siteDiagnostics[key] || {}),
    ...localPatch,
    stages,
    site: key,
    extensionVersion: chrome.runtime.getManifest().version,
    updatedAt: now
  };
  await chrome.storage.local.set({ siteDiagnostics });
}

let diagnosticUploadBusy = false;
async function flushRemoteDiagnostics() {
  if (diagnosticUploadBusy) return;
  diagnosticUploadBusy = true;
  try {
    await diagnosticQueue;
    const legacy = await chrome.storage.local.get(['siteDiagnostics']);
    for (const [site, value] of Object.entries(legacy.siteDiagnostics || {})) {
      if (!value.stages && value.uploadAt) await updateSiteDiagnostic(site, {});
    }
    const { syncToken, installationId, diagnosticDeviceLabel, siteDiagnostics } = await chrome.storage.local.get(['syncToken', 'installationId', 'diagnosticDeviceLabel', 'siteDiagnostics']);
    if (!syncToken) return;
    const rows = SyncDiagnostics.rows(siteDiagnostics);
    if (!rows.length) return;
    const response = await fetch(`${DASHBOARD}/api/diagnostics`, {
      method: 'POST', signal: AbortSignal.timeout(15000),
      headers: { 'content-type': 'application/json', authorization: `Bearer ${syncToken}`, 'OAI-Sites-Authorization': `Bearer ${syncToken}` },
      body: JSON.stringify({ installationId: await getInstallationId(installationId), deviceLabel: ['公司', '家裡'].includes(diagnosticDeviceLabel) ? diagnosticDeviceLabel : '', extensionVersion: chrome.runtime.getManifest().version, rows })
    });
    await chrome.storage.local.set({ diagnosticRemoteUpload: { ok: response.ok, at: new Date().toISOString() } });
  } catch {
    // Retain local errors and retry next alarm; never generate a notification.
    await chrome.storage.local.set({ diagnosticRemoteUpload: { ok: false, at: new Date().toISOString() } });
  } finally { diagnosticUploadBusy = false; }
}

function rootDomain(hostname) {
  const parts = hostname.split(".");
  return parts.slice(-2).join(".");
}

let installationIdPromise;

async function getInstallationId(existingId) {
  const current = String(existingId || "").trim();
  if (current) return current;
  if (!installationIdPromise) {
    installationIdPromise = chrome.storage.local.get(["installationId"]).then(async ({ installationId }) => {
      const stored = String(installationId || "").trim();
      if (stored) return stored;
      const created = crypto.randomUUID();
      await chrome.storage.local.set({ installationId: created });
      return created;
    });
  }
  return installationIdPromise;
}

async function uploadLedgerRows(rows, syncToken) {
  const response = await fetch(`${DASHBOARD}/api/ledger`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${syncToken}`,
      "OAI-Sites-Authorization": `Bearer ${syncToken}`
    },
    body: JSON.stringify({ rows })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
  return result;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["syncToken", "detectedAccounts", "installationId"], async ({ syncToken, detectedAccounts = {}, installationId }) => {
    if (!syncToken && DEFAULT_SYNC_TOKEN) chrome.storage.local.set({ syncToken: DEFAULT_SYNC_TOKEN });
    await getInstallationId(installationId);
    // 1.6.31 曾把下單群組 Fxxxxxx 誤當成喜網站登入帳號；升級時移除錯誤快取。
    delete detectedAccounts["kd998.net"];
    Object.keys(detectedAccounts).forEach((key) => {
      if (key === "kd998.net" || key.endsWith(".kd998.net")) delete detectedAccounts[key];
    });
    chrome.storage.local.set({ detectedAccounts });
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "SITE_DIAGNOSTIC" && message.state) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    updateSiteDiagnostic(hostname, message.state)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  }
  if (message?.type === "REGISTER_ACTUAL_ACCOUNT" && message.account) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const account = String(message.account).trim();
    if (!hostname || !account) {
      sendResponse({ ok: false });
      return;
    }
    chrome.storage.local.get(["detectedAccounts"], ({ detectedAccounts = {} }) => {
      const detected = { account, at: new Date().toISOString() };
      detectedAccounts[hostname] = detected;
      detectedAccounts[domain] = detected;
      chrome.storage.local.set({ detectedAccounts })
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: String(error) }));
    });
    return true;
  }
  if (message?.type === "POLL_STATUS") {
    chrome.storage.local.set({ lastPoll: { ...message.state, at: new Date().toISOString() } })
      .then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "LEARN_DETAIL_REQUEST" && message.request) {
    const request = message.request;
    const key = request.root || rootDomain(request.host || "");
    chrome.storage.local.get(["learnedDetailRequests"], ({ learnedDetailRequests = {} }) => {
      learnedDetailRequests[key] = { ...request, learnedAt: new Date().toISOString() };
      chrome.storage.local.set({ learnedDetailRequests })
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: String(error) }));
    });
    return true;
  }
  if (message?.type === "STORE_LEDGER_SNAPSHOT" && Array.isArray(message.rows)) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    chrome.storage.local.get(
      ["ledgerSnapshots", "siteAccounts", "detectedAccounts", "syncToken"],
      async ({ ledgerSnapshots = [], siteAccounts = {}, detectedAccounts = {}, syncToken }) => {
        try {
          const fallback = siteAccounts[hostname] || siteAccounts[domain] ||
            DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || "未設定";
          const detected = detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "";
          const incoming = message.rows
            .filter((row) => row && row.date)
            .map((row, sourceOrder) => {
              const account = String(row.account || detected || fallback);
              const id = [domain || hostname, account, row.date, row.gameName, row.phaseName, row.playType].join("|");
              return { ...row, id, account, host: hostname, root: domain, sourceOrder };
            });

          // 網站仍顯示的跨日資料也必須保留；相同鍵只覆寫最新快照，輪詢不可累加。
          const latest = new Map(
            ledgerSnapshots
              .filter((row) => row?.id)
              .map((row) => [row.id, row])
          );
          incoming.forEach((row) => latest.set(row.id, row));
          const next = [...latest.values()];
          await chrome.storage.local.set({
            ledgerSnapshots: next,
            lastLedgerCapture: {
              ok: true,
              at: new Date().toISOString(),
              site: domain || hostname,
              count: incoming.length
            }
          });
          if (!syncToken) throw new Error("尚未完成同步設定");
          const result = await uploadLedgerRows(incoming.map((row) => ({ ...row, site: row.source })), syncToken);
          await chrome.storage.local.set({ lastLedgerUpload: { ok: true, at: new Date().toISOString(), count: result.accepted } });
          await updateSiteDiagnostic(domain, { event: { stage: 'ledgerUpload', code: 'OK', count: incoming.length } });
          sendResponse({ ok: true, count: incoming.length, uploaded: result.accepted });
        } catch (error) {
          await updateSiteDiagnostic(domain, { event: { stage: 'ledgerUpload', code: SyncDiagnostics.errorCode(error, 'UPLOAD_FAILED') } });
          sendResponse({ ok: false, error: String(error) });
        }
      }
    );
    return true;
  }
  const isHeartbeat = message?.type === "SYNC_HEARTBEAT";
  if (!isHeartbeat && (message?.type !== "SYNC_BETS" || !Array.isArray(message.bets))) return;
  chrome.storage.local.get(
    ["syncToken", "siteAccounts", "detectedAccounts", "installationId"],
    async ({ syncToken, siteAccounts = {}, detectedAccounts = {}, installationId }) => {
    if (!syncToken) {
      sendResponse({ ok: false, error: "尚未完成同步設定" });
      return;
    }
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const detected = domain === "kd998.net"
      ? ""
      : (detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "");
    const fallback = siteAccounts[hostname] || siteAccounts[domain] || DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || message.account || "未設定";
    const bets = isHeartbeat ? [] : message.bets.map((bet) => {
      const account = String(bet.account || detected || fallback);
      const originalId = String(bet.id || "");
      const separator = originalId.indexOf("|");
      const stableTail = separator >= 0 ? originalId.slice(separator + 1) : originalId;
      // 網站會更換 w0 / w1 / w3 等子網域。訂單 ID 使用主網域與實際帳號，
      // 避免同一帳號的同一筆下注因換入口網址而被當成新資料。
      const stableId = `${domain || hostname}|${account}|${stableTail}`;
      return { ...bet, id: stableId, account };
    });
    try {
      const clientId = await getInstallationId(installationId);
      const response = await fetch(`${DASHBOARD}/api/bets`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": `Bearer ${syncToken}`,
          "OAI-Sites-Authorization": `Bearer ${syncToken}`
        },
        body: JSON.stringify({
          bets,
          client: {
            installationId: clientId,
            extensionVersion: chrome.runtime.getManifest().version,
            site: domain || hostname
          }
        })
      });
      const result = await response.json().catch(() => ({}));
      const state = { ok: response.ok, at: new Date().toISOString(), count: bets.length, error: response.ok ? "" : (result.error || `HTTP ${response.status}`) };
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
        await updateSiteDiagnostic(domain, { event: { stage: 'heartbeat', code: state.ok ? 'OK' : SyncDiagnostics.errorCode(state.error, 'UPLOAD_FAILED') } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
        await updateSiteDiagnostic(domain || hostname, {
          uploadOk: state.ok,
          uploadAt: state.at,
          uploadCount: state.count,
          uploadError: state.error
        });
      }
      sendResponse(state);
    } catch (error) {
      const state = { ok: false, at: new Date().toISOString(), count: 0, error: String(error) };
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
        await updateSiteDiagnostic(domain, { event: { stage: 'heartbeat', code: SyncDiagnostics.errorCode(state.error, 'UPLOAD_FAILED') } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
        await updateSiteDiagnostic(domain || hostname, {
          uploadOk: false,
          uploadAt: state.at,
          uploadCount: 0,
          uploadError: state.error
        });
      }
      sendResponse(state);
    }
    }
  );
  return true;
});
