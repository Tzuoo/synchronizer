importScripts("config.js");
importScripts("diagnostics.js");
const DASHBOARD = "https://live-bet-reconciliation.tsoyis0520.chatgpt.site";
const DEFAULT_ACCOUNTS = {
  "w0.188hot.net":"you320",
  "vs968.net":"a0593", "kd998.net":"a0593", "hyp98.com":"a6539",
  "188hot.net":"you320", "bnd139.com":"a0593",
  "umh693.com":"0593", "and539.com":"0593", "amc283.com":"a0593", "pee688.com":"a0593", "sk6688.net":"a0593",
  "nan688.com":"a6539", "la688.com":"a6539", "jgm258.com":"a0593",
  "bnm988.com":"380"
};

const BACKGROUND_ALARM = "synchronizer-background-poll";
const LOCAL_PREVIEW_CACHE = "http://127.0.0.1:8765/__sync/cache";
let localPreviewRefreshPromise = null;
let localPreviewRefreshAt = 0;
function utf8Base64(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 32768) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
  }
  return btoa(binary);
}
async function refreshLocalPreviewCache(force = false) {
  if (localPreviewRefreshPromise) return localPreviewRefreshPromise;
  if (!force && Date.now() - localPreviewRefreshAt < 2000) return;
  localPreviewRefreshAt = Date.now();
  localPreviewRefreshPromise = (async () => {
    const { syncToken, ledgerSnapshots = [] } = await chrome.storage.local.get(['syncToken', 'ledgerSnapshots']);
    const tabs = await chrome.tabs.query({});
    const openRoots = new Set(tabs.flatMap(tab => { try { return [rootDomain(new URL(tab.url).hostname)]; } catch { return []; } }));
    const rows = ledgerSnapshots.filter(row => openRoots.has(row.sourceRoot) && Date.now() - Date.parse(row.capturedAt) <= 120000).map(row => ({ ...row, site: row.source }));
    await fetch('http://127.0.0.1:8765/__sync/ledger-cache', {
      method: 'POST', headers: { 'content-type': 'text/plain', 'x-sync-encoding': 'base64' },
      body: utf8Base64(JSON.stringify({ rows }))
    }).catch(() => {});
    if (!syncToken) return;
    const response = await fetch(`${DASHBOARD}/api/extension-preview`, {
      headers: { authorization: `Bearer ${syncToken}`, 'OAI-Sites-Authorization': `Bearer ${syncToken}` }
    });
    if (!response.ok) return;
    const payload = await response.json().catch(() => ({}));
    if (!Array.isArray(payload.bets)) return;
    await fetch(LOCAL_PREVIEW_CACHE, {
      method: 'POST',
      headers: { 'content-type': 'text/plain', 'x-sync-encoding': 'base64' },
      body: utf8Base64(JSON.stringify({ bets: payload.bets }))
    });
  })().catch(() => {}).finally(() => { localPreviewRefreshPromise = null; });
  return localPreviewRefreshPromise;
}

chrome.alarms.create(BACKGROUND_ALARM, { periodInMinutes: 1 });
chrome.runtime.onStartup.addListener(() => refreshLocalPreviewCache(true).catch(() => {}));

async function wakeBackgroundFrames(tab) {
  if (!Number.isInteger(tab?.id)) return;
  const message = { type: "SYNC_BACKGROUND_TICK" };
  try {
    // 風雲／喜的登入與明細 Gateway 都在 /new_web/ 子框架。背景時該
    // 子框架的 page timer 可能被 Chrome 暫停，不能只喚醒最外層郵局。
    const frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id });
    const frameIds = [...new Set((frames || []).map(frame => frame.frameId).filter(Number.isInteger))];
    if (!frameIds.includes(0)) frameIds.push(0);
    await Promise.allSettled(frameIds.map(frameId => chrome.tabs.sendMessage(tab.id, message, { frameId })));
  } catch {
    // 非網頁分頁或框架瞬間重載時，保留舊有最外層喚醒作為安全退路。
    await chrome.tabs.sendMessage(tab.id, message).catch(() => {});
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== BACKGROUND_ALARM) return;
  refreshLocalPreviewCache(true).catch(() => {});
  flushRemoteDiagnostics().catch(() => {});
  chrome.tabs.query({}).then(async (tabs) => {
    await Promise.allSettled(tabs.map(wakeBackgroundFrames));
    const { siteDiagnostics = {} } = await chrome.storage.local.get(['siteDiagnostics']);
    const roots = new Set(tabs.flatMap(tab => { try { return [rootDomain(new URL(tab.url).hostname)]; } catch { return []; } }));
    for (const site of ['vs968.net', 'kd998.net']) {
      if (roots.has(site) && Date.now() - (Date.parse(siteDiagnostics[site]?.stages?.frame?.eventAt) || 0) > 120000) {
        await updateSiteDiagnostic(site, { event: { stage: 'frame', code: 'WAIT_FRAME' } });
      }
    }
  }).catch(() => {});
});

let diagnosticQueue = Promise.resolve();
function updateSiteDiagnostic(site, patch) {
  const task = diagnosticQueue.then(() => writeSiteDiagnostic(site, patch));
  diagnosticQueue = task.catch(() => {});
  return task;
}
async function writeSiteDiagnostic(site, patch) {
  const key = rootDomain(String(site || "").toLowerCase());
  if (!key) return;
  const { siteDiagnostics = {} } = await chrome.storage.local.get(["siteDiagnostics"]);
  const now = new Date().toISOString();
  const stages = { ...(siteDiagnostics[key]?.stages || {}) };
  const legacy = siteDiagnostics[key];
  if (!stages.upload && legacy?.uploadAt && typeof legacy.uploadOk === 'boolean' && Number.isFinite(Date.parse(legacy.uploadAt))) {
    stages.upload = SyncDiagnostics.record({}, { stage: 'upload', code: legacy.uploadOk ? 'OK' : SyncDiagnostics.errorCode(legacy.uploadError, 'UPLOAD_FAILED'), count: legacy.uploadCount }, legacy.uploadAt);
  }
  const events = [];
  if (patch.frameOk === true) events.push({ stage: 'frame', code: 'OK' });
  if (patch.requestReady === false) events.push({ stage: 'read', code: 'WAIT_REQUEST' });
  if (patch.responseOk === true) events.push({ stage: 'read', code: 'OK' }, { stage: 'parse', code: patch.parsedCount ? 'OK' : 'EMPTY', count: patch.parsedCount });
  if (typeof patch.uploadOk === 'boolean') events.push({ stage: 'upload', code: patch.uploadOk ? 'OK' : SyncDiagnostics.errorCode(patch.uploadError, 'UPLOAD_FAILED'), count: patch.uploadCount });
  if (patch.event) events.push(patch.event);
  for (const event of events) {
    const next = SyncDiagnostics.record(stages[event.stage], event, now);
    if (next.eventAt) stages[event.stage] = next;
  }
  const { event: ignoredEvent, ...localPatch } = patch;
  siteDiagnostics[key] = {
    ...(siteDiagnostics[key] || {}),
    ...localPatch,
    stages,
    site: key,
    extensionVersion: chrome.runtime.getManifest().version,
    updatedAt: now
  };
  await chrome.storage.local.set({ siteDiagnostics });
}

let diagnosticUploadBusy = false;
async function flushRemoteDiagnostics() {
  if (diagnosticUploadBusy) return;
  diagnosticUploadBusy = true;
  try {
    await diagnosticQueue;
    const legacy = await chrome.storage.local.get(['siteDiagnostics']);
    for (const [site, value] of Object.entries(legacy.siteDiagnostics || {})) {
      if (!value.stages && value.uploadAt) await updateSiteDiagnostic(site, {});
    }
    const { syncToken, installationId, diagnosticDeviceLabel, siteDiagnostics } = await chrome.storage.local.get(['syncToken', 'installationId', 'diagnosticDeviceLabel', 'siteDiagnostics']);
    if (!syncToken) return;
    const rows = SyncDiagnostics.rows(siteDiagnostics);
    if (!rows.length) return;
    const response = await fetch(`${DASHBOARD}/api/diagnostics`, {
      method: 'POST', signal: AbortSignal.timeout(15000),
      headers: { 'content-type': 'application/json', authorization: `Bearer ${syncToken}`, 'OAI-Sites-Authorization': `Bearer ${syncToken}` },
      body: JSON.stringify({ installationId: await getInstallationId(installationId), deviceLabel: ['公司', '家裡'].includes(diagnosticDeviceLabel) ? diagnosticDeviceLabel : '', extensionVersion: chrome.runtime.getManifest().version, rows })
    });
    await chrome.storage.local.set({ diagnosticRemoteUpload: { ok: response.ok, at: new Date().toISOString() } });
  } catch {
    // Retain local errors and retry next alarm; never generate a notification.
    await chrome.storage.local.set({ diagnosticRemoteUpload: { ok: false, at: new Date().toISOString() } });
  } finally { diagnosticUploadBusy = false; }
}

function rootDomain(hostname) {
  const parts = hostname.split(".");
  return parts.slice(-2).join(".");
}

// A07 有些站會把同一期寫成「【C115220】」，另一些回應則是
// 「C115220」。這只是外框格式，不是另一個期別；必須在建立快照鍵前
// 統一，否則輪詢會把同一期玩法加兩次。
function canonicalLedgerPhaseName(value) {
  let text = String(value || "").replace(/\u00a0/g, " ").replace(/[>＞]\s*$/, "").trim();
  let previous = "";
  while (text && text !== previous) {
    previous = text;
    const paired = text.match(/^[【\[（(]\s*(.*?)\s*[】\]）)]$/);
    if (paired) text = paired[1].trim();
  }
  const match = text.match(/^第\s*(.+?)\s*期$/);
  return match ? match[1].trim() : text;
}

function clientSiteKey(installationId, domain) {
  return `${String(installationId || "").trim()}|${String(domain || "").trim()}`;
}

function stableBetTail(bet, fallbackTail, occurrence) {
  // Gateway 主單／細項 ID 已是來源穩定鍵；補上顯示項次不能改變訂單 ID。
  if (/^(?:gateway\||kd-gateway-batch\|)/.test(fallbackTail)) return fallbackTail;
  const itemNumber = String(bet?.itemNumber || "").trim();
  const placedAt = String(bet?.placedAt || "").trim();
  const event = String(bet?.event || "").trim();
  const selection = String(bet?.selection || "").replace(/\s+/g, " ").trim();
  // 有網站把金額放在舊 ID 最後一段；金額被畫面暫時解析錯誤時會變成
  // 新訂單。來源實際項次、時間、玩法與內容齊全時改用它們作為穩定鍵。
  // 同一項內真正完全相同的兩列仍保留 occurrence，不能任意合併。
  if (itemNumber && placedAt && event && selection) {
    return `source-item|${itemNumber}|${placedAt}|${event}|${selection}|${occurrence}`;
  }
  return fallbackTail;
}

let installationIdPromise;

// Serialize only storage transactions; network requests must not hold this queue.
let snapshotStorageQueue = Promise.resolve();
function queueSnapshotStorage(task) {
  const result = snapshotStorageQueue.then(task);
  snapshotStorageQueue = result.catch(() => {});
  return result;
}

function saveLearnedRequest(key, request) {
  return queueSnapshotStorage(async () => {
    const { learnedDetailRequests = {} } = await chrome.storage.local.get(["learnedDetailRequests"]);
    learnedDetailRequests[key] = { ...request, learnedAt: new Date().toISOString() };
    await chrome.storage.local.set({ learnedDetailRequests });
  });
}

function saveLedgerSnapshot(incoming, site) {
  return queueSnapshotStorage(async () => {
    const { ledgerSnapshots = [] } = await chrome.storage.local.get(["ledgerSnapshots"]);
    const latest = new Map(ledgerSnapshots.filter(row => row?.id).map(row => [row.id, row]));
    incoming.forEach(row => latest.set(row.id, row));
    await chrome.storage.local.set({
      ledgerSnapshots: [...latest.values()],
      lastLedgerCapture: { ok: true, at: new Date().toISOString(), site, count: incoming.length }
    });
  });
}

async function uploadBetBatches(bets, client, syncToken) {
  let accepted = 0;
  // Empty arrays still send the existing heartbeat request.
  for (let offset = 0; offset < Math.max(1, bets.length); offset += 500) {
    try {
      const batch = bets.slice(offset, offset + 500);
      const response = await fetch(`${DASHBOARD}/api/bets`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": `Bearer ${syncToken}`,
          "OAI-Sites-Authorization": `Bearer ${syncToken}`
        },
        body: JSON.stringify({ bets: batch, client })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) return { ok: false, count: accepted, error: result.error || `HTTP ${response.status}` };
      accepted += batch.length;
    } catch (error) {
      return { ok: false, count: accepted, error: String(error) };
    }
  }
  return { ok: true, count: accepted, error: "" };
}

async function getInstallationId(existingId) {
  const current = String(existingId || "").trim();
  if (current) return current;
  if (!installationIdPromise) {
    installationIdPromise = chrome.storage.local.get(["installationId"]).then(async ({ installationId }) => {
      const stored = String(installationId || "").trim();
      if (stored) return stored;
      const created = crypto.randomUUID();
      await chrome.storage.local.set({ installationId: created });
      return created;
    });
  }
  return installationIdPromise;
}

async function uploadLedgerRows(rows, syncToken) {
  const response = await fetch(`${DASHBOARD}/api/ledger`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${syncToken}`,
      "OAI-Sites-Authorization": `Bearer ${syncToken}`
    },
    body: JSON.stringify({ rows })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
  return result;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["syncToken", "detectedAccounts", "installationId"], async ({ syncToken, detectedAccounts = {}, installationId }) => {
    if (!syncToken && DEFAULT_SYNC_TOKEN) {
      syncToken = DEFAULT_SYNC_TOKEN;
      await chrome.storage.local.set({ syncToken });
    }
    await getInstallationId(installationId);
    // 1.6.31 曾把下單群組 Fxxxxxx 誤當成喜網站登入帳號；升級時移除錯誤快取。
    Object.keys(detectedAccounts).forEach((key) => {
      if (key === "kd998.net" || key.endsWith(".kd998.net")) delete detectedAccounts[key];
    });
    await chrome.storage.local.set({ detectedAccounts });
    refreshLocalPreviewCache(true).catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "SITE_DIAGNOSTIC" && message.state) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    updateSiteDiagnostic(hostname, message.state)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  }
  if (message?.type === "REGISTER_ACTUAL_ACCOUNT" && message.account) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const account = String(message.account).trim();
    if (!hostname || !account) {
      sendResponse({ ok: false });
      return;
    }
    chrome.storage.local.get(["detectedAccounts"], ({ detectedAccounts = {} }) => {
      const detected = { account, at: new Date().toISOString() };
      detectedAccounts[hostname] = detected;
      detectedAccounts[domain] = detected;
      chrome.storage.local.set({ detectedAccounts })
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: String(error) }));
    });
    return true;
  }
  if (message?.type === "POLL_STATUS") {
    chrome.storage.local.set({ lastPoll: { ...message.state, at: new Date().toISOString() } })
      .then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "LEARN_DETAIL_REQUEST" && message.request) {
    const request = message.request;
    const key = request.root || rootDomain(request.host || "");
    saveLearnedRequest(key, request)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: String(error) }));
    return true;
  }
  if (message?.type === "STORE_LEDGER_SNAPSHOT" && Array.isArray(message.rows)) {
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    chrome.storage.local.get(
      ["siteAccounts", "detectedAccounts", "syncToken", "installationId"],
      async ({ siteAccounts = {}, detectedAccounts = {}, syncToken, installationId }) => {
        try {
          const fallback = siteAccounts[hostname] || siteAccounts[domain] ||
            DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || "未設定";
          const detected = detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "";
          const clientId = await getInstallationId(installationId);
          const clientSite = clientSiteKey(clientId, domain || hostname);
          const incoming = message.rows
            .filter((row) => row && row.date)
            .map((row, sourceOrder) => {
              const account = String(row.account || detected || fallback);
              const phaseName = canonicalLedgerPhaseName(row.phaseName);
              const id = [clientSite, account, row.date, row.gameName, phaseName, row.playType].join("|");
              return { ...row, id, account, phaseName, host: hostname, root: clientSite, sourceRoot: domain, sourceOrder };
            });

          // 網站仍顯示的跨日資料也必須保留；相同鍵只覆寫最新快照，輪詢不可累加。
          await saveLedgerSnapshot(incoming, domain || hostname);
          if (!syncToken) throw new Error("尚未完成同步設定");
          const result = await uploadLedgerRows(incoming.map((row) => ({ ...row, site: row.source })), syncToken);
          await chrome.storage.local.set({ lastLedgerUpload: { ok: true, at: new Date().toISOString(), count: result.accepted } });
          refreshLocalPreviewCache(true).catch(() => {});
          await updateSiteDiagnostic(domain, { event: { stage: 'ledgerUpload', code: 'OK', count: incoming.length } });
          sendResponse({ ok: true, count: incoming.length, uploaded: result.accepted });
        } catch (error) {
          await updateSiteDiagnostic(domain, { event: { stage: 'ledgerUpload', code: SyncDiagnostics.errorCode(error, 'UPLOAD_FAILED') } });
          sendResponse({ ok: false, error: String(error) });
        }
      }
    );
    return true;
  }
  const isHeartbeat = message?.type === "SYNC_HEARTBEAT";
  if (!isHeartbeat && (message?.type !== "SYNC_BETS" || !Array.isArray(message.bets))) return;
  chrome.storage.local.get(
    ["syncToken", "siteAccounts", "detectedAccounts", "installationId"],
    async ({ syncToken, siteAccounts = {}, detectedAccounts = {}, installationId }) => {
    if (!syncToken) {
      sendResponse({ ok: false, error: "尚未完成同步設定" });
      return;
    }
    const hostname = sender?.url ? new URL(sender.url).hostname : "";
    const domain = rootDomain(hostname);
    const detected = domain === "kd998.net"
      ? ""
      : (detectedAccounts[hostname]?.account || detectedAccounts[domain]?.account || "");
    const fallback = siteAccounts[hostname] || siteAccounts[domain] || DEFAULT_ACCOUNTS[hostname] || DEFAULT_ACCOUNTS[domain] || message.account || "未設定";
    const clientId = await getInstallationId(installationId);
    const clientSite = clientSiteKey(clientId, domain || hostname);
    const sourceOccurrences = new Map();
    const bets = isHeartbeat ? [] : message.bets.map((bet) => {
      const account = String(bet.account || detected || fallback);
      const originalId = String(bet.id || "");
      const separator = originalId.indexOf("|");
      const stableTail = separator >= 0 ? originalId.slice(separator + 1) : originalId;
      const itemKey = [String(bet.itemNumber || ""), String(bet.placedAt || ""), String(bet.event || ""), String(bet.selection || "")].join("\u0000");
      const occurrence = sourceOccurrences.get(itemKey) || 0;
      sourceOccurrences.set(itemKey, occurrence + 1);
      // 網站會更換 w0 / w1 / w3 等子網域。訂單 ID 使用主網域與實際帳號，
      // 避免同一帳號的同一筆下注因換入口網址而被當成新資料。
      const stableId = `${clientSite}|${account}|${stableBetTail(bet, stableTail, occurrence)}`;
      return { ...bet, id: stableId, account };
    });
    try {
      const result = await uploadBetBatches(bets, {
        installationId: clientId,
        extensionVersion: chrome.runtime.getManifest().version,
        site: clientSite
      }, syncToken);
      const state = { ...result, at: new Date().toISOString() };
      if (state.ok) refreshLocalPreviewCache().catch(() => {});
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
        await updateSiteDiagnostic(domain, { event: { stage: 'heartbeat', code: state.ok ? 'OK' : SyncDiagnostics.errorCode(state.error, 'UPLOAD_FAILED') } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
        await updateSiteDiagnostic(domain || hostname, {
          uploadOk: state.ok,
          uploadAt: state.at,
          uploadCount: state.count,
          uploadError: state.error
        });
      }
      sendResponse(state);
    } catch (error) {
      const state = { ok: false, at: new Date().toISOString(), count: 0, error: String(error) };
      if (isHeartbeat) {
        await chrome.storage.local.set({ lastHeartbeat: { ...state, site: domain || hostname } });
        await updateSiteDiagnostic(domain, { event: { stage: 'heartbeat', code: SyncDiagnostics.errorCode(state.error, 'UPLOAD_FAILED') } });
      } else {
        await chrome.storage.local.set({ lastSync: state });
        await updateSiteDiagnostic(domain || hostname, {
          uploadOk: false,
          uploadAt: state.at,
          uploadCount: 0,
          uploadError: state.error
        });
      }
      sendResponse(state);
    }
    }
  );
  return true;
});
