function scrapeVs968Json(responseText) {
  const root = rootDomain(location.hostname);
  if (!["vs968.net", "kd998.net"].includes(root)) return [];

  let payload;
  try {
    payload = JSON.parse(responseText || "");
  } catch {
    return [];
  }

  if (!Array.isArray(payload?.rows)) return [];

  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[root] || root;
  const playNames = {
    1: "全車", 2: "特別號", 3: "正特碼雙面", 4: "台號",
    5: "特尾三", 6: "二星", 7: "三星", 8: "四星",
    9: "天碰二", 10: "天碰三", 11: "反轉樂", 12: "五星"
  };
  const bets = [];
  // 風雲 main06 與喜實際 539 明細均按 group.id 分組倒序編號。
  // 只有完整清單才可還原項次，不用目前頁面筆數冒充整組筆數。
  const windItemNumbers = new Map();
  if (Number(payload.total) === payload.rows.length) {
    const groups = new Map();
    [...payload.rows].sort((a,b)=>Number(b.id)-Number(a.id)).forEach(row=>{
      const key=String(row?.group?.id ?? '');
      if (!key || !row?.id) return;
      const rows=groups.get(key)||[]; rows.push(row); groups.set(key,rows);
    });
    groups.forEach(rows=>rows.forEach((row,index)=>windItemNumbers.set(String(row.id),String(rows.length-index))));
  }
  const kdPlayNames = {
    1: "正碼", 2: "特碼", 3: "正特碼雙面", 4: "台號", 5: "特尾三",
    6: "二星", 7: "三星", 8: "四星", 9: "天碰二", 10: "天碰三",
    11: "反轉樂", 12: "五星", 13: "衝鋒三"
  };

  payload.rows.forEach((row, rowIndex) => {
    const placedAt = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(String(row?.created_at || ""))
      ? `${String(row.created_at).replace(" ", "T")}+08:00`
      : new Date().toISOString();
    const details = Array.isArray(row?.details) ? row.details : [];
    const seq = String(row?.game?.seq || "").trim();
    const groupNo = String(row?.group?.no || "").padStart(3, "0");

    if (root === "kd998.net") {
      const parsedDetails = details.map((detail) => {
        const playCode = Number(detail?.play);
        const play = kdPlayNames[playCode] || `未辨識玩法 ${playCode || ""}`.trim();
        const amount = Number(detail?.money);
        const carUnit = Number(kdCarUnits[play]);
        const cars = amount > 0 && carUnit > 0 ? amount / carUnit : null;
        const water = Number(detail?.water);
        const payout = amount > 0 && Number.isFinite(water) ? amount * (100 - water) / 100 : null;
        return { play, content: String(detail?.content ?? "").trim(), amount, cars, payout, odds: Number(detail?.odds) };
      }).filter((detail) => detail.play && detail.content && detail.amount > 0);
      if (!parsedDetails.length) return;

      const plays = [...new Set(parsedDetails.map((detail) => detail.play))];
      const amounts = parsedDetails.map((detail) => detail.amount);
      const cars = parsedDetails.map((detail) => detail.cars);
      const selection = parsedDetails.map((detail) => [
        detail.play,
        detail.content,
        `下注金額 ${detail.amount}`,
        detail.cars == null ? "車數 未辨識" : `車數 ${Number(detail.cars.toFixed(4))} 車`
      ].join("｜")).join("\n");
      const playType = plays.join("／");
      bets.push(enrichedBet({
        id: `${hostname}|kd-gateway-batch|${row?.id ?? rowIndex}`,
        source,
        account: "",
        placedAt,
        event: playType,
        selection,
        odds: parsedDetails.every((detail) => detail.odds === parsedDetails[0].odds) ? parsedDetails[0].odds : null,
        stake: amounts.every((amount) => amount === amounts[0]) ? amounts[0] : 0,
        potentialPayout: parsedDetails.every((detail) => detail.payout != null)
          ? parsedDetails.reduce((sum, detail) => sum + detail.payout, 0)
          : null,
        status: row?.is_cancel ? "已撤單" : "待結算",
        result: null,
        reconciled: false
      }, {
        playType,
        itemNumber: windItemNumbers.get(String(row?.id)) || null,
        unitAmount: amounts.every((amount) => amount === amounts[0]) ? amounts[0] : null,
        carCount: cars.every((value) => value != null) ? cars.reduce((sum, value) => sum + value, 0) : null,
        betAmount: amounts.reduce((sum, amount) => sum + amount, 0),
        rawText: JSON.stringify(row).slice(0, 20000),
        parseStatus: cars.every((value) => value != null) ? "parsed" : "partial"
      }));
      return;
    }

    details.forEach((detail, detailIndex) => {
      const playCode = Number(detail?.play);
      const playName = playNames[playCode] || `未辨識玩法 ${playCode || ""}`.trim();
      const isSix = String(row?.casino ?? row?.game?.casino ?? "") === "1";
      // 六合沿用既有批次格式，網頁會依同一時間與群組合併成「台號」直式清單。
      // 其他盤別只採用 gateway 明確提供的玩法代碼名稱，不自行猜測單碰／連碰。
      const event = isSix && seq && playCode === 4
        ? `六合 / ${seq}${groupNo ? ` - ${groupNo}` : ""}`
        : playName;
      const money = Number(detail?.money);
      const rowAmount = Number(row?.amount);
      const amount = Number.isFinite(money) && money > 0
        ? money
        : (Number.isFinite(rowAmount) && rowAmount > 0 ? rowAmount : 0);
      if (!(amount > 0)) return;

      // 來源 app.js row-view-type01：非全車固定以 money / 100 顯示支數。
      // 限已核對的六合台號與 bet_type=1，不外推到星碰或其他玩法。
      const taihaoCount = isSix && playCode === 4 && Number(row?.bet_type) === 1
        ? Number((amount / 100).toFixed(2)) : null;
      const rawSelection = String(detail?.content ?? '').trim();
      const selection = isSix && playCode === 4 && /^\d{1,2}$/.test(rawSelection)
        ? rawSelection.padStart(2, '0') : rawSelection;

      bets.push(enrichedBet({
        id: `${hostname}|gateway|${row?.id ?? rowIndex}|${detail?.id ?? detailIndex}`,
        source,
        account: "",
        placedAt,
        event,
        selection,
        odds: Number.isFinite(Number(detail?.odds)) ? Number(detail.odds) : null,
        stake: amount,
        potentialPayout: amount,
        status: row?.is_cancel ? "已撤單" : "待結算",
        result: null,
        reconciled: false
      }, {
        playType: isSix ? "台號" : playName,
        itemNumber: windItemNumbers.get(String(row?.id)) || null,
        unitAmount: amount,
        combinationCount: null,
        carCount: taihaoCount,
        betAmount: amount,
        principal: null,
        rawText: JSON.stringify({ rowId: row?.id, betType: row?.bet_type, detail }),
        parseStatus: playNames[playCode] ? "parsed" : "partial"
      }));
    });
  });

  return bets;
}

function scrapeDetailResponse(responseText) {
  const documents = [
    new DOMParser().parseFromString(
      responseText || "",
      "text/html"
    )
  ];

  try {
    const strings = [];

    const collect = (
      value,
      depth = 0
    ) => {
      if (
        depth > 8 ||
        strings.length > 80
      ) {
        return;
      }

      if (
        typeof value === "string"
      ) {
        if (
          value.includes("分組序號報表") ||
          value.includes("下注明細") ||
          value.includes("<tr")
        ) {
          strings.push(value);
        }

        return;
      }

      if (Array.isArray(value)) {
        value.forEach(
          (item) =>
            collect(
              item,
              depth + 1
            )
        );
      } else if (
        value &&
        typeof value === "object"
      ) {
        Object.values(
          value
        ).forEach(
          (item) =>
            collect(
              item,
              depth + 1
            )
        );
      }
    };

    collect(
      JSON.parse(
        responseText
      )
    );

    strings.forEach(
      (html) =>
        documents.push(
          new DOMParser().parseFromString(
            html,
            "text/html"
          )
        )
    );
  } catch {}

  const result = scrapeVs968Json(responseText);
  const seen = new Set(result.map((bet) => bet.id));

  documents.forEach(
    (doc) => {
      const parsed = rootDomain(location.hostname) === "vs968.net"
        ? [...scrape(doc), ...scrapeGroupedReportFrom(doc)]
        : scrapeGroupedReportFrom(doc);

      parsed.forEach(
        (bet) => {
          if (
            !seen.has(
              bet.id
            )
          ) {
            seen.add(
              bet.id
            );

            result.push(
              bet
            );
          }
        }
      );
    }
  );

  return result;
}
