const SITE_NAMES = {
  "vs968.net": "風雲", "hyp98.com": "98", "kd998.net": "喜", "cj3688.com": "喜代",
  "188hot.net": "16", "bnd139.com": "28",
  "umh693.com": "海勝", "amc283.com": "航海", "pee688.com": "航海", "sk6688.net": "sk6688",
  "nan688.com": "nan688", "la688.com": "la688", "jgm258.com": "jgm258",
  "bnm988.com": "bnm988"
};

// 供實際網頁診斷目前載入的擴充版本，不會顯示在使用者畫面。
document.documentElement.dataset.syncExtensionVersion =
  chrome.runtime.getManifest().version;

const HOST_NAMES = {
  "www.vs968.net": "風雲",
  "www.hyp98.com": "98",
  "w1.hyp98.com": "98",
  "w0.188hot.net": "16"
};

function rootDomain(hostname) {
  const parts = hostname.split(".");
  return parts.slice(-2).join(".");
}

function accountFromDocument(root) {
  const value = (root?.body?.innerText || root?.body?.textContent || "")
    .replace(/\u00a0/g, " ");
  const match = value.match(
    /(?:會員\s*)?(?:帳號|账号)\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9._-]{1,31})/i
  );
  return match?.[1] || "";
}

function detectActualAccount() {
  let current = window;
  for (let depth = 0; depth < 12; depth += 1) {
    try {
      const account = accountFromDocument(current.document);
      if (account) return account;
      if (current.parent === current) break;
      current = current.parent;
    } catch {
      break;
    }
  }
  return "";
}

let lastReportedAccount = "";

function reportActualAccount() {
  const account = detectActualAccount();
  if (!account || account === lastReportedAccount) return account;
  lastReportedAccount = account;
  safeMessage({ type: "REGISTER_ACTUAL_ACCOUNT", account });
  return account;
}

function text(node, selector) {
  return (node.querySelector(selector)?.textContent || "").trim();
}

function numeric(value) {
  const parsed = Number(String(value).replace(/[^0-9.-]/g, ""));
  return Number.isFinite(parsed) ? parsed : null;
}

function starCountFor(play) {
  return ({ "二": 2, "三": 3, "四": 4, "五": 5 })[String(play || "")[0]] || null;
}

function parsePillarsFromText(value) {
  const raw = String(value || "")
    .replace(/\u00a0/g, " ")
    .replace(/，/g, ",");
  const markers = [...raw.matchAll(/第\s*(\d{1,2})\s*柱/g)];
  const pillars = [];

  for (let i = 0; i < markers.length; i++) {
    const marker = markers[i];
    const start = (marker.index || 0) + marker[0].length;
    const end = i + 1 < markers.length ? markers[i + 1].index : raw.length;
    const segment = raw.slice(start, end);
    const numbers = (segment.match(/\b\d{1,2}\b/g) || [])
      .map((n) => Number(n))
      .filter((n) => n >= 1 && n <= 49);

    if (numbers.length) {
      pillars.push({
        index: Number(marker[1]),
        numbers
      });
    }
  }

  return pillars;
}

function formatPillarSelection(value) {
  const pillars = parsePillarsFromText(value);
  if (!pillars.length) return "";

  // 同步器畫面欄寬有限；柱碰改成逐柱換行，
  // 長柱每 10 個號碼再換一行，避免文字溢出到右側欄位。
  return pillars
    .map((pillar) => {
      const prefix = `第${String(pillar.index).padStart(2, "0")}柱 `;
      const nums = pillar.numbers.map((n) => String(n).padStart(2, "0"));
      const chunks = [];
      for (let i = 0; i < nums.length; i += 10) {
        chunks.push(nums.slice(i, i + 10).join(", "));
      }
      return prefix + chunks.join("\n      ");
    })
    .join("\n");
}

function pillarCombinationCountFor(play, selection) {
  const star = starCountFor(play);
  if (!star || !/柱碰/.test(String(play || ""))) return null;

  const sizes = parsePillarsFromText(selection).map((pillar) => pillar.numbers.length);
  if (sizes.length < star) return null;

  // 柱碰：從不同柱選 star 柱，各柱各取 1 號。
  // 例如二星柱碰 2/2/4 = 2*2 + 2*4 + 2*4 = 20 碰；
  // 三星柱碰 2/2/4 = 2*2*4 = 16 碰。
  const dp = Array(star + 1).fill(0);
  dp[0] = 1;
  for (const size of sizes) {
    for (let k = star; k >= 1; k--) {
      dp[k] += dp[k - 1] * size;
    }
  }
  return dp[star] || null;
}

function combinationCountFor(play, selection) {
  if (/柱碰/.test(String(play || ""))) {
    return pillarCombinationCountFor(play, selection);
  }

  const nums = (String(selection || "").match(/\b\d{1,2}\b/g) || []).length;
  const star = starCountFor(play);
  if (!star || !/連碰/.test(String(play || "")) || nums < star) return null;

  let result = 1;
  for (let i = 1; i <= star; i++) {
    result = result * (nums - star + i) / i;
  }

  return Math.round(result);
}


function orderStatusFromText(...values) {
  const value = values
    .filter((item) => item != null)
    .map((item) => String(item))
    .join(" ")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (/已\s*刪\s*單|刪\s*單|已\s*刪\s*除|已\s*删\s*除|deleted/i.test(value)) {
    return "已刪單";
  }

  if (/已\s*取\s*消|已\s*撤\s*單|cancelled|canceled/i.test(value)) {
    return "已取消";
  }

  return "待結算";
}

function enrichedBet(base, extra = {}) {
  return {
    ...base,
    playType: extra.playType ?? base.event ?? null,
    unitAmount: extra.unitAmount ?? null,
    combinationCount: extra.combinationCount ?? null,
    carCount: extra.carCount ?? null,
    betAmount: extra.betAmount ?? base.potentialPayout ?? base.stake ?? null,
    principal: extra.principal ?? null,
    rawText: extra.rawText ?? "",
    parseStatus: extra.parseStatus ?? "parsed",
  };
}

function gameSectionFromText(value, fallback = "") {
  const matches = [...String(value || "").matchAll(/【\s*([^】]+?)\s*】\s*第\s*[^\s】]+\s*期/g)];
  return matches.length ? matches.at(-1)[1].trim() : fallback;
}

function eventWithGameSection(gameSection, playType) {
  const game = String(gameSection || "").trim();
  const play = String(playType || "").trim();
  return game && play ? `${game} / ${play}` : play;
}

function safeMessage(message) {
  try {
    if (!chrome?.runtime?.id) return Promise.resolve();
    return chrome.runtime.sendMessage(message).catch(() => {});
  } catch {
    return Promise.resolve();
  }
}

function scrape(root = document) {
  const details = root.querySelector("#bet_details");
  if (!details) return [];

  const domain = rootDomain(location.hostname);
  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[domain] || domain;
  const bets = [];

  root.querySelectorAll("#bet_details .bet_group").forEach((group) => {
    const groupName = text(group, ".panel_title span") || "未分類";

    group.querySelectorAll(".bet_item").forEach((item) => {
      const number = text(item, ".bet_item_no").replace(/\s+/g, " ");
      const dateLine = text(item, ".bet_cnt > p.btm--gold");
      const date = (dateLine.match(/\d{4}-\d{2}-\d{2}/) || [""])[0];
      const time = text(item, ".bet_time");

      const placedAt =
        date && time
          ? `${date}T${time}+08:00`
          : new Date().toISOString();

      item
        .querySelectorAll(
          ".table .tr:not(.bg--title--black):not(.sumup_row)"
        )
        .forEach((row, rowIndex) => {
          const play = text(row, ".col-play");
          const content = text(row, ".col-content");

          if (!play && !content) return;

          const odds = numeric(text(row, ".col-odds"));
          const stake = numeric(text(row, ".col-money")) || 0;
          const total = numeric(text(row, ".col-total"));

          const rawId =
            `${hostname}|${groupName}|${number}|${date}|${time}|${rowIndex}|${play}|${content}`;

          bets.push(
            enrichedBet(
              {
                id: rawId,
                source,
                account: "",
                placedAt,
                event: groupName,
                selection: `${play} ${content}`.trim(),
                odds,
                stake,
                potentialPayout:
                  source === "風雲"
                    ? stake
                    : total,
                status: orderStatusFromText(closestText(item), closestText(row)),
                result: null,
                reconciled: false
              },
              {
                playType: play || groupName,
                unitAmount: stake || null,
                betAmount:
                  source === "風雲"
                    ? stake
                    : (total ?? stake),
                rawText: closestText(row),
                parseStatus: "parsed"
              }
            )
          );
        });
    });
  });

  return bets;
}

function scrapeKdOrders(root = document) {
  if (rootDomain(location.hostname) !== "kd998.net") return [];

  const details = root.querySelector("#bet_details");
  if (!details) return [];

  const hostname = location.hostname.toLowerCase();
  const source = SITE_NAMES["kd998.net"];
  const bets = [];

  details.querySelectorAll(".bet_group").forEach((group) => {
    const groupName = text(group, ".panel_title span") || "下注明細";
    const groupId = group.id || groupName;

    group.querySelectorAll(".bet_item").forEach((item, itemIndex) => {
      const number = text(item, ".bet_item_no").replace(/\s+/g, " ");
      const dateLine = text(item, ".bet_cnt > p.btm--gold");
      const date = (dateLine.match(/\d{4}-\d{2}-\d{2}/) || [""])[0];
      const time = text(item, ".bet_time");
      if (!date || !time) return;

      const rows = [...item.querySelectorAll(".table .tr:not(.bg--title--black):not(.sumup_row)")]
        .map((row) => ({
          play: text(row, ".col-play"),
          content: text(row, ".col-content"),
          odds: numeric(text(row, ".col-odds")),
          principal: numeric(text(row, ".col-capital")),
          amount: numeric(text(row, ".col-money")),
          carsText: text(row, ".col-unit"),
          payout: numeric(text(row, ".col-total")),
          rawText: closestText(row)
        }))
        .filter((row) => row.play || row.content);
      if (!rows.length) return;

      const summary = item.querySelector(".table .sumup_row");
      const betAmount = numeric(text(summary, ".col-money"));
      const payout = numeric(text(summary, ".col-total"));
      const carCount = numeric(text(summary, ".col-unit"));
      const amounts = rows.map((row) => row.amount).filter((value) => value != null);
      const learnedCarUnits = {};
      rows.forEach((row) => {
        const cars = numeric(row.carsText);
        if (row.play && row.amount > 0 && cars > 0) learnedCarUnits[row.play] = row.amount / cars;
      });
      if (Object.keys(learnedCarUnits).length) {
        chrome.storage.local.get(["kdCarUnits"], ({ kdCarUnits = {} }) => {
          chrome.storage.local.set({ kdCarUnits: { ...kdCarUnits, ...learnedCarUnits } });
        });
      }
      const unitAmount = amounts.length === rows.length && amounts.every((value) => value === amounts[0])
        ? amounts[0]
        : null;
      const plays = [...new Set(rows.map((row) => row.play).filter(Boolean))];
      const playType = plays.join("／") || groupName;
      const selection = rows.map((row) => [
        row.play,
        row.content,
        row.amount == null ? "" : `下注金額 ${row.amount}`,
        row.carsText ? `車數 ${row.carsText}` : ""
      ].filter(Boolean).join("｜")).join("\n");
      const placedAt = `${date}T${time}+08:00`;

      bets.push(enrichedBet({
        id: `${hostname}|kd-batch|${groupId}|${number || itemIndex}|${date}|${time}`,
        source,
        account: "",
        placedAt,
        event: playType,
        selection,
        odds: rows.every((row) => row.odds === rows[0].odds) ? rows[0].odds : null,
        stake: unitAmount || 0,
        potentialPayout: payout,
        status: orderStatusFromText(closestText(item)),
        result: null,
        reconciled: false
      }, {
        playType,
        unitAmount,
        carCount,
        betAmount: betAmount ?? amounts.reduce((sum, value) => sum + value, 0),
        principal: rows.reduce((sum, row) => sum + (row.principal || 0), 0) || null,
        rawText: [groupName, closestText(item)].join(" "),
        parseStatus: "parsed"
      }));
    });
  });

  return bets;
}

function closestText(node) {
  return (node?.textContent || "")
    .trim()
    .replace(/\s+/g, " ");
}

function scrapeGroupedReportFrom(root) {
  if (["amc283.com", "pee688.com"].includes(rootDomain(location.hostname))) return [];

  const pageText =
    root.body?.innerText ||
    root.body?.textContent ||
    "";

  if (!pageText.includes("分組序號報表")) return [];

  const domain = rootDomain(location.hostname);
  const hostname = location.hostname.toLowerCase();
  const source =
    HOST_NAMES[hostname] ||
    SITE_NAMES[domain] ||
    domain;

  const bets = [];
  const rows = [...root.querySelectorAll("tr")];

  let currentTicket = "";
  let currentTime = "";
  let currentEvent = "分組序號報表";

  rows.forEach((row, rowIndex) => {
    const cells = [
      ...row.querySelectorAll("td,th")
    ]
      .map(closestText)
      .filter(Boolean);

    const line = cells.join(" ");

    if (!line) return;

    const ticket =
      line.match(/[A-Z]\d{5,}\s*-\s*\d{3}/i) ||
      line.match(/\b\d{6,}\b/);

    if (ticket) {
      currentTicket = ticket[0].replace(/\s+/g, "");
    }

    const dateTime =
      line.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    if (dateTime) {
      currentTime =
        dateTime[0].replace(/\//g, "-");
    }

    const event =
      line.match(
        /(大樂|六合|539|天天樂|固定賠)/
      );

    if (event) {
      currentEvent = event[1];
    }

    const numericCells =
      cells.map(numeric);

    const hasMoney =
      numericCells.some(
        (n) => n && n > 0
      );

    const hasPlay =
      cells.some(
        (c) =>
          /正碼|特碼|台號|二星|三星|四星|全車|固定賠/.test(c)
      );

    const hasNumber =
      cells.some(
        (c) =>
          /^\d{1,2}$/.test(c) ||
          /^\d{3,4}$/.test(c)
      );

    if (
      !hasMoney ||
      (!hasPlay && !hasNumber)
    ) {
      return;
    }

    if (
      line.includes("總計") ||
      line.includes("小計") ||
      line.includes("列印")
    ) {
      return;
    }

    const play =
      cells.find(
        (c) =>
          /正碼|特碼|台號|二星|三星|四星|全車|固定賠/.test(c)
      ) ||
      currentEvent;

    const content =
      cells.find(
        (c) =>
          /^\d{1,2}$/.test(c) ||
          /^\d{3,4}$/.test(c) ||
          /\d{1,2}[,，]\d{1,2}/.test(c)
      ) ||
      "";

    const odds =
      numericCells.find(
        (n) =>
          n &&
          n > 1 &&
          n < 10000
      ) ||
      null;

    const stakeCandidates =
      numericCells.filter(
        (n) =>
          n &&
          n >= 1
      );

    const stake =
      stakeCandidates.length
        ? stakeCandidates[
            stakeCandidates.length - 1
          ]
        : 0;

    const placedAt =
      currentTime
        ? `${currentTime.replace(" ", "T")}+08:00`
        : new Date().toISOString();

    bets.push(
      enrichedBet(
        {
          id:
            `${hostname}|grouped|${currentTicket}|${currentTime}|${rowIndex}|${play}|${content}|${stake}`,
          source,
          account: "",
          placedAt,
          event:
            currentTicket
              ? `${currentEvent} / ${currentTicket}`
              : currentEvent,
          selection:
            `${play} ${content}`.trim(),
          odds,
          stake,
          potentialPayout: null,
          status: orderStatusFromText(line),
          result: null,
          reconciled: false
        },
        {
          playType: play,
          unitAmount:
            stake || null,
          betAmount:
            stake || null,
          rawText: line,
          parseStatus: "partial"
        }
      )
    );
  });

  return bets;
}

function scrapeGroupedReport() {
  return scrapeGroupedReportFrom(document);
}

function scrapeUmhOrders(root = document) {
  if (
    rootDomain(location.hostname) !==
    "umh693.com"
  ) {
    return [];
  }

  // 柱碰優先直接讀實際下注內容 td。
  // 不再用整頁文字正規表示式截取，避免第三柱很長時被下一欄資料截斷。
  const directPillarOrders = scrapeCommonPillarRows(root);

  const hostname =
    location.hostname.toLowerCase();

  // 柱碰資料只作為欄位補強，不可先插入結果陣列；否則柱碰會全部跑到
  // 全車／連碰前面，破壞下注明細原始批次順序。
  const orders = [];
  const seen = new Set();
  const signatureCounts = new Map();

  const pageText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  // 依網站每批末尾的「單項金額總計」逐批切開，不限制往前字數。
  // 固定 1200 字的視窗遇到較長批次會遺失日期／玩法，造成少批。
  const totalSegments = pageText.split(/單項金額總計/);
  let activeGameSection = "";
  const blocks = totalSegments.slice(0, -1).map((segment, index) => {
    activeGameSection = gameSectionFromText(segment, activeGameSection);
    const summary = totalSegments[index + 1].match(/^\s*(\d+(?:\.\d+)?)/);
    return summary ? { text: segment, total: summary[1], batchIndex: index, gameSection: activeGameSection } : null;
  }).filter(Boolean);

  for (const block of blocks) {
    const textBlock = block.text;

    const playParts =
      textBlock.match(
        /([二三四五星]星)\s*(柱碰|連碰)/
      );

    let play =
      playParts
        ? `${playParts[1]}${playParts[2]}`
        : textBlock.match(
            /(?:全車|[二三四五星]星[^\s]*碰|台號|特尾三|套餐|雙面|快速輸入)/
          )?.[0];

    if (play === "全車" && /全車\s*單碰/.test(textBlock)) {
      play = "全車單碰";
    }

    const pillars = [
      ...textBlock.matchAll(
        /第\s*(\d{1,2})\s*柱\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)/g
      )
    ];

    const numberMatches = [
      ...textBlock.matchAll(
        /\d{1,2}(?:\s*,\s*\d{1,2})+/g
      )
    ];

    let selection =
      pillars.length
        ? pillars
            .map(
              (pillar) =>
                `第${pillar[1].padStart(2, "0")}柱 ${pillar[2].replace(/\s*,\s*/g, ", ")}`
            )
            .join("、")
        : numberMatches
            .at(-1)?.[0]
            ?.replace(/\s*,\s*/g, ", ");

    if (play === "全車單碰") {
      const items = [...textBlock.matchAll(
        /(?:^|\s)(\d{1,2})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\)/g
      )];
      if (items.length) {
        selection = items.map((item) =>
          `${item[1].padStart(2, "0")} ${Number(item[2])}車`
        ).join("、");
      }
    }

    const dateTime =
      textBlock.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      )?.[0];

    const total =
      numeric(block.total);

    const startIndex =
      (pillars.at(-1)?.index ??
        numberMatches.at(-1)?.index ??
        0) +
      (
        pillars.at(-1)?.[0]?.length ??
        numberMatches.at(-1)?.[0]?.length ??
        0
      );

    const valuesAfterNumbers = [
      ...textBlock
        .slice(startIndex)
        .matchAll(
          /\d+(?:\.\d+)?/g
        )
    ].map(
      (value) =>
        Number(value[0])
    );

    const totalIndex =
      valuesAfterNumbers.lastIndexOf(total);

    const eachAmount =
      totalIndex >= 2
        ? valuesAfterNumbers[
            totalIndex - 2
          ]
        : total;

    if (
      !play ||
      !selection ||
      !total ||
      total <= 0 ||
      !eachAmount ||
      eachAmount <= 0
    ) {
      continue;
    }

    const placedAt =
      dateTime
        ? `${dateTime
            .replace(/\//g, "-")
            .replace(" ", "T")}+08:00`
        : new Date().toISOString();

    const directPillar = /柱碰/.test(play)
      ? directPillarOrders.find((order) =>
          String(order.placedAt || "").replace(/\s+/g, "T") ===
            String(placedAt || "").replace(/\s+/g, "T") &&
          order.event === play &&
          (!selection || order.selection === selection)
        )
      : null;

    if (directPillar) {
      selection = directPillar.selection;
    }

    // 第一筆沿用既有 ID，讓後端 UPSERT 更新舊資料；只有網站真的出現第二個
    // 完全相同批次時才加序號，保留真實重複而不製造版本升級重複資料。
    const baseId = directPillar?.id ||
      `${hostname}|text-table-order|${placedAt}|${play}|${selection}|${total}`;
    const occurrence = signatureCounts.get(baseId) || 0;
    signatureCounts.set(baseId, occurrence + 1);
    const id = occurrence ? `${baseId}|batch-${occurrence + 1}` : baseId;

    if (seen.has(id)) continue;

    seen.add(id);

    const comboCount = directPillar?.combinationCount ??
      combinationCountFor(play, selection);
    const carCount = play === "全車單碰"
      ? [...String(selection).matchAll(/(\d+(?:\.\d+)?)\s*車/g)]
          .reduce((sum, item) => sum + Number(item[1]), 0)
      : null;

    orders.push(
      enrichedBet(
        {
          id,
          source: "海勝",
          account: "",
          placedAt,
          event: eventWithGameSection(block.gameSection, play),
          selection,
          odds: directPillar?.odds ?? null,
          stake: directPillar?.unitAmount ?? eachAmount,
          potentialPayout: total,
          status: orderStatusFromText(textBlock),
          result: null,
          reconciled: false
        },
        {
          playType: play,
          unitAmount: play === "全車單碰" ? null : (directPillar?.unitAmount ?? eachAmount),
          combinationCount:
            comboCount,
          carCount: carCount > 0 ? carCount : null,
          betAmount: total,
          rawText: textBlock,
          parseStatus: "parsed"
        }
      )
    );
  }

  if (orders.length) {
    return orders;
  }

  let currentTime = "";

  for (
    const row of root.querySelectorAll("tr")
  ) {
    const raw =
      (
        row.innerText ||
        row.textContent ||
        ""
      )
        .replace(/\u00a0/g, " ")
        .replace(/\s+/g, " ")
        .trim();

    if (
      !raw ||
      /^(頁次|玩法|下注內容|賠率|本金|每碰金額|碰數|下注金額)/.test(raw)
    ) {
      continue;
    }

    const dateTime =
      raw.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    if (dateTime) {
      currentTime =
        dateTime[0].replace(/\//g, "-");
    }

    const play =
      raw.match(
        /(?:全車|[二三四五星]星連碰|[二三四五星]星[^\s]*碰|台號|特尾三|套餐|雙面|快速輸入)/
      )?.[0];

    const numberMatch =
      raw.match(
        /\d{1,2}(?:\s*,\s*\d{1,2})+/
      );

    if (
      !play ||
      !numberMatch
    ) {
      continue;
    }

    const cells = [
      ...row.querySelectorAll("td")
    ].map(
      (cell) =>
        (
          cell.innerText ||
          cell.textContent ||
          ""
        )
          .replace(/\s+/g, " ")
          .trim()
    );

    const stake =
      cells.length >= 8
        ? numeric(cells[7])
        : null;

    if (
      !stake ||
      stake <= 0
    ) {
      continue;
    }

    const selection =
      numberMatch[0].replace(
        /\s*,\s*/g,
        ", "
      );

    const id =
      `${hostname}|table-order|${currentTime}|${play}|${selection}|${stake}`;

    if (seen.has(id)) {
      continue;
    }

    seen.add(id);

    const comboCount =
      combinationCountFor(
        play,
        selection
      );

    orders.push(
      enrichedBet(
        {
          id,
          source: "海勝",
          account: "",
          placedAt:
            currentTime
              ? `${currentTime.replace(" ", "T")}+08:00`
              : new Date().toISOString(),
          event: play,
          selection,
          odds: null,
          stake,
          potentialPayout: null,
          status: orderStatusFromText(raw),
          result: null,
          reconciled: false
        },
        {
          playType: play,
          unitAmount: stake,
          combinationCount:
            comboCount,
          betAmount:
            comboCount
              ? stake * comboCount
              : stake,
          rawText: raw,
          parseStatus: "partial"
        }
      )
    );
  }

  if (orders.length) {
    return orders;
  }

  const fallbackText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  const fallbackBlocks =
    fallbackText.matchAll(
      /([\s\S]{0,1200}?)單項金額總計\s*(\d+(?:\.\d+)?)/g
    );

  for (
    const block of fallbackBlocks
  ) {
    const textBlock =
      block[1];

    const play =
      textBlock.match(
        /(?:全車|[二三四五星]星連碰|[二三四五星]星[^\s]*碰|台號|特尾三|套餐|雙面|快速輸入)/
      )?.[0];

    const numberMatches = [
      ...textBlock.matchAll(
        /\d{1,2}(?:\s*,\s*\d{1,2})+/g
      )
    ];

    const numberMatch =
      numberMatches.at(-1);

    const dateTime =
      textBlock.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      )?.[0];

    const stake =
      numeric(block[2]);

    if (
      !play ||
      !numberMatch ||
      !stake ||
      stake <= 0
    ) {
      continue;
    }

    const selection =
      numberMatch[0].replace(
        /\s*,\s*/g,
        ", "
      );

    const placedAt =
      dateTime
        ? `${dateTime
            .replace(/\//g, "-")
            .replace(" ", "T")}+08:00`
        : new Date().toISOString();

    const id =
      `${hostname}|text-table-order|${placedAt}|${play}|${selection}|${stake}`;

    if (seen.has(id)) {
      continue;
    }

    seen.add(id);

    const comboCount =
      combinationCountFor(
        play,
        selection
      );

    orders.push(
      enrichedBet(
        {
          id,
          source: "海勝",
          account: "",
          placedAt,
          event: play,
          selection,
          odds: null,
          stake,
          potentialPayout: null,
          status: orderStatusFromText(textBlock),
          result: null,
          reconciled: false
        },
        {
          playType: play,
          unitAmount: stake,
          combinationCount:
            comboCount,
          betAmount:
            comboCount
              ? stake * comboCount
              : stake,
          rawText: textBlock,
          parseStatus: "partial"
        }
      )
    );
  }

  return orders;
}

function read188ColumnMeta(selectionCell) {
  if (!selectionCell) return null;

  const clean = (node) =>
    (node?.innerText || node?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();

  const number = (node) => {
    const raw = clean(node).replace(/,/g, "").trim();
    return /^-?\d+(?:\.\d+)?$/.test(raw) ? Number(raw) : null;
  };

  const normalize = (value) => String(value || "").replace(/\s+/g, "");
  let row = selectionCell.closest("tr");

  for (let depth = 0; row && depth < 6; depth++) {
    const rowCells = [...row.cells];
    const selectionIndex = rowCells.findIndex(
      (cell) => cell === selectionCell || cell.contains(selectionCell)
    );

    if (selectionIndex >= 0) {
      let headerRow = row.previousElementSibling;
      for (let back = 0; headerRow && back < 8; back++, headerRow = headerRow.previousElementSibling) {
        if (headerRow.tagName !== "TR") continue;
        const headerCells = [...headerRow.cells];
        const labels = headerCells.map((cell) => normalize(clean(cell)));
        const hSelection = labels.findIndex((x) => x.includes("下注內容"));
        const hUnit = labels.findIndex((x) => x.includes("每碰金額"));
        const hCombo = labels.findIndex((x) => x === "碰數" || x.includes("碰數"));
        const hTotal = labels.findIndex((x) => x === "下注金額" || x.includes("下注金額"));

        if (hSelection < 0 || hCombo < 0 || hTotal < 0) continue;

        const delta = selectionIndex - hSelection;
        const at = (headerIndex) => rowCells[headerIndex + delta] || null;
        const combo = number(at(hCombo));
        const unit = hUnit >= 0 ? number(at(hUnit)) : null;
        const total = number(at(hTotal));

        if (Number.isFinite(combo) && combo > 0) {
          return {
            combinationCount: combo,
            unitAmount: Number.isFinite(unit) ? unit : null,
            betAmount: Number.isFinite(total) ? total : null,
            headerRow,
            dataRow: row
          };
        }
      }
    }

    const table = row.closest("table");
    const parentCell = table?.parentElement?.closest("td");
    row = parentCell?.closest("tr") || null;
  }

  return null;
}

function scrapeCommonPillarRows(root = document) {
  const domain = rootDomain(location.hostname);
  if (!["188hot.net", "bnd139.com", "hyp98.com", "umh693.com", "amc283.com", "pee688.com"].includes(domain)) return [];

  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[domain] || domain;
  const orders = [];
  const seen = new Set();

  const cleanText = (node) =>
    (node?.innerText || node?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();

  const strictNumber = (value) => {
    const cleaned = String(value ?? "").replace(/,/g, "").trim();
    return /^-?\d+(?:\.\d+)?$/.test(cleaned) ? Number(cleaned) : null;
  };

  // 找出真正包含柱碰內容的 td。98 / 16 / 28 / 海勝 / 航海共用這套表格時，
  // 都從實際下注內容欄位完整讀取第01柱到最後一柱。
  const selectionCells = [...root.querySelectorAll("td")].filter((cell) => {
    const raw = cleanText(cell);
    return /第\s*0?1\s*柱/.test(raw) && /第\s*0?2\s*柱/.test(raw);
  });

  for (const selectionCell of selectionCells) {
    const selection = formatPillarSelection(cleanText(selectionCell));
    if (!selection) continue;

    // 網站可能在 td 內再包小 table。由目前 selection td 往外找，
    // 選第一個「selection 後面至少有 5 個數值欄」的 tr，避免抓到內層排版列。
    let row = selectionCell.closest("tr");
    let cells = [];
    let selectionIndex = -1;
    let numericAfter = [];

    for (let depth = 0; row && depth < 5; depth++) {
      cells = [...row.children].filter((el) => /^(TD|TH)$/.test(el.tagName));
      selectionIndex = cells.findIndex((cell) => cell === selectionCell || cell.contains(selectionCell));
      if (selectionIndex >= 0) {
        numericAfter = cells.slice(selectionIndex + 1).map((cell) => strictNumber(cleanText(cell)));
        if (numericAfter.length >= 5 && numericAfter.slice(0, 5).filter((v) => v != null).length >= 4) {
          break;
        }
      }
      const table = row.closest("table");
      const parentCell = table?.parentElement?.closest("td");
      row = parentCell?.closest("tr") || null;
    }

    if (selectionIndex < 0 || numericAfter.length < 5) continue;

    // 優先依表頭欄名直接讀「碰數」；找不到表頭時才沿用舊的欄位順序。
    const columnMeta = read188ColumnMeta(selectionCell);
    const odds = numericAfter[0];
    const principal = numericAfter[1];
    const unitAmount = columnMeta?.unitAmount ?? numericAfter[2];
    const combinationCount = columnMeta?.combinationCount ?? numericAfter[3];
    const betAmount = columnMeta?.betAmount ?? numericAfter[4];

    if (!(Number.isFinite(unitAmount) && unitAmount > 0 &&
          Number.isFinite(combinationCount) && combinationCount > 0 &&
          Number.isFinite(betAmount) && betAmount > 0)) continue;

    // 玩法、日期可能在 rowspan 或外層 row。從目前 row 往外/往上取一小段文字判斷。
    let contextText = cleanText(row);
    let cursor = row;
    for (let i = 0; i < 3 && !/([二三四五星]星)\s*柱碰/.test(contextText); i++) {
      const prev = cursor?.previousElementSibling;
      if (prev) contextText = `${cleanText(prev)} ${contextText}`;
      cursor = prev;
    }
    if (!/([二三四五星]星)\s*柱碰/.test(contextText)) {
      const tableText = cleanText(row?.closest("table"));
      contextText = `${contextText} ${tableText.slice(0, 3000)}`;
    }

    const playMatch = contextText.match(/([二三四五星]星)\s*柱碰/);
    if (!playMatch) continue;
    const event = `${playMatch[1]}柱碰`;

    const dateTime = contextText.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/)?.[0];
    const placedAt = dateTime
      ? `${dateTime.replace(/\//g, "-").replace(/\s+/, "T")}+08:00`
      : new Date().toISOString();

    // 和舊版 fallback 使用相同 id 前綴，讓後端以 UPSERT 更新原本那筆資料，
    // 不會因為修正碰數而新增重複訂單。
    const id = `${hostname}|table-order|${placedAt}|${event}|${selection}|${betAmount}`;
    if (seen.has(id)) continue;
    seen.add(id);

    orders.push(enrichedBet({
      id,
      source,
      account: "",
      placedAt,
      event,
      selection,
      odds: Number.isFinite(odds) ? odds : null,
      stake: unitAmount,
      potentialPayout: betAmount,
      status: orderStatusFromText(contextText, cleanText(row)),
      result: null,
      reconciled: false
    }, {
      playType: event,
      unitAmount,
      combinationCount,
      carCount: null,
      betAmount,
      principal: Number.isFinite(principal) ? principal : null,
      rawText: cleanText(row),
      parseStatus: "parsed"
    }));
  }

  return orders;
}

function scrape188SkyRows(root = document) {
  const domain = rootDomain(location.hostname);
  if (!["188hot.net", "bnd139.com", "hyp98.com"].includes(domain)) return [];

  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[domain] || domain;
  const orders = [];
  const seenContainers = new Set();

  const clean = (node) => (node?.innerText || node?.textContent || "")
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+/g, " ")
    .trim();

  const selectionCells = [...root.querySelectorAll("td")].filter((cell) => {
    const value = clean(cell);
    return /特碼\s*\d/.test(value) && /正碼\s*\d/.test(value);
  });

  for (const selectionCell of selectionCells) {
    let container = selectionCell;
    for (let depth = 0; container && depth < 12; depth++, container = container.parentElement) {
      const value = clean(container);
      if (
        /天碰[一二三四五六七八九十]+\s*(?:單碰|連碰)/.test(value) &&
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/.test(value) &&
        /單項金額總計/.test(value)
      ) break;
    }

    if (!container || seenContainers.has(container)) continue;
    seenContainers.add(container);

    const block = clean(container);
    const playMatch = block.match(/天碰([一二三四五六七八九十]+)\s*(單碰|連碰)/);
    if (!playMatch) continue;
    const event = `天碰${playMatch[1]}${playMatch[2]}`;
    const dateTime = block.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/)?.[0];
    const summary = block.match(/單項金額總計\s*(\d+(?:\.\d+)?)/);
    const total = summary ? Number(summary[1]) : 0;
    if (!dateTime || !(total > 0)) continue;

    const itemMatches = [...block.matchAll(
      /特碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)\s*正碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)(?:\s*顯示去除)?\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)/g
    )];
    if (!itemMatches.length) continue;

    const selection = itemMatches.map((item) =>
      `特碼 ${item[1].replace(/\s*,\s*/g, ", ")}／正碼 ${item[2].replace(/\s*,\s*/g, ", ")}`
    ).join("\n");
    const units = [...new Set(itemMatches.map((item) => Number(item[5])))];
    // 同批可能有不同每碰金額；不可用整批總額冒充單位金額。
    const eachAmount = units.length === 1 ? units[0] : null;
    const combinationCount = itemMatches.reduce((sum, item) => sum + Number(item[6]), 0);
    const placedAt = `${dateTime.replace(/\//g, "-").replace(/\s+/, "T")}+08:00`;
    // ID 也必須保留網站實際玩法名稱，避免天碰一／二／三互相覆寫。
    const id = `${hostname}|table-order|${placedAt}|${event}|${selection}|${total}`;

    orders.push(enrichedBet({
      id,
      source,
      account: "",
      placedAt,
      event,
      selection,
      odds: null,
      stake: eachAmount,
      potentialPayout: total,
      status: orderStatusFromText(block),
      result: null,
      reconciled: false
    }, {
      playType: event,
      unitAmount: eachAmount,
      combinationCount,
      carCount: null,
      betAmount: total,
      principal: null,
      rawText: block,
      parseStatus: "parsed"
    }));
  }

  return orders;
}

function scrape188Orders(root = document) {
  const directPillarOrders = scrapeCommonPillarRows(root);
  const directSkyOrders = scrape188SkyRows(root);
  const domain =
    rootDomain(location.hostname);

  if (
    ![
      "188hot.net",
      "bnd139.com",
      "hyp98.com"
    ].includes(domain)
  ) {
    return [];
  }

  const hostname =
    location.hostname.toLowerCase();

  const source =
    HOST_NAMES[hostname] ||
    SITE_NAMES[domain] ||
    domain;

  const pageText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  // 柱碰與連碰可能同時出現在同一張明細表。
  // 舊版只要先抓到任何柱碰就直接 return，導致同頁的連碰整批漏傳。
  // 先保留可靠的 DOM 柱碰結果，再繼續解析其他玩法；相同 id 由 seen 去重。
  const orders = [...directPillarOrders, ...directSkyOrders];
  const seen = new Set(orders.map((order) => order.id));

  // 188 / 98 / 28 的柱碰內容會在下注內容欄位內換行。
  // 直接從該 td 讀完整文字，避免 pageText 正規表示式在換行處截斷最後一柱。
  const pillarCellEntries = [...root.querySelectorAll("td")]
    .map((cell) => {
      const raw = (cell.innerText || cell.textContent || "").replace(/\u00a0/g, " ");
      if (!/第\s*0?1\s*柱/.test(raw) || !/第\s*0?2\s*柱/.test(raw)) return null;

      const selection = formatPillarSelection(raw);
      if (!selection) return null;

      return { cell, selection };
    })
    .filter(Boolean);
  let pillarSelectionIndex = 0;

  // 以網站真正的「單項金額總計」切分批次。舊版限制往前最多 1600 字，
  // 遇到同頁大量表格或隱藏欄位時，會把其中一批的日期／玩法切掉。
  const totalSegments188 = pageText.split(/單項金額總計/);
  let activeGameSection188 = "";
  const blocks188 = totalSegments188
    .slice(0, -1)
    .map((segment, index) => {
      activeGameSection188 = gameSectionFromText(segment, activeGameSection188);
      const summary = totalSegments188[index + 1].match(
        /^\s*(\d+(?:\.\d+)?)(?:\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\))?/
      );
      return summary ? [null, segment.slice(-6000), summary[1], summary[2], activeGameSection188] : null;
    })
    .filter(Boolean);

  for (const block of blocks188) {
    const textBlock =
      block[1];

    const gameSection = block[4];

    const total =
      numeric(block[2]);

    const totalCars =
      numeric(block[3]);

    const dateTime =
      textBlock.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      )?.[0];

    const placedAt =
      dateTime
        ? `${dateTime
            .replace(/\//g, "-")
            .replace(/\s+/, "T")}+08:00`
        : new Date().toISOString();

    const isFullCar =
      /全車\s*單碰/.test(
        textBlock
      );

    const isSpecialSingle =
      /特碼\s*單碰/.test(
        textBlock
      );

    const isTailThreeSingle =
      /特尾三\s*單碰/.test(
        textBlock
      );

    const isSkyTwoCombo =
      /天碰[一二三四五六七八九十]+\s*(?:單碰|連碰)/.test(
        textBlock
      );

    let event = "";
    let selection = "";
    let eachAmount = 0;
    let pillarEntry = null;
    let webCombinationCount = null;

    if (isTailThreeSingle) {
      event = "特尾三單碰";

      const items = [
        ...textBlock.matchAll(
          /(?:^|\s)(\d{3})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) continue;

      selection = items
        .map((item) => `${item[1]} ${Number(item[2])}`)
        .join("、");
      eachAmount = total;
    } else if (isSkyTwoCombo) {
      const skyMatch = textBlock.match(/天碰([一二三四五六七八九十]+)\s*(單碰|連碰)/);
      event = skyMatch ? `天碰${skyMatch[1]}${skyMatch[2]}` : "";

      const items = [
        ...textBlock.matchAll(
          /特碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)\s*正碼\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)(?:\s*顯示去除)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?/g
        )
      ];

      if (!items.length) continue;

      selection = items
        .map((item) =>
          `特碼 ${item[1].replace(/\s*,\s*/g, ", ")}／正碼 ${item[2].replace(/\s*,\s*/g, ", ")}`
        )
        .join("\n");

      const unitAmounts = [...new Set(items.map((item) => Number(item[3])))];
      // 同批可能有不同每碰金額；各組金額保留在 rawText，由顯示端逐組呈現。
      eachAmount = unitAmounts.length === 1 ? unitAmounts[0] : null;
      webCombinationCount = items.reduce((sum, item) => sum + Number(item[4]), 0);
    } else if (isSpecialSingle) {
      event = "特碼單碰";

      const items = [
        ...textBlock.matchAll(
          /(?:^|\s)(\d{1,2})\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      selection =
        items
          .map(
            (item) =>
              `${item[1].padStart(2, "0")} ${Number(item[4])}`
          )
          .join("、");

      eachAmount =
        total;
    } else if (isFullCar) {
      event = "全車單碰";

      const items = [
        ...textBlock.matchAll(
          /(?:^|\s)(\d{1,2})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      selection =
        items
          .map(
            (item) =>
              `${item[1].padStart(2, "0")} ${Number(item[2])}車`
          )
          .join("、");

      eachAmount =
        totalCars ||
        items.reduce(
          (sum, item) =>
            sum + Number(item[2]),
          0
        );
    } else {
      const playParts =
        textBlock.match(
          /([二三四五星]星)\s*(柱碰|連碰)/
        );

      event =
        playParts
          ? `${playParts[1]}${playParts[2]}`
          : "";

      const pillars = [
        ...textBlock.matchAll(
          /第\s*(\d{1,2})\s*柱\s*(\d{1,2}(?:\s*,\s*\d{1,2})*)/g
        )
      ];

      const numberMatches = [
        ...textBlock.matchAll(
          /\d{1,2}(?:\s*,\s*\d{1,2})+/g
        )
      ];

      const numberMatch =
        numberMatches.at(-1);

      if (
        !event ||
        (!pillars.length && !numberMatch)
      ) {
        continue;
      }

      if (/柱碰/.test(event)) {
        pillarEntry = pillarCellEntries[pillarSelectionIndex++] || null;
        const domSelection = pillarEntry?.selection || "";
        const columnMeta = read188ColumnMeta(pillarEntry?.cell);
        if (columnMeta?.combinationCount) {
          webCombinationCount = columnMeta.combinationCount;
        }
        selection = domSelection || (pillars.length
          ? pillars
              .map(
                (pillar) =>
                  `第${pillar[1].padStart(2, "0")}柱 ${pillar[2].replace(/\s*,\s*/g, ", ")}`
              )
              .join("、")
          : "");
      } else {
        // 連碰號碼過多時，網站會在同一個下注內容 td 內自動換行。
        // numberMatches.at(-1) 只會留下最後一行；改為從下注時間後、
        // 「顯示去除」按鈕前的完整內容依原順序讀取全部號碼。
        const afterDate = dateTime && textBlock.includes(dateTime)
          ? textBlock.slice(textBlock.indexOf(dateTime) + dateTime.length)
          : textBlock;
        const hasSelectionBoundary = /顯示去除/.test(afterDate);
        const selectionRegion = afterDate.split(/顯示去除|新增備註/)[0];
        const wrappedNumbers = hasSelectionBoundary
          ? [...selectionRegion.matchAll(/(?:^|[^\d])(\d{1,2})(?=[^\d]|$)/g)]
              .map((match) => match[1].padStart(2, "0"))
          : [];
        selection = wrappedNumbers.length
          ? wrappedNumbers.join(", ")
          : numberMatch[0].replace(/\s*,\s*/g, ", ");
      }

      const lastSelectionMatch =
        /柱碰/.test(event) && pillars.length
          ? pillars.at(-1)
          : numberMatch;

      const tail =
        textBlock.slice(
          (lastSelectionMatch.index || 0) +
          lastSelectionMatch[0].length
        );

      const values = [
        ...tail.matchAll(
          /\d+(?:\.\d+)?/g
        )
      ].map(
        (value) =>
          Number(value[0])
      );

      const totalIndex =
        values.lastIndexOf(
          total
        );

      // 網站欄位順序：賠率、本金、每碰金額、碰數、下注金額。
      // 直接取下注金額前一格的「碰數」，不自行計算。
      if (/柱碰/.test(event) && webCombinationCount == null && totalIndex >= 1) {
        webCombinationCount = values[totalIndex - 1];
      }

      eachAmount =
        totalIndex >= 2
          ? values[
              totalIndex - 2
            ]
          : total;
    }

    if (
      !event ||
      !selection ||
      !total ||
      total <= 0 ||
      !eachAmount ||
      eachAmount <= 0
    ) {
      continue;
    }

    const id =
      `${hostname}|table-order|${placedAt}|${event}|${selection}|${total}`;

    if (seen.has(id)) {
      const existing = orders.find((order) => order.id === id);
      if (existing && gameSection) existing.event = eventWithGameSection(gameSection, existing.playType || event);
      continue;
    }

    seen.add(id);

    // 柱碰直接採用網站明細中的「碰數」欄位；其他玩法維持既有邏輯。
    const comboCount = /柱碰|天碰/.test(event)
      ? webCombinationCount
      : combinationCountFor(event, selection);

    orders.push(
      enrichedBet(
        {
          id,
          source,
          account: "",
          placedAt,
          event: eventWithGameSection(gameSection, event),
          selection,
          odds: null,
          stake: eachAmount,
          potentialPayout: total,
          status: orderStatusFromText(textBlock),
          result: null,
          reconciled: false
        },
        {
          playType: event,
          unitAmount:
            isFullCar
              ? null
              : eachAmount,
          combinationCount:
            comboCount,
          carCount:
            isFullCar
              ? eachAmount
              : null,
          betAmount: total,
          rawText: textBlock,
          parseStatus: "parsed"
        }
      )
    );
  }

  return orders;
}

function scrapeAmcOrders(root = document) {
  if (
    !["amc283.com", "pee688.com"].includes(rootDomain(location.hostname))
  ) {
    return [];
  }

  // 與 98 / 16 / 28 / 海勝共用柱碰 DOM 解析。
  // 長柱完整從下注內容欄位讀取，並直接讀網站的每碰金額／碰數／下注金額。
  const directPillarOrders = scrapeCommonPillarRows(root);

  const hostname =
    location.hostname.toLowerCase();

  const pageText =
    (
      root.body?.innerText ||
      root.body?.textContent ||
      ""
    ).replace(/\u00a0/g, " ");

  const textOrders = [...directPillarOrders];

  const blocks =
    pageText.split(
      /單項金額總計/
    );

  let activeGameSection = "";

  for (
    let index = 0;
    index < blocks.length - 1;
    index++
  ) {
    const block =
      blocks[index];

    activeGameSection = gameSectionFromText(block, activeGameSection);

    const next =
      blocks[index + 1];

    const time =
      block.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    const play =
      block.match(
        /(全車(?:\s*單碰)?|特碼(?:\s*單碰)?|[二三四五星]星\s*(?:連柱碰|柱碰|連碰)|台號|特尾\S*|套餐|自選不中|雙面|快速輸入)/
      );

    const summary =
      next.match(
        /^\s*(\d+(?:\.\d+)?)(?:\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\))?/
      );

    if (
      !time ||
      !play ||
      !summary
    ) {
      continue;
    }

    const event =
      play[1].replace(
        /\s+/g,
        ""
      );

    const total =
      Number(summary[1]);

    const placedAt =
      `${time[0]
        .replace(/\//g, "-")
        .replace(/\s+/, "T")}+08:00`;

    // 同頁可同時出現柱碰、連碰、全車與單碰。柱碰採 DOM 結果，
    // 其餘玩法仍繼續解析，避免因一批柱碰讓整頁提早結束。
    if (
      /柱碰/.test(event) &&
      directPillarOrders.some(
        (order) =>
          String(order.placedAt || "").replace(/\s+/g, "T") ===
            String(placedAt || "").replace(/\s+/g, "T") &&
          order.event === event
      )
    ) {
      continue;
    }

    if (/^特尾三/.test(event)) {
      const items = [
        ...block.matchAll(
          /(?:^|\s)(\d{3})\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      const selections = items
        .map((item) => `${item[1]} ${Number(item[2])}`)
        .join("、");

      textOrders.push(
        enrichedBet(
          {
            id: `${hostname}|text-order|${time[0]}|特尾三單碰|${selections}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, "特尾三單碰"),
            selection: selections,
            odds: null,
            stake: total,
            potentialPayout: total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            playType: "特尾三單碰",
            unitAmount: null,
            combinationCount: null,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    } else if (/^特碼/.test(event)) {
      // 航海的特碼單碰是一個號碼一列：
      // 下注內容、賠率、本金、下注金額、中獎、退水漲跌、退水金額、小計。
      // 只保留實際的「號碼 + 下注金額」，其他欄位不送到同步器。
      const items = [
        ...block.matchAll(
          /(?:^|\s)(\d{1,2})\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?(?=\s|$)/g
        )
      ];

      if (!items.length) {
        continue;
      }

      const selections = items
        .map((item) => `${item[1].padStart(2, "0")} ${Number(item[4])}`)
        .join("、");

      textOrders.push(
        enrichedBet(
          {
            id: `${hostname}|text-order|${time[0]}|特碼單碰|${selections}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, "特碼單碰"),
            selection: selections,
            odds: null,
            stake: total,
            potentialPayout: total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            playType: "特碼單碰",
            unitAmount: null,
            combinationCount: null,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    } else if (/^全車/.test(event)) {
      const items = [];

      const itemPattern =
        /(?:^|\s)(\d{1,2})\s+(?:\d+(?:\.\d+)?)\s+(?:\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s*\(\s*(\d+(?:\.\d+)?)\s*車/g;

      for (
        const match of block.matchAll(
          itemPattern
        )
      ) {
        items.push({
          line:
            `${match[1].padStart(2, "0")} ${Number(match[3])}車`,
          cars:
            Number(match[3])
        });
      }

      if (!items.length) {
        continue;
      }

      const selections =
        [
          ...new Set(
            items.map(
              (item) =>
                item.line
            )
          )
        ].join("、");

      const cars =
        Number(summary[2]) ||
        items.reduce(
          (sum, item) =>
            sum + item.cars,
          0
        );

      textOrders.push(
        enrichedBet(
          {
            id:
              `${hostname}|text-order|${time[0]}|${event}|${selections}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, event === "全車" ? "全車單碰" : event),
            selection:
              selections,
            odds: null,
            stake: cars,
            potentialPayout:
              total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            playType:
              event === "全車"
                ? "全車單碰"
                : event,
            unitAmount: null,
            carCount: cars,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    } else {
      const numberMatches = [
        ...block.matchAll(
          /\d{1,2}(?:\s*,\s*\d{1,2})+/g
        )
      ];

      const numberMatch =
        numberMatches.at(-1);

      if (!numberMatch) {
        continue;
      }

      // 連柱碰會先列出各行下注號碼，再以「碰」列出碰撞號碼。
      // 必須保存全部原始分組，不能只取最後一行，也不能自行改成柱碰或連碰。
      const selection = /連柱碰/.test(event)
        ? numberMatches.map((match, matchIndex) => {
            const numbers = match[0].replace(/\s*,\s*/g, ", ").trim();
            return matchIndex === numberMatches.length - 1 ? `碰 ${numbers}` : numbers;
          }).join("、")
        : numberMatch[0].replace(
            /\s*,\s*/g,
            ", "
          );

      const tail =
        block.slice(
          (numberMatch.index || 0) +
          numberMatch[0].length
        );

      const values = [
        ...tail.matchAll(
          /\d+(?:\.\d+)?/g
        )
      ].map(
        (value) =>
          Number(value[0])
      );

      const totalIndex =
        values.lastIndexOf(total);

      const eachAmount =
        totalIndex >= 2
          ? values[
              totalIndex - 2
            ]
          : total;

      const comboCount = /連柱碰/.test(event) && totalIndex >= 1
        ? values[totalIndex - 1]
        : combinationCountFor(
            event,
            selection
          );

      textOrders.push(
        enrichedBet(
          {
            id:
              `${hostname}|text-order|${time[0]}|${event}|${selection}|${total}`,
            source: "航海",
            account: "",
            placedAt,
            event: eventWithGameSection(activeGameSection, event),
            selection,
            odds: null,
            stake: eachAmount,
            potentialPayout:
              total,
            status: orderStatusFromText(block),
            result: null,
            reconciled: false
          },
          {
            playType: event,
            unitAmount:
              eachAmount,
            combinationCount:
              comboCount,
            betAmount: total,
            rawText: block,
            parseStatus: "parsed"
          }
        )
      );
    }
  }

  if (textOrders.length) {
    return textOrders;
  }

  const rows = [
    ...root.querySelectorAll("tr")
  ];

  const orders = [];

  let current = null;

  const flush = () => {
    if (
      !current ||
      !current.time ||
      !current.items.length ||
      !current.stake
    ) {
      return;
    }

    const selections =
      current.items
        .map(
          (item) =>
            `${item.number} ${item.unit}`
        )
        .join("、");

    orders.push(
      enrichedBet(
        {
          id:
            `${hostname}|order|${current.time}|${current.play}|${selections}|${current.stake}`,
          source: "航海",
          account: "",
          placedAt:
            `${current.time.replace(" ", "T")}+08:00`,
          event:
            current.play,
          selection:
            `${current.play} ${selections}`,
          odds:
            current.odds,
          stake:
            current.stake,
          potentialPayout:
            null,
          status:
            current.status || "待結算",
          result:
            null,
          reconciled:
            false
        },
        {
          playType:
            current.play,
          unitAmount:
            current.stake,
          betAmount:
            current.stake,
          rawText:
            selections,
          parseStatus:
            "partial"
        }
      )
    );
  };

  for (
    const row of rows
  ) {
    const cells = [
      ...row.querySelectorAll(
        "td,th"
      )
    ]
      .map(closestText)
      .filter(Boolean);

    const line =
      cells.join(" ");

    const dateTime =
      line.match(
        /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}:\d{2}/
      );

    if (dateTime) {
      flush();

      const play =
        cells.find(
          (cell) =>
            /全車|二三四星|台號|特尾|套餐|自選不中|雙面|快速/.test(cell)
        ) ||
        "下注";

      current = {
        time:
          dateTime[0].replace(/\//g, "-"),
        play,
        items: [],
        stake: 0,
        odds: null,
        status: orderStatusFromText(line)
      };
    }

    if (!current) {
      continue;
    }

    if (orderStatusFromText(line) !== "待結算") {
      current.status = orderStatusFromText(line);
    }

    const unitMatch =
      line.match(
        /(\d+(?:\.\d+)?)\s*\(\s*(\d+(?:\.\d+)?)\s*車\s*\)/
      );

    if (
      unitMatch &&
      !line.includes("單項金額總計")
    ) {
      const numberCell =
        cells.find(
          (cell) =>
            /^\d{1,2}(?:\s+\d{1,2})*$/.test(cell)
        );

      const numbers =
        numberCell
          ? numberCell.match(
              /\b\d{1,2}\b/g
            ) || []
          : [];

      numbers.forEach(
        (number) => {
          const unit =
            `${unitMatch[2]}車`;

          if (
            !current.items.some(
              (item) =>
                item.number === number &&
                item.unit === unit
            )
          ) {
            current.items.push({
              number,
              unit
            });
          }
        }
      );

      const odds =
        cells
          .map(numeric)
          .find(
            (value) =>
              value &&
              value > 1 &&
              value < 10000
          );

      if (odds) {
        current.odds = odds;
      }
    }

    if (
      line.includes(
        "單項金額總計"
      )
    ) {
      const total =
        line.match(
          /(\d+(?:\.\d+)?)\s*\(/
        );

      if (total) {
        current.stake =
          Number(total[1]);
      }

      flush();

      current = null;
    }
  }

  flush();

  return orders;
}

function scrapeVs968Json(responseText) {
  const root = rootDomain(location.hostname);
  if (!["vs968.net", "kd998.net"].includes(root)) return [];

  let payload;
  try {
    payload = JSON.parse(responseText || "");
  } catch {
    return [];
  }

  if (!Array.isArray(payload?.rows)) return [];

  const hostname = location.hostname.toLowerCase();
  const source = HOST_NAMES[hostname] || SITE_NAMES[root] || root;
  const playNames = {
    1: "全車", 2: "特別號", 3: "正特碼雙面", 4: "台號",
    5: "特尾三", 6: "二星", 7: "三星", 8: "四星",
    9: "天碰二", 10: "天碰三", 11: "反轉樂", 12: "五星"
  };
  const bets = [];
  const kdPlayNames = {
    1: "正碼", 2: "特碼", 3: "正特碼雙面", 4: "台號", 5: "特尾三",
    6: "二星", 7: "三星", 8: "四星", 9: "天碰二", 10: "天碰三",
    11: "反轉樂", 12: "五星", 13: "衝鋒三"
  };

  payload.rows.forEach((row, rowIndex) => {
    const placedAt = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(String(row?.created_at || ""))
      ? `${String(row.created_at).replace(" ", "T")}+08:00`
      : new Date().toISOString();
    const details = Array.isArray(row?.details) ? row.details : [];
    const seq = String(row?.game?.seq || "").trim();
    const groupNo = String(row?.group?.no || "").padStart(3, "0");

    if (root === "kd998.net") {
      const parsedDetails = details.map((detail) => {
        const playCode = Number(detail?.play);
        const play = kdPlayNames[playCode] || `未辨識玩法 ${playCode || ""}`.trim();
        const amount = Number(detail?.money);
        const carUnit = Number(kdCarUnits[play]);
        const cars = amount > 0 && carUnit > 0 ? amount / carUnit : null;
        const water = Number(detail?.water);
        const payout = amount > 0 && Number.isFinite(water) ? amount * (100 - water) / 100 : null;
        return { play, content: String(detail?.content ?? "").trim(), amount, cars, payout, odds: Number(detail?.odds) };
      }).filter((detail) => detail.play && detail.content && detail.amount > 0);
      if (!parsedDetails.length) return;

      const plays = [...new Set(parsedDetails.map((detail) => detail.play))];
      const amounts = parsedDetails.map((detail) => detail.amount);
      const cars = parsedDetails.map((detail) => detail.cars);
      const selection = parsedDetails.map((detail) => [
        detail.play,
        detail.content,
        `下注金額 ${detail.amount}`,
        detail.cars == null ? "車數 未辨識" : `車數 ${Number(detail.cars.toFixed(4))} 車`
      ].join("｜")).join("\n");
      const playType = plays.join("／");
      bets.push(enrichedBet({
        id: `${hostname}|kd-gateway-batch|${row?.id ?? rowIndex}`,
        source,
        account: "",
        placedAt,
        event: playType,
        selection,
        odds: parsedDetails.every((detail) => detail.odds === parsedDetails[0].odds) ? parsedDetails[0].odds : null,
        stake: amounts.every((amount) => amount === amounts[0]) ? amounts[0] : 0,
        potentialPayout: parsedDetails.every((detail) => detail.payout != null)
          ? parsedDetails.reduce((sum, detail) => sum + detail.payout, 0)
          : null,
        status: row?.is_cancel ? "已撤單" : "待結算",
        result: null,
        reconciled: false
      }, {
        playType,
        unitAmount: amounts.every((amount) => amount === amounts[0]) ? amounts[0] : null,
        carCount: cars.every((value) => value != null) ? cars.reduce((sum, value) => sum + value, 0) : null,
        betAmount: amounts.reduce((sum, amount) => sum + amount, 0),
        rawText: JSON.stringify(row).slice(0, 20000),
        parseStatus: cars.every((value) => value != null) ? "parsed" : "partial"
      }));
      return;
    }

    details.forEach((detail, detailIndex) => {
      const playCode = Number(detail?.play);
      const playName = playNames[playCode] || `未辨識玩法 ${playCode || ""}`.trim();
      const isSix = String(row?.casino ?? row?.game?.casino ?? "") === "1";
      // 六合沿用既有批次格式，網頁會依同一時間與群組合併成「台號」直式清單。
      // 其他盤別只採用 gateway 明確提供的玩法代碼名稱，不自行猜測單碰／連碰。
      const event = isSix && seq && playCode === 4
        ? `六合 / ${seq}${groupNo ? ` - ${groupNo}` : ""}`
        : playName;
      const money = Number(detail?.money);
      const rowAmount = Number(row?.amount);
      const amount = Number.isFinite(money) && money > 0
        ? money
        : (Number.isFinite(rowAmount) && rowAmount > 0 ? rowAmount : 0);
      if (!(amount > 0)) return;

      bets.push(enrichedBet({
        id: `${hostname}|gateway|${row?.id ?? rowIndex}|${detail?.id ?? detailIndex}`,
        source,
        account: "",
        placedAt,
        event,
        selection: String(detail?.content ?? "").trim(),
        odds: Number.isFinite(Number(detail?.odds)) ? Number(detail.odds) : null,
        stake: amount,
        potentialPayout: amount,
        status: row?.is_cancel ? "已撤單" : "待結算",
        result: null,
        reconciled: false
      }, {
        playType: isSix ? "台號" : playName,
        unitAmount: amount,
        combinationCount: null,
        carCount: null,
        betAmount: amount,
        principal: null,
        rawText: JSON.stringify({ rowId: row?.id, betType: row?.bet_type, detail }),
        parseStatus: playNames[playCode] ? "parsed" : "partial"
      }));
    });
  });

  return bets;
}

function scrapeDetailResponse(responseText) {
  const documents = [
    new DOMParser().parseFromString(
      responseText || "",
      "text/html"
    )
  ];

  try {
    const strings = [];

    const collect = (
      value,
      depth = 0
    ) => {
      if (
        depth > 8 ||
        strings.length > 80
      ) {
        return;
      }

      if (
        typeof value === "string"
      ) {
        if (
          value.includes("分組序號報表") ||
          value.includes("下注明細") ||
          value.includes("<tr")
        ) {
          strings.push(value);
        }

        return;
      }

      if (Array.isArray(value)) {
        value.forEach(
          (item) =>
            collect(
              item,
              depth + 1
            )
        );
      } else if (
        value &&
        typeof value === "object"
      ) {
        Object.values(
          value
        ).forEach(
          (item) =>
            collect(
              item,
              depth + 1
            )
        );
      }
    };

    collect(
      JSON.parse(
        responseText
      )
    );

    strings.forEach(
      (html) =>
        documents.push(
          new DOMParser().parseFromString(
            html,
            "text/html"
          )
        )
    );
  } catch {}

  const result = scrapeVs968Json(responseText);
  const seen = new Set(result.map((bet) => bet.id));

  documents.forEach(
    (doc) => {
      const parsed = rootDomain(location.hostname) === "vs968.net"
        ? [...scrape(doc), ...scrapeGroupedReportFrom(doc)]
        : scrapeGroupedReportFrom(doc);

      parsed.forEach(
        (bet) => {
          if (
            !seen.has(
              bet.id
            )
          ) {
            seen.add(
              bet.id
            );

            result.push(
              bet
            );
          }
        }
      );
    }
  );

  return result;
}

function taiwanDateKey(value = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Taipei",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(value);
}

function parseA07LedgerResponse(responseText, capturedAt = new Date()) {
  const root = rootDomain(location.hostname);
  if (!["hyp98.com", "188hot.net", "bnd139.com", "umh693.com"].includes(root)) return [];

  let payload;
  try {
    payload = JSON.parse(String(responseText || ""));
  } catch {
    return [];
  }

  const games = Array.isArray(payload) ? payload : [payload];
  const source = SITE_NAMES[root] || root;
  const date = taiwanDateKey(capturedAt);
  const capturedAtIso = capturedAt.toISOString();
  const rows = [];

  const amount = (value) => {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  };

  for (const game of games) {
    const gameName = String(game?.GameName || "").trim();
    const periods = Array.isArray(game?.DataList) ? game.DataList : [];

    for (const period of periods) {
      const phaseName = String(period?.PhaseName || period?.PhasesName || "").trim();
      const groups = Array.isArray(period?.DataList) ? period.DataList : [];

      for (const group of groups) {
        const playType = String(group?.GroupName || "").trim();
        const totalAmount = amount(group?.TotBet);
        const winningAmount = amount(group?.TotBetWinLose);
        if (!gameName || !phaseName || !playType || totalAmount == null || winningAmount == null) continue;

        rows.push({
          date,
          source,
          account: "",
          gameName,
          phaseName,
          playType,
          totalAmount,
          winningAmount,
          capturedAt: capturedAtIso,
          parseStatus: "parsed"
        });
      }
    }
  }

  return rows;
}

function scrapeSharedLedger(root = document, capturedAt = new Date()) {
  const domain = rootDomain(location.hostname);
  if (!["kd998.net", "vs968.net"].includes(domain)) return [];
  const ledger = root.querySelector("#ledger_01");
  if (!ledger) return [];

  const clean = (node) => (node?.innerText || node?.textContent || "")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const labels = [...ledger.querySelectorAll(".tr.tr-head .th")].map(clean);
  const nameIndex = labels.findIndex((value) => value === "名稱");
  const totalIndex = labels.findIndex((value) => value === "總量");
  const winningIndex = labels.findIndex((value) => value === "中獎");
  if (nameIndex < 0 || totalIndex < 0 || winningIndex < 0) return [];

  const source = SITE_NAMES[domain];
  const date = taiwanDateKey(capturedAt);
  const capturedAtIso = capturedAt.toISOString();
  const rows = [];

  for (const row of ledger.querySelectorAll(".tr.tr-body")) {
    const cells = [...row.children];
    const phaseName = clean(cells[0]).replace(/[>＞]\s*$/, "").trim();
    const playType = clean(cells[nameIndex]);
    const totalAmount = numeric(clean(cells[totalIndex]));
    const winningAmount = numeric(clean(cells[winningIndex]));
    const group = row.closest(".bet_group.f_group");
    const gameName = clean(group?.querySelector(":scope > .panel_title"));
    if (!gameName || !phaseName || !playType || totalAmount == null || winningAmount == null) continue;

    rows.push({
      date,
      source,
      account: "",
      gameName,
      phaseName,
      playType,
      totalAmount,
      winningAmount,
      capturedAt: capturedAtIso,
      parseStatus: "parsed"
    });
  }

  return rows;
}

function storeLedgerSnapshot(rows) {
  if (!rows.length) return;
  const actualAccount = reportActualAccount();
  safeMessage({
    type: "STORE_LEDGER_SNAPSHOT",
    rows: rows.map((row) => actualAccount ? { ...row, account: actualAccount } : row)
  });
}

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.type !== "SYNC_LEDGER_RESPONSE") return;
  try {
    const url = new URL(event.data.url, location.href);
    if (url.origin !== location.origin || !/(?:\/api\/Front\/A07|\/api\/FrontA07)\/Query$/i.test(url.pathname)) return;
    const rows = parseA07LedgerResponse(event.data.response || "");
    document.documentElement.dataset.syncLedgerCount = String(rows.length);
    storeLedgerSnapshot(rows);
  } catch {}
});

function syncLedgerDom() {
  const rows = scrapeSharedLedger();
  document.documentElement.dataset.syncLedgerCount = String(rows.length);
  storeLedgerSnapshot(rows);
}

setInterval(syncLedgerDom, 10000);
syncLedgerDom();

window.addEventListener(
  "message",
  (event) => {
    if (
      event.source !== window ||
      event.data?.type !==
        "SYNC_DETAIL_RESPONSE"
    ) {
      return;
    }

    const supportedRoots = [
      "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
      "188hot.net", "bnd139.com", "umh693.com", "amc283.com", "pee688.com"
    ];
    if (!supportedRoots.includes(rootDomain(location.hostname))) return;

    try {
      const data =
        event.data;

      const url =
        new URL(
          data.url,
          location.href
        );

      if (
        url.origin !==
        location.origin
      ) {
        return;
      }

      document.documentElement.dataset.syncDetailResponse =
        `${data.method || "GET"} ${url.pathname}${url.search}`.slice(0, 500);
      safeMessage({
        type:
          "LEARN_DETAIL_REQUEST",
        request: {
          host:
            location.hostname,
          root:
            rootDomain(location.hostname),
          path:
            url.pathname + url.search,
          url:
            url.href,
          method:
            data.method === "POST"
              ? "POST"
              : "GET",
          body:
            data.body || "",
          contentType:
            data.contentType || "",
          headers:
            data.headers || {}
        }
      });

      const bets =
        scrapeDetailResponse(
          data.response || ""
        );

      document.documentElement.dataset.syncDetailCount = String(bets.length);

      safeMessage({
        type:
          "POLL_STATUS",
        state: {
          ok: true,
          count:
            bets.length
        }
      });

      if (bets.length) {
        safeMessage({
          type:
            "SYNC_BETS",
          bets
        });
      }
    } catch {}
  }
);

function isLoggedInWorkPage() {
  const bodyText =
    (
      document.body?.innerText ||
      ""
    ).slice(
      0,
      20000
    );

  return (
    bodyText.includes(
      "最近下注"
    ) ||
    bodyText.includes(
      "下注明細"
    ) ||
    bodyText.includes(
      "登出"
    )
  );
}

function preserveWebsiteOrder(bets) {
  const totals =
    new Map();

  const seen =
    new Map();

  bets.forEach(
    (bet) =>
      totals.set(
        bet.placedAt,
        (
          totals.get(
            bet.placedAt
          ) || 0
        ) + 1
      )
  );

  return bets.map(
    (bet) => {
      if (
        (
          totals.get(
            bet.placedAt
          ) || 0
        ) < 2
      ) {
        return bet;
      }

      const position =
        seen.get(
          bet.placedAt
        ) || 0;

      seen.set(
        bet.placedAt,
        position + 1
      );

      const milliseconds =
        String(
          Math.max(
            0,
            999 - position
          )
        ).padStart(
          3,
          "0"
        );

      const placedAt =
        String(
          bet.placedAt
        ).replace(
          /(?:\.\d{1,3})?([+-]\d\d:\d\d|Z)$/,
          `.${milliseconds}$1`
        );

      return {
        ...bet,
        placedAt
      };
    }
  );
}

function sendBets(bets) {
  if (!bets.length) {
    return;
  }

  const actualAccount = reportActualAccount();
  bets = preserveWebsiteOrder(
    bets.map((bet) => actualAccount ? { ...bet, account: actualAccount } : bet)
  );

  safeMessage({
    type:
      "SYNC_BETS",
    bets
  });
}

async function sync() {
  const domain =
    rootDomain(
      location.hostname
    );

  const bets =
    domain === "kd998.net"
      ? scrapeKdOrders()
      : ["amc283.com", "pee688.com"].includes(domain)
      ? scrapeAmcOrders()
      : domain === "umh693.com"
      ? scrapeUmhOrders()
      : [
          "188hot.net",
          "bnd139.com",
          "hyp98.com"
        ].includes(domain)
      ? scrape188Orders()
      : scrape();

  sendBets(
    bets
  );
}

setInterval(
  sync,
  2000
);

sync();

setInterval(reportActualAccount, 5000);
reportActualAccount();

let learnedPollBusy =
  false;

const kdCarUnits = {};
chrome.storage.local.get(["kdCarUnits"], ({ kdCarUnits: saved = {} }) => Object.assign(kdCarUnits, saved));

async function pollLearnedDetail() {
  const supportedRoots = [
    "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
    "188hot.net", "bnd139.com", "umh693.com", "amc283.com", "pee688.com"
  ];
  const root = rootDomain(location.hostname);
  const directA06Roots = ["hyp98.com", "cj3688.com", "188hot.net", "bnd139.com", "umh693.com", "amc283.com", "pee688.com"];
  // 風雲的最外層只是網路郵局 frameset；真正登入、持有下注狀態並
  // 呼叫 cmd=516 明細 API 的是 /new_web/ 子框架。背景重播必須在該
  // 子框架執行，否則伺服器會把請求視為未登入。其他網站維持頂層執行。
  const isSharedGatewayWorkFrame =
    ["vs968.net", "kd998.net"].includes(root) && location.pathname.includes("/new_web/");
  const isAllowedPollFrame =
    ["vs968.net", "kd998.net"].includes(root) ? isSharedGatewayWorkFrame : window.top === window;
  if (
    learnedPollBusy ||
    !supportedRoots.includes(root) ||
    !isAllowedPollFrame ||
    directA06Roots.includes(root)
  ) return;

  learnedPollBusy = true;
  try {
    const { learnedDetailRequests = {} } = await chrome.storage.local.get(["learnedDetailRequests"]);
    const saved = learnedDetailRequests[root];
    if (!saved) {
      document.documentElement.dataset.syncPollState = "no-saved-request";
      return;
    }

    // Same main-domain subdomains can share the learned endpoint path,
    // while the request is sent from the current origin with its own login cookies.
    const request = { ...saved };
    if (request.path) request.url = location.origin + request.path;

    window.postMessage({ type: "SYNC_SET_DETAIL_REQUEST", request }, "*");
    window.postMessage({ type: "SYNC_POLL_DETAIL" }, "*");
    document.documentElement.dataset.syncPollState =
      `sent ${request.method || "GET"} ${request.path || request.url || ""}`.slice(0, 500);
  } catch (error) {
    safeMessage({ type: "POLL_STATUS", state: { ok: false, error: String(error) } });
  } finally {
    learnedPollBusy = false;
  }
}

setInterval(pollLearnedDetail, 3000);
pollLearnedDetail();

function heartbeat() {
  safeMessage({
    type:
      "SYNC_HEARTBEAT"
  });
}

setInterval(
  heartbeat,
  10000
);

heartbeat();

function findDetailsUrl() {
  const candidates = [
    ...document.querySelectorAll(
      "a,button,[role='button']"
    )
  ];

  const link =
    candidates.find(
      (item) =>
        (
          item.textContent ||
          ""
        )
          .replace(
            /\s+/g,
            ""
          )
          .includes(
            "下注明細"
          )
    );

  if (!link) {
    return location.href;
  }

  const raw =
    link.getAttribute(
      "href"
    ) || "";

  if (
    !raw ||
    raw === "#" ||
    /^javascript:/i.test(raw)
  ) {
    if (
      location.pathname.includes(
        "/new_web/index.php"
      )
    ) {
      const target =
        new URL(
          location.href
        );

      target.hash =
        "#/main/main06";

      return target.href;
    }

    return location.href;
  }

  try {
    return new URL(
      raw,
      location.href
    ).href;
  } catch {
    return "";
  }
}

function isInsideSyncDetailFrame() {
  // The 188/98/28/海勝/航海 family uses a frameset. The hidden bootstrap
  // iframe therefore contains nested frames, and the navigation link usually
  // lives in a child frame rather than in the bootstrap frame itself.
  let current = window;
  for (let depth = 0; depth < 12; depth += 1) {
    try {
      if (current.name === "sync-detail-frame") return true;
      if (current.frameElement?.dataset?.syncDetails === "1") return true;
      if (current.parent === current) break;
      current = current.parent;
    } catch {
      break;
    }
  }
  return false;
}

function openDetailsInsideBackgroundFrame() {
  if (
    !isInsideSyncDetailFrame() ||
    document.querySelector(
      "#bet_details"
    )
  ) {
    return;
  }

  const candidates = [
    ...document.querySelectorAll(
      "a,button,[role='button']"
    )
  ];

  const link =
    candidates.find(
      (item) =>
        (
          item.textContent ||
          ""
        )
          .replace(
            /\s+/g,
            ""
          )
          .includes(
            "下注明細"
          )
    );

  if (link) {
    link.click();
  }
}

function expandBackgroundDetailPageSize() {
  if (!isInsideSyncDetailFrame()) return;

  // A06 預設每頁 15 筆；航海一天超過 15 筆時會出現第 2 頁，
  // 舊版背景框架只解析目前頁面。自動切到網站提供的 50 筆選項，
  // 讓兩頁資料在同一份 DOM 中完整解析，且不改動使用者正在看的頁面。
  const pageSizeSelect = [...document.querySelectorAll("select")].find((select) => {
    const optionTexts = [...select.options].map((option) => option.textContent.trim());
    return optionTexts.includes("15") && optionTexts.includes("50");
  });

  if (!pageSizeSelect) return;

  const option50 = [...pageSizeSelect.options].find(
    (option) => option.textContent.trim() === "50"
  );
  if (!option50) return;

  if (pageSizeSelect.value === option50.value) return;

  pageSizeSelect.value = option50.value;
  pageSizeSelect.dispatchEvent(new Event("input", { bubbles: true }));
  pageSizeSelect.dispatchEvent(new Event("change", { bubbles: true }));
}

function isInsideSyncLedgerFrame() {
  return window.name === "sync-ledger-frame" ||
    document.documentElement?.dataset?.syncLedger === "1";
}

function directLedgerUrl() {
  const root = rootDomain(location.hostname);
  // 只加入已確認的 A07 頁面；其他共版網站不可猜。
  if (!["hyp98.com", "188hot.net", "bnd139.com", "umh693.com"].includes(root)) return "";

  const marker = "/Front/";
  const idx = location.pathname.indexOf(marker);
  if (idx < 0) return "";
  const prefix = location.pathname.slice(0, idx);
  return `${location.origin}${prefix}/Front/A/A07`;
}

function ensureBackgroundLedger() {
  if (window.top !== window || isInsideSyncLedgerFrame()) return;
  const url = directLedgerUrl();
  if (!url) return;

  let frame = document.querySelector("iframe[data-sync-ledger]");
  if (!frame) {
    frame = document.createElement("iframe");
    frame.name = "sync-ledger-frame";
    frame.dataset.syncLedger = "1";
    frame.setAttribute("aria-hidden", "true");
    frame.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;border:0;left:-10000px;top:-10000px";
    document.documentElement.appendChild(frame);
  }

  if (frame.getAttribute("data-sync-url") !== url) {
    frame.setAttribute("data-sync-url", url);
    frame.src = url;
  }
}

function refreshBackgroundLedger() {
  ensureBackgroundLedger();
  const frame = document.querySelector("iframe[data-sync-ledger]");
  const url = frame?.getAttribute("data-sync-url");
  if (!frame || !url) return;
  const refreshed = new URL(url);
  refreshed.searchParams.set("_sync", String(Date.now()));
  frame.src = refreshed.href;
}

function directA06Url() {
  const root = rootDomain(location.hostname);
  const directRoots = [
    "hyp98.com", "kd998.net", "cj3688.com", "188hot.net",
    "bnd139.com", "umh693.com", "amc283.com", "pee688.com"
  ];
  if (!directRoots.includes(root)) return "";

  // These sites use a per-login/site prefix before /Front/. Keep that prefix
  // from the current URL and go straight to the real bet-detail document.
  const marker = "/Front/";
  const idx = location.pathname.indexOf(marker);
  if (idx < 0) return "";
  const prefix = location.pathname.slice(0, idx);
  return `${location.origin}${prefix}/Front/A/A06`;
}

function ensureBackgroundDetails() {
  if (window.top !== window || window.name === "sync-detail-frame") return;

  const root = rootDomain(location.hostname);
  const supportedRoots = [
    "vs968.net", "hyp98.com", "kd998.net", "cj3688.com",
    "188hot.net", "bnd139.com", "umh693.com", "amc283.com", "pee688.com"
  ];
  if (!supportedRoots.includes(root)) return;

  // 188/98/28/海勝/航海 family: A06 is the confirmed detail document.
  // Load it directly in a hidden same-origin frame so its own scripts render
  // the table; content.js in that frame then uses the existing DOM parsers.
  const a06 = directA06Url();
  if (a06) {
    let frame = document.querySelector("iframe[data-sync-details]");
    if (!frame) {
      frame = document.createElement("iframe");
      frame.name = "sync-detail-frame";
      frame.dataset.syncDetails = "1";
      frame.setAttribute("aria-hidden", "true");
      frame.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;border:0;left:-10000px;top:-10000px";
      document.documentElement.appendChild(frame);
    }
    if (frame.getAttribute("data-sync-url") !== a06) {
      frame.setAttribute("data-sync-url", a06);
      frame.src = a06;
    }
    return;
  }

  // vs968 keeps the learned-request flow because its detail source differs.
  chrome.storage.local.get(["learnedDetailRequests"], ({ learnedDetailRequests = {} }) => {
    if (learnedDetailRequests[root]) {
      document.querySelectorAll("iframe[data-sync-details]").forEach((frame) => frame.remove());
      return;
    }
    const url = findDetailsUrl();
    if (!url) return;
    let frame = document.querySelector("iframe[data-sync-details]");
    if (!frame) {
      frame = document.createElement("iframe");
      frame.name = "sync-detail-frame";
      frame.dataset.syncDetails = "1";
      frame.setAttribute("aria-hidden", "true");
      frame.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;border:0;left:-10000px;top:-10000px";
      document.documentElement.appendChild(frame);
    }
    if (frame.getAttribute("data-sync-url") !== url) {
      frame.setAttribute("data-sync-url", url);
      frame.src = url;
    }
  });
}

function refreshBackgroundDetails() {
  ensureBackgroundDetails();
  const frame = document.querySelector("iframe[data-sync-details]");
  const url = frame?.getAttribute("data-sync-url");
  if (frame && url && directA06Url()) {
    // Reload the confirmed A06 document. Cache-busting avoids stale HTML while
    // preserving same-origin login cookies/session.
    const u = new URL(url);
    u.searchParams.set("_sync", String(Date.now()));
    frame.src = u.href;
  }
}

// Fresh-install / cross-page bootstrap: if this extension has no learned
// detail request yet, silently open the site's detail route inside a 1px
// hidden frame. The frame is removed automatically after learning succeeds.
if (isInsideSyncDetailFrame()) {
  setTimeout(expandBackgroundDetailPageSize, 300);
  setTimeout(expandBackgroundDetailPageSize, 1000);
  setTimeout(expandBackgroundDetailPageSize, 2500);
  setInterval(expandBackgroundDetailPageSize, 1000);
  setTimeout(openDetailsInsideBackgroundFrame, 400);
  setTimeout(openDetailsInsideBackgroundFrame, 1400);
  setTimeout(openDetailsInsideBackgroundFrame, 3000);
  setTimeout(openDetailsInsideBackgroundFrame, 6000);
}

if (window.top === window) {
  setTimeout(ensureBackgroundDetails, 700);
  setInterval(() => {
    if (directA06Url()) refreshBackgroundDetails();
    else ensureBackgroundDetails();
  }, 10000);

  // 總帳與下注明細使用不同背景框架。A07 每分鐘更新一次當日快照，
  // 避免頻繁重載造成網站卡頓，也不會把輪詢結果重複累加。
  setTimeout(ensureBackgroundLedger, 1200);
  setInterval(refreshBackgroundLedger, 60000);
}

// 喜網站不建立第二個 /new_web/ SPA。實站確認同一工作階段同時載入
// 隱藏 main07 會讓主頁被踢回登入畫面。使用者手動開啟總帳時仍由
// syncLedgerDom 解析 #ledger_01；下注明細維持既有 gateway 背景輪詢。
