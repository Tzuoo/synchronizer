const sites = ["www.vs968.net","www.hyp98.com","wa.hyp98.com","kd998.net","www2.kd998.net","mail2.cj3688.com","w0.188hot.net","w1.bnd139.com","wc.umh693.com","w0.and539.com","www.pee688.com","www.amc283.com","www.sk6688.net","www.nan688.com","www.la688.com","www.jgm258.com","w0.bnm988.com"];
const accounts = document.querySelector("#accounts");
sites.forEach((site,index) => { const label=document.createElement("label"); label.textContent=`同步項目 ${String(index+1).padStart(2,"0")}`; const input=document.createElement("input"); input.dataset.site=site; label.appendChild(input); accounts.appendChild(label); });
const message = document.querySelector("#message");
const settingsFromForm = () => ({ syncToken: document.querySelector("#token").value.trim(), siteAccounts: Object.fromEntries([...document.querySelectorAll("[data-site]")].map(input => [input.dataset.site, input.value.trim()])) });
const applySettings = ({syncToken="",siteAccounts={}}={}) => { document.querySelector("#token").value=syncToken; document.querySelectorAll("[data-site]").forEach((input)=>input.value=siteAccounts[input.dataset.site]||""); };
function normalizeTransfer(payload) {
  const settings = payload && payload.schemaVersion === 1 ? payload.settings : null;
  if (!settings || typeof settings.syncToken !== 'string' || !settings.siteAccounts || typeof settings.siteAccounts !== 'object' || Array.isArray(settings.siteAccounts)) throw new Error('這不是同步器設定檔。');
  return { syncToken: settings.syncToken.trim(), siteAccounts: Object.fromEntries(sites.map(site => [site, typeof settings.siteAccounts[site] === 'string' ? settings.siteAccounts[site].trim() : ''])) };
}
chrome.storage.local.get(["syncToken","siteAccounts"], applySettings);
document.querySelector("#save").addEventListener("click", async () => { await chrome.storage.local.set(settingsFromForm()); message.textContent="已儲存"; });
document.querySelector("#export-settings").addEventListener("click", () => { const payload={schemaVersion:1,exportedAt:new Date().toISOString(),settings:settingsFromForm()}; const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})); const link=document.createElement('a'); link.href=url; link.download='同步器設定搬移.json'; link.click(); setTimeout(()=>URL.revokeObjectURL(url),0); message.textContent='設定檔已匯出；請妥善保管。'; });
document.querySelector("#import-settings").addEventListener("change", async event => { const file=event.target.files?.[0]; if (!file) return; try { const settings=normalizeTransfer(JSON.parse(await file.text())); if (!settings.syncToken) throw new Error('設定檔沒有同步權杖。'); await chrome.storage.local.set(settings); applySettings(settings); message.textContent='已匯入並儲存；請到擴充彈窗選擇這台是公司或家裡。'; } catch (error) { message.textContent='匯入失敗：'+(error?.message||'檔案無法讀取'); } finally { event.target.value=''; } });
