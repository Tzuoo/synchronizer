// 私人同步權杖只保存在 Chrome storage，不再放入公開更新包。
const DEFAULT_SYNC_TOKEN = "";
